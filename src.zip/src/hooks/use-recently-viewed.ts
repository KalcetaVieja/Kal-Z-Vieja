"use client";

import { useState, useEffect, useCallback } from 'react';
import type { Product } from '@/types';

const RECENTLY_VIEWED_KEY = 'kalz-recently-viewed';
const MAX_RECENTLY_VIEWED = 5;

export const useRecentlyViewed = () => {
  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>([]);

  useEffect(() => {
    // Load from localStorage on initial client-side render
    try {
      const storedItems = localStorage.getItem(RECENTLY_VIEWED_KEY);
      if (storedItems) {
        setRecentlyViewed(JSON.parse(storedItems));
      }
    } catch (error) {
      console.error("Failed to parse recently viewed items from localStorage", error);
    }
  }, []);

  const addRecentlyViewed = useCallback((product: Product) => {
    setRecentlyViewed(prevItems => {
      // 1. Remove the product if it already exists to move it to the front
      const filteredItems = prevItems.filter(item => item.id !== product.id);
      
      // 2. Add the new product to the beginning of the array
      const newItems = [product, ...filteredItems];
      
      // 3. Limit the number of items
      const limitedItems = newItems.slice(0, MAX_RECENTLY_VIEWED);
      
      // 4. Save to localStorage
      try {
        localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(limitedItems));
      } catch (error) {
        console.error("Failed to save recently viewed items to localStorage", error);
      }
      
      return limitedItems;
    });
  }, []);

  const clearRecentlyViewed = useCallback(() => {
    setRecentlyViewed([]);
    try {
      localStorage.removeItem(RECENTLY_VIEWED_KEY);
    } catch (error) {
      console.error("Failed to clear recently viewed items from localStorage", error);
    }
  }, []);

  return { recentlyViewed, addRecentlyViewed, clearRecentlyViewed };
};
