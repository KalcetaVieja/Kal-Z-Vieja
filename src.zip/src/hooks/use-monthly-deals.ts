
"use client";

import { useState, useEffect, useMemo } from 'react';
import type { Product } from '@/types';
import { mockProducts } from '@/data/mock';

// A simple seeded random number generator for deterministic shuffling
function createSeededRandom(seedString: string) {
  let seed = 0;
  for (let i = 0; i < seedString.length; i++) {
    seed = (seed * 31 + seedString.charCodeAt(i)) | 0;
  }

  return function() {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
}

export const useMonthlyDeals = (count: number) => {
  const [dealProducts, setDealProducts] = useState<Product[]>([]);

  const monthlyDeals = useMemo(() => {
    // This logic runs only once per month change, thanks to useMemo
    const date = new Date();
    const seed = date.getFullYear() + '-' + date.getMonth(); // Seed changes monthly
    const seededRandom = createSeededRandom(seed);

    const eligibleProducts = mockProducts.filter(p => 
      p.category === "Camisetas Manga Corta" || p.category === "Tazas"
    );

    // Deterministic shuffle based on the monthly seed
    const shuffled = [...eligibleProducts].sort(() => seededRandom() - 0.5);

    const selectedProducts = shuffled.slice(0, count);

    // Apply 20% discount
    return selectedProducts.map(product => ({
      ...product,
      price: product.price * 0.8,
    }));
  }, [count]); // Reruns if 'count' changes, but seed logic depends on month

  useEffect(() => {
    // Set state on client-side to avoid hydration issues
    setDealProducts(monthlyDeals);
  }, [monthlyDeals]);

  return dealProducts;
};
