
"use client";

import React from 'react';
import { InteractiveCustomizer } from "@/components/catalog/interactive-customizer";
import type { CustomizationOptions } from '@/types';
import { useState } from 'react';

export default function KalZAiPage() {
  const [customizationOptions, setCustomizationOptions] = useState<CustomizationOptions | null>(null);

  return (
    <div className="space-y-12">
      <InteractiveCustomizer onCustomizationChange={setCustomizationOptions} />
    </div>
  );
}
