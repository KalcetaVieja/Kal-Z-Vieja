
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MapPin, Phone, MessageCircle, Send, Instagram, Facebook, ExternalLink } from "lucide-react";
import Link from "next/link";
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { useAssistant } from "@/context/assistant-context";
import { cn } from "@/lib/utils";

const TikTokIcon = ({ className }: { className?: string }) => (
  <svg
    className={cn("lucide", className)}
    viewBox="0 0 24 24" // Simplified to a "T"
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M19 3H5V5H11V21H13V5H19V3Z" />
  </svg>
);


export default function ContactPage() {
  const { showAssistantMessage } = useAssistant();

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    showAssistantMessage({
      title: "Formulario Enviado (Simulación)",
      message: "¡Gracias por tu mensaje! Nos pondremos en contacto contigo pronto.",
    });
    // Add actual form submission logic here
  };

  return (
    <div className="space-y-12">
      <PageHeaderBanner
        title="Contáctanos"
        description="Estamos aquí para ayudarte con tus preguntas, pedidos o compras."
        imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
        dataAiHint="soporte cliente"
      />

      <div className="grid md:grid-cols-2 gap-8 items-start">
        {/* Contact Information */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl">Información de Contacto</CardTitle>
            <CardDescription>Puedes encontrarnos en:</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <Phone className="h-5 w-5 mt-1 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-semibold">Teléfonos / WhatsApp</h3>
                <p className="text-muted-foreground">
                  Daniel Arriaga (CEO): <a href="tel:+527711256832" className="hover:text-accent transition-colors">+52 77 1125 6832</a>
                  {' '}
                  <a href="https://wa.me/527711256832" target="_blank" rel="noopener noreferrer" className="text-green-600 hover:text-green-500 transition-colors inline-flex items-center text-sm">
                    (<MessageCircle className="h-3 w-3 mr-1 inline-block"/>WhatsApp)
                  </a>
                </p>
                <p className="text-muted-foreground mt-1">
                  Tania Jiménez (CEO): <a href="tel:+527712581579" className="hover:text-accent transition-colors">+52 77 1258 1579</a>
                  {' '}
                  <a href="https://wa.me/527712581579" target="_blank" rel="noopener noreferrer" className="text-green-600 hover:text-green-500 transition-colors inline-flex items-center text-sm">
                    (<MessageCircle className="h-3 w-3 mr-1 inline-block"/>WhatsApp)
                  </a>
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Mail className="h-5 w-5 mt-1 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-semibold">Correo Electrónico</h3>
                <a href="mailto:klz.vieja@gmail.com" className="text-muted-foreground hover:text-accent transition-colors">
                  klz.vieja@gmail.com
                </a>
                <br />
                <a href="mailto:kalceta.vieja@gmail.com" className="text-muted-foreground hover:text-accent transition-colors">
                  kalceta.vieja@gmail.com
                </a>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 mt-1 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-semibold">Nuestra Tienda</h3>
                <div className="text-muted-foreground">
                  <p className="font-medium">Kal-Z-Vieja (Centro):</p>
                  <a
                    href="https://maps.app.goo.gl/bXZLSTs5xcW7R1Av8"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-accent transition-colors inline-flex items-center"
                  >
                    Calle Allende #324, Col Centro Pach, Hgo.
                    <ExternalLink className="h-3 w-3 ml-1" />
                  </a>
                </div>
              </div>
            </div>
             <div className="flex items-start gap-3">
              <MessageCircle className="h-5 w-5 mt-1 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-semibold">Redes Sociales</h3>
                <div className="flex space-x-3 mt-1">
                  <Link href="https://wa.me/527711256832" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp de Daniel Arriaga" className="text-muted-foreground hover:text-accent">
                     <MessageCircle className="h-6 w-6" />
                  </Link>
                  <Link href="https://www.facebook.com/share/1EdRR8bBcY/" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="text-muted-foreground hover:text-accent">
                    <Facebook className="h-6 w-6" />
                  </Link>
                  <Link href="https://www.instagram.com/kalzvieja?igsh=MWk4MnJtZXBpMmUxeg==" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-muted-foreground hover:text-accent">
                    <Instagram className="h-6 w-6" />
                  </Link>
                  <Link href="https://www.tiktok.com/@kalz.vieja?_t=ZS-8z03tZgzQXK&_r=1" target="_blank" rel="noopener noreferrer" aria-label="TikTok" className="text-muted-foreground hover:text-accent">
                    <TikTokIcon className="h-6 w-6" />
                  </Link>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Form */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl">Envíanos un Mensaje</CardTitle>
            <CardDescription>Completa el formulario y te responderemos lo antes posible.</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Nombre</Label>
                  <Input id="name" placeholder="Tu nombre completo" required />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="email">Correo Electrónico</Label>
                  <Input id="email" type="email" placeholder="tu@correo.com" required />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="subject">Asunto</Label>
                <Input id="subject" placeholder="Motivo de tu contacto" required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="message">Mensaje</Label>
                <Textarea id="message" placeholder="Escribe tu mensaje aquí..." rows={5} required />
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                <Send className="mr-2 h-4 w-4" /> Enviar Mensaje
              </Button>
            </CardContent>
          </form>
        </Card>
      </div>
    </div>
  );
}
