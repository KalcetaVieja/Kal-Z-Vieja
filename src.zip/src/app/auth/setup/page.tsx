'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Palette, User, MapPin, MessageCircle, Check } from 'lucide-react';
import { HighlightK } from '@/components/layout/highlight-k';
import { useLanguage } from '@/context/language-context';

const mexicanStates = [
  'Aguascalientes', 'Baja California', 'Baja California Sur', 'Campeche', 'Chiapas', 'Chihuahua', 'Ciudad de México', 'Coahuila', 'Colima', 'Durango', 'Guanajuato', 'Guerrero', 'Hidalgo', 'Jalisco', 'México', 'Michoacán', 'Morelos', 'Nayarit', 'Nuevo León', 'Oaxaca', 'Puebla', 'Querétaro', 'Quintana Roo', 'San Luis Potosí', 'Sinaloa', 'Sonora', 'Tabasco', 'Tamaulipas', 'Tlaxcala', 'Veracruz', 'Yucatán', 'Zacatecas'
];

export default function SetupPage() {
  const router = useRouter();
  const { setTheme } = useTheme();
  const { toast } = useToast();
  const { setIsLoadingPage } = useLanguage();
  const [displayName, setDisplayName] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [pin, setPin] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState('tornasol');

  useEffect(() => {
    // Ensure user is "logged in" for prototype
    if (localStorage.getItem('isLoggedIn') !== 'true') {
      setIsLoadingPage(true);
      router.replace('/auth/login');
    }
  }, [router, setIsLoadingPage]);

  const handleVerifyPin = () => {
    // Simulate PIN verification
    if (pin === '1234') {
      setIsVerified(true);
      toast({ title: 'WhatsApp Verificado', description: 'Tu número ha sido verificado con éxito.' });
    } else {
      toast({ title: 'PIN Incorrecto', description: 'El PIN ingresado no es válido. Inténtalo de nuevo.', variant: 'destructive' });
    }
  };

  const handleFinishSetup = () => {
    if (!displayName || !selectedState || !isVerified) {
      toast({
        title: 'Faltan datos',
        description: 'Por favor, completa tu nombre, estado y verifica tu WhatsApp.',
        variant: 'destructive',
      });
      return;
    }

    // Apply settings
    setTheme(selectedTheme);

    // Save settings (simulation)
    localStorage.setItem('userProfileName', displayName);
    localStorage.setItem('userState', selectedState);
    localStorage.setItem('userTheme', selectedTheme);

    setIsLoadingPage(true);
    toast({ title: '¡Configuración Kompletada!', description: `Bienvenido a Kal-Z-Vieja, ${displayName}!` });
    router.push('/home');
  };

  return (
    <div className={`flex items-center justify-center min-h-screen bg-transparent p-4 ${selectedTheme}`}>
      <Card 
        className="w-full max-w-sm bg-card/80 backdrop-blur-sm card-iridescent rounded-2xl"
      >
        <CardHeader className="p-4">
          <CardTitle className="text-2xl font-bold text-center">
            <HighlightK text="Kompleta tu Perfil" />
          </CardTitle>
          <CardDescription className="text-center">
            Solo unos pasos más para empezar a Krear.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 p-4 pt-0">
          <div className="space-y-2">
            <Label htmlFor="displayName" className="flex items-center"><User className="mr-2 h-4 w-4" /> Nombre de Perfil</Label>
            <Input id="displayName" placeholder="¿Kómo te llamaremos?" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="state" className="flex items-center"><MapPin className="mr-2 h-4 w-4" /> ¿De dónde nos visitas?</Label>
            <Select onValueChange={setSelectedState} value={selectedState}>
              <SelectTrigger id="state">
                <SelectValue placeholder="Selecciona tu estado..." />
              </SelectTrigger>
              <SelectContent>
                {mexicanStates.map(state => <SelectItem key={state} value={state}>{state}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
             <Label htmlFor="whatsapp" className="flex items-center"><MessageCircle className="mr-2 h-4 w-4" /> Verificación de WhatsApp</Label>
            <div className="flex gap-2">
                <Input id="whatsapp" type="tel" placeholder="Tu número de WhatsApp" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} disabled={isVerified} />
                <Input type="text" placeholder="PIN" maxLength={4} value={pin} onChange={(e) => setPin(e.target.value)} disabled={isVerified || !whatsapp} className="w-20"/>
                <Button onClick={handleVerifyPin} disabled={isVerified || !pin || pin.length < 4} variant={isVerified ? "default" : "outline"}>
                    {isVerified ? <Check className="h-5 w-5"/> : 'Verificar'}
                </Button>
            </div>
            <p className="text-xs text-muted-foreground">Te enviaremos un código a tu WhatsApp (simulación: usa '1234').</p>
          </div>
          
          <div className="space-y-3">
             <Label className="flex items-center"><Palette className="mr-2 h-4 w-4" /> Elige tu Tema Favorito</Label>
             <RadioGroup defaultValue="tornasol" onValueChange={(value) => setSelectedTheme(value as 'vieja' | 'tornasol' | 'green')} className="grid grid-cols-3 gap-2">
                <div>
                  <RadioGroupItem value="vieja" id="t-vieja" className="peer sr-only" />
                  <Label htmlFor="t-vieja" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-3 text-sm hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">Vieja</Label>
                </div>
                <div>
                  <RadioGroupItem value="tornasol" id="t-tornasol" className="peer sr-only" />
                  <Label htmlFor="t-tornasol" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-3 text-sm hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">Tornasol</Label>
                </div>
                 <div>
                  <RadioGroupItem value="green" id="t-green" className="peer sr-only" />
                  <Label htmlFor="t-green" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-3 text-sm hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">Green</Label>
                </div>
             </RadioGroup>
          </div>
          
          <Button onClick={handleFinishSetup} className="w-full text-lg h-12">
            Guardar y Entrar a Kal-Z-Vieja
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
