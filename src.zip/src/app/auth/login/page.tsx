
"use client";

import { SocialLoginButtons } from "@/components/auth/social-login-buttons"
import Image from "next/image";
import Link from "next/link";
import { HighlightK } from "@/components/layout/highlight-k";
import { useTheme } from "next-themes";
import { useState, useEffect } from "react";

export default function LoginPage() {
  const { theme } = useTheme();
  const [logoSrc, setLogoSrc] = useState("/images/Logos/kalZlogin.png");

  useEffect(() => {
    const getLogo = () => {
      const cacheBust = '?v=6';
      switch(theme) {
        case 'green':
          return `/images/Logos/logokalZ.png${cacheBust}`;
        case 'tornasol':
          return `/images/Logos/logo8bit.png${cacheBust}`;
        case 'vieja':
          return `/images/Logos/logo%20grises.png${cacheBust}`;
        default:
          return `/images/Logos/kalZlogin.png${cacheBust}`;
      }
    }
    setLogoSrc(getLogo());
  }, [theme]);

  return (
    <div className="flex flex-col items-center justify-start min-h-screen bg-transparent p-4 pt-20 sm:pt-24 space-y-8">
       <Link href="/" className="inline-block mx-auto">
         <Image 
            src={logoSrc} 
            alt="Logo de Kal-Z-Vieja"
            width={180} 
            height={55} 
            className="h-auto title-float" 
            priority={true}
            data-ai-hint="logo marca"
          />
      </Link>
      
      <div className="text-center">
        <h1 className="text-4xl font-bold text-foreground">
          <HighlightK text="Bienvenido a Kal-Z-Vieja"/>
        </h1>
        <p className="text-lg text-muted-foreground mt-2">
          <HighlightK text="Inicia sesión para Komenzar."/>
        </p>
      </div>
      
      <div className="w-full max-w-md flex flex-col items-center gap-8">
        <SocialLoginButtons />
        
        <div className="flex justify-center w-full">
          <Image 
            src="/videos/iniciosesion.gif" 
            alt="Animación de inicio de sesión" 
            width={220} 
            height={220} 
            unoptimized={true}
            className="h-auto rounded-lg shadow-sm"
            data-ai-hint="animacion bienvenida"
          />
        </div>
      </div>

      <p className="mt-6 text-center text-xs text-muted-foreground px-2 absolute bottom-8">
        Al continuar, aceptas nuestros{" "}
        <Link href="/terms" className="underline hover:text-accent">
          Términos de Servicio
        </Link>{" "}
        y{" "}
        <Link href="/privacy" className="underline hover:text-accent">
          Política de Privacidad
        </Link>
        .
      </p>
    </div>
  )
}
