
'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Palette } from 'lucide-react';
import { HighlightK } from '@/components/layout/highlight-k';
import { useLanguage } from '@/context/language-context';

export default function GuestSetupPage() {
  const router = useRouter();
  const { setTheme } = useTheme();
  const { toast } = useToast();
  const { setIsLoadingPage } = useLanguage();
  const [selectedTheme, setSelectedTheme] = useState('tornasol');

  useEffect(() => {
    // Ensure user is "logged in" for prototype
    if (localStorage.getItem('isLoggedIn') !== 'true') {
      setIsLoadingPage(true);
      router.replace('/auth/login');
    }
  }, [router, setIsLoadingPage]);

  const handleFinishSetup = () => {
    // Apply settings
    setTheme(selectedTheme);

    // Save settings (simulation)
    localStorage.setItem('userTheme', selectedTheme);
    localStorage.setItem('userProfileName', 'Invitado'); // Set a default guest name

    setIsLoadingPage(true);
    toast({ title: '¡Tema seleccionado!', description: `¡Bienvenido a Kal-Z-Vieja!` });
    router.push('/home');
  };

  return (
    <div className={`flex items-center justify-center min-h-screen bg-transparent p-4 ${selectedTheme}`}>
      <Card 
        className="w-full max-w-sm bg-card/80 backdrop-blur-sm card-iridescent rounded-2xl"
      >
        <CardHeader className="p-4">
          <CardTitle className="text-2xl font-bold text-center">
            <HighlightK text="Elige tu Tema" />
          </CardTitle>
          <CardDescription className="text-center">
            Personaliza tu experiencia visual.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 p-4 pt-0">
          <div className="space-y-3">
             <Label className="flex items-center justify-center"><Palette className="mr-2 h-4 w-4" /> Elige tu Tema Favorito</Label>
             <RadioGroup defaultValue="tornasol" onValueChange={(value) => setSelectedTheme(value as 'vieja' | 'tornasol' | 'green')} className="grid grid-cols-3 gap-2">
                <div>
                  <RadioGroupItem value="vieja" id="t-vieja" className="peer sr-only" />
                  <Label htmlFor="t-vieja" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-3 text-sm hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">Vieja</Label>
                </div>
                <div>
                  <RadioGroupItem value="tornasol" id="t-tornasol" className="peer sr-only" />
                  <Label htmlFor="t-tornasol" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-3 text-sm hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">Tornasol</Label>
                </div>
                 <div>
                  <RadioGroupItem value="green" id="t-green" className="peer sr-only" />
                  <Label htmlFor="t-green" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-3 text-sm hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">Green</Label>
                </div>
             </RadioGroup>
          </div>
          
          <Button onClick={handleFinishSetup} className="w-full text-lg h-12">
            Entrar a Kal-Z-Vieja
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
