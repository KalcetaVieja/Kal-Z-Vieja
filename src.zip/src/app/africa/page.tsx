
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { CassetteTape } from "lucide-react";

export default function AfricaPage() {
  return (
    <div className="space-y-12">
      <PageHeaderBanner
        title="Colección África"
        description="Esta colección no está disponible por el momento."
        imageUrl="https://picsum.photos/seed/africabanner/1200/400"
        dataAiHint="sabana africana atardecer"
      />

       <div className="text-center text-muted-foreground py-10 my-8 space-y-4">
            <CassetteTape className="h-16 w-16 mx-auto" />
            <p>Esta colección no está disponible por el momento.</p>
            <p className="text-xs">Vuelve a sintonizar pronto.</p>
        </div>
    </div>
  );
}
