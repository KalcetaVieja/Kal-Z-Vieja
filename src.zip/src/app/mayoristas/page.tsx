"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Send, Building, DollarSign, CheckCircle, Package } from "lucide-react";
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { useAssistant } from "@/context/assistant-context";

export default function MayoristasPage() {
  const { showAssistantMessage } = useAssistant();

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    showAssistantMessage({
      title: "Solicitud Recibida (Simulación)",
      message: "¡Gracias por tu interés! Nos pondremos en contacto contigo pronto para discutir las oportunidades de venta al por mayor.",
    });
    // Reset form logic would go here
  };

  return (
    <div className="space-y-12">
      <PageHeaderBanner
        title="Ventas al por Mayor"
        description="Conviértete en distribuidor de Kal-Z-Vieja y lleva nuestros diseños únicos a más personas."
        imageUrl="https://picsum.photos/seed/mayoristas/1200/400"
        dataAiHint="negocio distribucion"
      />

      <div className="grid md:grid-cols-2 gap-8 items-start">
        {/* Benefits Section */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <Package className="h-6 w-6 text-primary" />
              Beneficios para Mayoristas
            </CardTitle>
            <CardDescription>Al unirte a nuestro programa, obtienes:</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <DollarSign className="h-5 w-5 mt-1 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-semibold">Precios Preferenciales</h3>
                <p className="text-muted-foreground text-sm">Accede a descuentos significativos por volumen para maximizar tu margen de ganancia.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 mt-1 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-semibold">Acceso a Catálogo Exclusivo</h3>
                <p className="text-muted-foreground text-sm">Sé el primero en conocer y adquirir nuestros nuevos lanzamientos y colecciones de edición limitada.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Building className="h-5 w-5 mt-1 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-semibold">Soporte Dedicado</h3>
                <p className="text-muted-foreground text-sm">Te asignaremos un asesor para ayudarte con tus pedidos, logística y estrategias de venta.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Inquiry Form */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl">Solicita Información</CardTitle>
            <CardDescription>Completa el formulario para iniciar el proceso. Nos pondremos en contacto a la brevedad.</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="companyName">Nombre de la Empresa</Label>
                  <Input id="companyName" placeholder="Tu empresa S.A. de C.V." required />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="contactName">Nombre de Contacto</Label>
                  <Input id="contactName" placeholder="Tu nombre completo" required />
                </div>
              </div>
               <div className="space-y-1.5">
                  <Label htmlFor="email">Correo Electrónico</Label>
                  <Input id="email" type="email" placeholder="tu@empresa.com" required />
                </div>
              <div className="space-y-1.5">
                <Label htmlFor="message">Mensaje</Label>
                <Textarea id="message" placeholder="Cuéntanos sobre tu negocio y por qué te interesa ser distribuidor..." rows={4} required />
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                <Send className="mr-2 h-4 w-4" /> Enviar Solicitud
              </Button>
            </CardContent>
          </form>
        </Card>
      </div>
    </div>
  );
}
