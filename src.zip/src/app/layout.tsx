"use client";

import type { ReactNode, MouseEvent } from 'react';
import React, { useState, useEffect } from 'react';
import { GeistMono } from 'geist/font/mono';
import { VT323, Advent_Pro, Patrick_Hand } from 'next/font/google';
import './globals.css';
import { ThemeProvider } from "@/components/layout/theme-provider";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Toaster } from "@/components/ui/toaster";
import { LanguageProvider, useLanguage } from '@/context/language-context';
import { AiPageAssistant } from '@/components/assistant/ai-page-assistant';
import { PageTransitionLoader } from '@/components/layout/page-transition-loader';
import ClientSpaceBackground from '@/components/layout/client-space-background';
import { ScrollToTopButton } from '@/components/shared/scroll-to-top-button';
import { AssistantProvider } from '@/context/assistant-context';
import { MyLooksProvider } from '@/context/my-looks-context';
import CursorTrail from '@/components/layout/cursor-trail';
import { NavigationHistoryProvider, useNavigationHistory } from '@/context/navigation-history-context';
import GuestWelcomeAnimation from '@/components/layout/GuestWelcomeAnimation';
import { PageLoader } from '@/components/layout/page-loader';

const geistMono = GeistMono;

const vt323 = VT323({
  subsets: ['latin'],
  weight: ['400'],
  variable: '--font-vt323',
});

const adventPro = Advent_Pro({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-advent-pro',
});

const patrickHand = Patrick_Hand({
  subsets: ['latin'],
  weight: ['400'],
  variable: '--font-patrick-hand',
});

const pathTitleMap: Record<string, string> = {
    '/home': 'Página Principal',
    '/catalog': 'Catálogo',
    '/kal-z-ai': 'Kal-Z-AI Studio',
    '/recompensas': 'Recompensas',
    '/viral': 'Galería Viral',
    '/viral/mis-looks': 'Mis Looks',
    '/cart': 'Carrito de Compras',
    '/profile': 'Mi Perfil',
    '/contact': 'Contacto',
    '/mayoristas': 'Venta por Mayor',
    '/los-90s': 'Colección Los 90s',
    '/africa': 'Colección África',
    '/admin/deliveries': 'Gestión de Entregas',
    '/master-panel': 'Panel Maestro',
    '/auth/setup': 'Configuración de Perfil',
    '/virtual-try-on': 'Probador Virtual',
    '/terms': 'Términos de Servicio',
    '/privacy': 'Política de Privacidad',
};

function getTitleForPath(path: string): string | null {
    if (pathTitleMap[path]) {
        return pathTitleMap[path];
    }
    if (path.startsWith('/catalog/')) {
        return 'Detalle de Producto';
    }
    return null;
}

function ClientProviders({ children }: { children: React.ReactNode }) {
  const { setIsLoadingPage, pathname } = useLanguage();
  const { addHistoryEntry } = useNavigationHistory();
  const currentPath = pathname;

  useEffect(() => {
    // Apply font size from localStorage on initial load
    const savedFontSize = localStorage.getItem('userFontSize');
    if (savedFontSize) {
      document.documentElement.style.fontSize = `${savedFontSize}px`;
    }
  }, []);
  
  useEffect(() => {
      if (pathname) {
          const title = getTitleForPath(pathname);
          // Do not add auth pages to history
          if (title && !pathname.startsWith('/auth') && pathname !== '/') {
              addHistoryEntry({ path: pathname, title });
          }
      }
  }, [pathname, addHistoryEntry]);

  const handleLinkClick = (e: MouseEvent<HTMLDivElement>) => {
    let target = e.target as HTMLElement;
    while (target && target.tagName !== 'A') {
      target = target.parentElement as HTMLElement;
    }

    if (target && target.tagName === 'A') {
      const href = target.getAttribute('href');
      if (href && href.startsWith('/') && href !== currentPath) {
        setIsLoadingPage(true);
      }
    }
  };
  
  const showHeaderAndFooter = currentPath !== '/auth/login' && currentPath !== '/' && currentPath !== '/auth/setup';

  return (
    <div id="page-content-wrapper" onClickCapture={handleLinkClick}>
      {showHeaderAndFooter && <Header />}
      <main className="flex-grow py-4 sm:py-8 bg-transparent">
        {children}
      </main>
       {showHeaderAndFooter && <Footer />}
      <Toaster />
      {showHeaderAndFooter && <AiPageAssistant />}
      <PageTransitionLoader />
      <PageLoader />
      {showHeaderAndFooter && <ScrollToTopButton />}
      <GuestWelcomeAnimation />
    </div>
  );
}

// RootLayout is now a client component that sets up providers.
export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistMono.variable} ${vt323.variable} ${adventPro.variable} ${patrickHand.variable} font-sans antialiased flex flex-col min-h-screen text-foreground`}
        suppressHydrationWarning
      >
        <ClientSpaceBackground />
        <ThemeProvider
          attribute="class"
          defaultTheme="vieja"
          enableSystem
          disableTransitionOnChange
          themes={['dark', 'light', 'system', 'vieja', 'tornasol', 'green']}
        >
          <LanguageProvider>
            <AssistantProvider>
              <MyLooksProvider>
                <NavigationHistoryProvider>
                  <ClientProviders>{children}</ClientProviders>
                </NavigationHistoryProvider>
                <CursorTrail />
              </MyLooksProvider>
            </AssistantProvider>
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
