
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { useLanguage } from '@/context/language-context';

export default function SplashPage() {
  const router = useRouter();
  const { setIsLoadingPage } = useLanguage();

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

    const timer = setTimeout(() => {
      setIsLoadingPage(true);
      if (isLoggedIn) {
        router.replace('/home');
      } else {
        router.replace('/auth/login');
      }
    }, 4000); // 4 seconds for the splash screen

    return () => clearTimeout(timer);
  }, [router, setIsLoadingPage]);

  return (
    <div className="flex items-center justify-center h-screen w-screen fixed inset-0 bg-background z-[9999]">
      <Image
        src="/animations/splash.gif"
        alt="Animación de bienvenida de Kal-Z-Vieja"
        fill
        className="object-cover"
        unoptimized={true} 
        priority
        data-ai-hint="logo animado"
      />
    </div>
  );
}
