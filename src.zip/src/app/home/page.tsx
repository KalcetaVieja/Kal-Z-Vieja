// HomePage.tsx
'use client';

import Link from "next/link"
import * as React from "react";

import { Button } from "@/components/ui/button"
import { Instagram, ThumbsUp, RefreshCw, Loader2, Gift, Shirt, Truck, Crown, ArrowRight, Heart, BookOpen, Printer, Palette, MessageCircle } from "lucide-react";
import { useLanguage } from "@/context/language-context";
import { HighlightK } from "@/components/layout/highlight-k"; 
import { HomeCarouselWrapper } from "@/components/layout/home-carousel";
import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { PilonCarousel } from "@/components/shared/pilon-carousel";
import { Separator } from "@/components/ui/separator";
import { ProductCard } from "@/components/catalog/product-card";
import { Badge } from "@/components/ui/badge";
import placeholderImages from '@/lib/placeholder-images.json';
import { mockProducts } from "@/data/mock";
import type { Product } from "@/types";

const pageTranslations = {
  es: {
    readyToCreate: "¿Listo para KREAR?",
    readyToCreateDesc: "Usa nuestro KAL-Z-STUDIO y las sugerencias de diseño IA para llevar tus ideas al siguiente nivel.",
    startCustomizing: "¡Empieza a Personalizar!",
    
    loadingPage: "Cargando...",
    loadingHomePage: "Cargando página principal...",
    followUsTitle: "Síguenos en Redes Sociales",
    followUsDesc: "Entérate de las últimas novedades, promociones y diseños de la comunidad.",
    followUsInstruction: "Pasa el cursor (o toca en móvil) sobre un botón para ver una vista previa de nuestras redes.",
    viewOnFacebook: "Ver en Facebook",
    viewOnInstagram: "Ver en Instagram",
    viewOnTikTok: "Ver en TikTok",

    likeOnFacebook: "Me Gusta",
    followOnInstagram: "Seguir",
    followOnTikTok: "Seguir",
    specialOfferTitle: "Ruleta de Ofertas del Mes",
    specialOfferDesc: "¡Productos seleccionados con 20% de descuento este mes! Gira para ver algunos.",
    specialOfferPrice: "$299 MXN",
    freeShipping: "Envío Gratis",
    promoText: "¡Cada giro revela una nueva combinación! Aprovecha esta promoción única.",
    claimOffer: "¡Añadir al Carrito!",
    spinRoulette: "Girar Ruleta",

    servicesTitle: "Nuestros Servicios",
    servicesDesc: "Ofrecemos soluciones personalizadas para todas tus necesidades textiles.",
    dtfTitle: "DTF Impresión Mayorista",
    dtfDesc: "Servicios de impresión de alta calidad para grandes volúmenes.",
    uniformsTitle: "Uniformes",
    uniformsDesc: "Diseño y fabricación de uniformes para empresas y equipos.",
    customizeTitle: "Personaliza tu Camiseta",
    customizeDesc: "Usa nuestra IA y estudio para crear diseños únicos.",
    contactTitle: "Contacto",
    contactDesc: "¿Tienes dudas? Ponte en contacto con nuestro equipo.",
  },
  en: {
    readyToCreate: "Ready to KREATE?",
    readyToCreateDesc: "Use our KAL-Z-STUDIO and AI design suggestions to take your ideas to the next level.",
    startCustomizing: "Start Kustomizing!",
    
    loadingPage: "Loading...",
    loadingHomePage: "Loading homepage...",
    followUsTitle: "Follow Us on Social Media",
    followUsDesc: "Find out about the latest news, promotions, and community designs.",
    followUsInstruction: "Hover (or tap on mobile) over a button to see a preview of our social media.",
    viewOnFacebook: "View on Facebook",
    viewOnInstagram: "View on Instagram",
    viewOnTikTok: "View on TikTok",
    
    likeOnFacebook: "Like Page",
    followOnInstagram: "Follow",
    followOnTikTok: "Follow",
    featuredProductsTitle: "Featured ProduKts",
    featuredProductsDesc: "A special selection of our most popular designs from Kal-Z-Vieja.",

    specialOfferTitle: "Offer Roulette of the Month",
    specialOfferDesc: "Selected products with 20% off this month! Spin to see some.",
    specialOfferPrice: "$299 MXN",
    freeShipping: "Free Shipping",
    promoText: "Each spin reveals a new combination! Take advantage of this unique promotion.",
    claimOffer: "Add to Cart!",
    spinRoulette: "Spin Roulette",

    servicesTitle: "Our Services",
    servicesDesc: "We offer customized solutions for all your textile needs.",
    dtfTitle: "DTF Wholesale Printing",
    dtfDesc: "High-quality printing services for large volumes.",
    uniformsTitle: "Uniforms",
    uniformsDesc: "Design and manufacturing of uniforms for companies and teams.",
    customizeTitle: "Customize your T-shirt",
    customizeDesc: "Use our AI and studio to create unique designs.",
    contactTitle: "Contact",
    contactDesc: "Have questions? Get in touch with our team.",
  }
};

const TikTokIcon = ({ className }: { className?: string }) => (
  <svg
    className={cn("lucide", className)}
    viewBox="0 0 24 24"
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M19 3H5V5H11V21H13V5H19V3Z" />
  </svg>
);

export default function HomePage() {
  const [isClient, setIsClient] = React.useState(false);
  const languageContext = useLanguage();
  const { toast } = useToast();
  const [isFacebookOpen, setIsFacebookOpen] = React.useState(false);
  const [isInstagramOpen, setIsInstagramOpen] = React.useState(false);
  const [isTikTokOpen, setIsTikTokOpen] = React.useState(false);

  React.useEffect(() => {
    setIsClient(true);
  }, []);
  
  const { locale } = languageContext || { locale: 'es' };

  const t = (key: keyof typeof pageTranslations.es) => {
    let text = pageTranslations[locale]?.[key] || pageTranslations['es']?.[key] || String(key);
    
    const isTitleOrProminentLabel = 
        key.toLowerCase().includes("title") || 
        key === "readyToCreate" ||
        key === "dtfTitle" ||
        key === "uniformsTitle" ||
        key === "customizeTitle" ||
        key === "contactTitle";

    if (isTitleOrProminentLabel) {
      text = text.replace(/Catálogo/gi, "KATÁLOGO")
                 .replace(/Recompensas/gi, "REKOMPENSAS")
                 .replace(/Krear/gi, "KREAR")
                 .replace(/Kal-Z-Vieja/gi, "KAL-Z-VIEJA")
                 .replace(/Kal-Z-Studio/gi, "KAL-Z-STUDIO")
                 .replace(/Khe Viral/gi, "KHE VIRAL")
                 .replace(/Contacto/gi, "KONTAKTO");
      text = text.replace(/K/g, "K").replace(/k/g, "K");
    } else {
      text = text.replace(/Katálogo/gi, "Catálogo")
                 .replace(/Rekompensas/gi, "Recompensas")
                 .replace(/Krear/gi, "Crear");
    }
    return text;
  }
  
  if (!isClient || !languageContext) { 
    return (
      <div className="flex flex-col justify-center items-center min-h-[calc(100vh-20rem)] space-y-4">
        <Image src="/images/splash.gif" alt="Cargando..." width={128} height={128} unoptimized />
        <p className="text-muted-foreground">{t('loadingPage')}</p>
      </div>
    );
  }

  const services = [
    {
      title: t('dtfTitle'),
      description: t('dtfDesc'),
      icon: Printer,
      href: "/mayoristas",
    },
    {
      title: t('uniformsTitle'),
      description: t('uniformsDesc'),
      icon: Shirt,
      href: "/catalog",
    },
    {
      title: t('customizeTitle'),
      description: t('customizeDesc'),
      icon: Palette,
      href: "/kal-z-ai",
    },
    {
      title: t('contactTitle'),
      description: t('contactDesc'),
      icon: MessageCircle,
      href: "/contact",
    },
  ];

  return (
    <div className="space-y-16 md:space-y-24">
      <HomeCarouselWrapper />

      {/* Nuestros Servicios Section */}
      <section className="px-4 md:px-8">
          <Card className="p-4 sm:p-6 shadow-xl bg-card/50">
              <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold">
                  <HighlightK text={t('servicesTitle')} />
                  </h2>
                  <p className="text-muted-foreground max-w-2xl mx-auto mt-2">
                  <HighlightK text={t('servicesDesc')} />
                  </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {services.map((service) => {
                    const Icon = service.icon;
                    return (
                      <Link key={service.title} href={service.href}>
                        <Card className="h-full hover:border-primary transition-all duration-300 group cursor-pointer overflow-hidden border-2 border-transparent bg-muted/20">
                          <CardHeader className="flex flex-col items-center text-center pb-2">
                            <div className="p-4 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors mb-3">
                              <Icon className="h-10 w-10 text-primary" />
                            </div>
                            <CardTitle className="text-xl group-hover:text-primary transition-colors">
                              <HighlightK text={service.title} />
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="text-center text-muted-foreground text-sm">
                            {service.description}
                          </CardContent>
                        </Card>
                      </Link>
                    )
                  })}
              </div>
          </Card>
      </section>

      <section className="container mx-auto px-4 space-y-8">
        <Card className="card-iridescent shadow-lg overflow-hidden">
            <CardContent className="p-6 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
                <Gift className="h-16 w-16 text-primary flex-shrink-0" />
                <div className="flex-grow">
                    <h3 className="text-2xl font-bold"><HighlightK text="¡Descubre la Ruleta de Ofertas!" /></h3>
                    <p className="text-muted-foreground mt-1">
                        Gira la ruleta en nuestra sección de <HighlightK text="Rekompensas" /> y gana descuentos exclusivos en productos seleccionados cada mes.
                    </p>
                </div>
                <Button asChild size="lg" className="flex-shrink-0">
                    <Link href="/recompensas">
                        <ArrowRight className="mr-2 h-5 w-5" />
                        Probar Suerte
                    </Link>
                </Button>
            </CardContent>
        </Card>
        
        <Card className="shadow-lg overflow-hidden border-2 border-primary/20">
            <CardHeader className="text-center bg-muted/20 pb-4">
                <CardTitle className="text-3xl flex items-center justify-center gap-3">
                    <BookOpen className="h-8 w-8 text-primary" />
                    <HighlightK text="La Historia de este Mes" />
                </CardTitle>
                <CardDescription className="max-w-2xl mx-auto">
                    Una pequeña historia de amor que inspira nuestra promoción especial. Haz clic en las imágenes para revelarla.
                </CardDescription>
            </CardHeader>
            <CardContent className="p-4">
                 <Dialog>
                    <div className="grid grid-cols-2 gap-4">
                    {[1, 2, 3, 4].map((i) => (
                        <DialogTrigger key={i} asChild>
                            <div className="block group relative aspect-square overflow-hidden cursor-pointer rounded-lg">
                            <Image
                                src={`/images/stopmes/Ancianos${i}.png`}
                                alt={`Parte ${i} de la historia del mes`}
                                fill
                                className="object-cover transition-transform duration-300 group-hover:scale-105"
                            />
                            </div>
                        </DialogTrigger>
                    ))}
                    </div>

                    <DialogContent className="max-w-4xl bg-card/95 backdrop-blur-lg">
                    <DialogHeader>
                        <DialogTitle className="text-2xl flex items-center gap-2">
                        <Heart className="h-6 w-6 text-primary"/>
                        Promoción: Dúo "Therian"
                        </DialogTitle>
                        <DialogDescription>
                        ¡Lleva dos camisetas con los diseños exclusivos "I Love Therian's" y "Cuidado con el Therian" a un precio especial!
                        </DialogDescription>
                    </DialogHeader>

                    <div className="grid md:grid-cols-2 gap-6 items-start py-4">
                        <div className="space-y-4">
                            <h3 className="font-semibold">Nuevos Diseños:</h3>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2 text-center">
                                    <div className="aspect-square relative rounded-md bg-muted/30 overflow-hidden">
                                        <Image src={placeholderImages.therian1.src} alt={placeholderImages.therian1.alt} fill className="object-contain p-2" data-ai-hint={placeholderImages.therian1.dataAiHint} />
                                    </div>
                                    <p className="text-xs font-medium">"I Love Therian's"</p>
                                </div>
                                <div className="space-y-2 text-center">
                                    <div className="aspect-square relative rounded-md bg-muted/30 overflow-hidden">
                                        <Image src={placeholderImages.therian2.src} alt={placeholderImages.therian2.alt} fill className="object-contain p-2" data-ai-hint={placeholderImages.therian2.dataAiHint}/>
                                    </div>
                                    <p className="text-xs font-medium">"Cuidado con el Therian"</p>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h3 className="font-semibold">Detalles de la Promoción:</h3>
                            <p className="text-sm text-muted-foreground">
                                Lleva un dúo de camisetas por un precio especial. Elige el color (blanco o negro) y el diseño para cada una.
                            </p>
                            <div className="p-4 border rounded-lg bg-background/50">
                                <p className="text-2xl font-bold text-accent">$449.90 MXN <Badge variant="destructive">10% OFF</Badge></p>
                                <p className="text-sm text-muted-foreground line-through">Precio regular: $499.80 MXN</p>
                            </div>
                        </div>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
                        <DialogClose asChild>
                            <Button onClick={() => toast({ title: "Dúo Añadido al Carrito (Simulación)", description: "Revisa tu carrito para finalizar la compra." })} className="flex-1">
                            <Shirt className="mr-2 h-4 w-4" /> Agregar al Carrito
                            </Button>
                        </DialogClose>
                        <DialogClose asChild>
                            <Button asChild variant="default" className="flex-1">
                            <Link href="/cart/duo-promo">
                                <ArrowRight className="mr-2 h-4 w-4" /> Comprar Dúo Ahora
                            </Link>
                            </Button>
                        </DialogClose>
                    </div>

                    </DialogContent>
                </Dialog>
            </CardContent>
        </Card>

      </section>

      <Separator className="container my-12" />

      <section className="container mx-auto px-4">
        <div className="text-center mb-8">
            <h2 className="text-3xl font-bold"><HighlightK text={t('followUsTitle')} /></h2>
            <p className="text-muted-foreground max-w-2xl mx-auto"><HighlightK text={t('followUsDesc')} /></p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
          <Dialog onOpenChange={setIsFacebookOpen}>
            <DialogTrigger asChild>
                <Button className="w-full bg-[#1877F2] hover:bg-[#1877F2]/90 text-white text-lg h-14">
                    <ThumbsUp className="mr-2"/> {t('likeOnFacebook')}
                </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl w-[90vw] h-[90vh] flex flex-col p-4">
                <DialogHeader className="flex-shrink-0">
                    <DialogTitle>Página de Facebook de Kal-Z-Vieja</DialogTitle>
                    <DialogDescription>
                        Es posible que el contenido no se muestre si Facebook bloquea la visualización en sitios externos.
                    </DialogDescription>
                </DialogHeader>
                <div className="flex-grow mt-4 border rounded-md overflow-hidden">
                    {isFacebookOpen && (
                        <iframe
                            src="https://www.facebook.com/share/1EdRR8bBcY/"
                            className="w-full h-full"
                            title="Facebook Kal-Z-Vieja"
                            sandbox="allow-scripts allow-same-origin"
                        ></iframe>
                    )}
                </div>
            </DialogContent>
          </Dialog>
            
          <Dialog onOpenChange={setIsInstagramOpen}>
              <DialogTrigger asChild>
                  <Button className="w-full bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 text-white text-lg h-14">
                      <Instagram className="mr-2"/> {t('followOnInstagram')}
                  </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl w-[90vw] h-[90vh] flex flex-col p-4">
                  <DialogHeader className="flex-shrink-0">
                      <DialogTitle>Perfil de Instagram de Kal-Z-Vieja</DialogTitle>
                      <DialogDescription>
                          Es posible que el contenido no se muestre si Instagram bloquea la visualización en sitios externos.
                      </DialogDescription>
                  </DialogHeader>
                  <div className="flex-grow mt-4 border rounded-md overflow-hidden">
                      {isInstagramOpen && (
                          <iframe
                              src="https://www.instagram.com/kalzvieja?igsh=MWk4MnJtZXBpMmUxeg=="
                              className="w-full h-full"
                              title="Instagram Kal-Z-Vieja"
                              sandbox="allow-scripts allow-same-origin"
                          ></iframe>
                      )}
                  </div>
              </DialogContent>
          </Dialog>

          <Dialog onOpenChange={setIsTikTokOpen}>
            <DialogTrigger asChild>
                <Button className="w-full bg-black text-white hover:bg-black/80 text-lg h-14 border-2 border-white">
                    <TikTokIcon className="mr-2 h-6 w-6"/> {t('followOnTikTok')}
                </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl w-[90vw] h-[90vh] flex flex-col p-4">
                <DialogHeader className="flex-shrink-0">
                    <DialogTitle>Perfil de TikTok de Kal-Z-Vieja</DialogTitle>
                    <DialogDescription>
                        Es posible que el contenido no se muestre si TikTok bloquea la visualización en sitios externos.
                    </DialogDescription>
                </DialogHeader>
                <div className="flex-grow mt-4 border rounded-md overflow-hidden">
                    {isTikTokOpen && (
                        <iframe
                            src="https://www.tiktok.com/@kalz.vieja?_t=ZS-8z03tZgzQXK&_r=1"
                            className="w-full h-full"
                            title="TikTok Kal-Z-Vieja"
                            sandbox="allow-scripts allow-same-origin"
                        ></iframe>
                    )}
                </div>
            </DialogContent>
          </Dialog>

        </div>
      </section>
      
      <div className="pt-12 container mx-auto px-4">
        <PilonCarousel />
      </div>

    </div>
  );
}
