
"use client";

import React, { useState, useMemo } from 'react';
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { VirtualTryOnBooth } from "@/components/try-on/virtual-try-on-booth";
import { PilonCarousel } from "@/components/shared/pilon-carousel";
import { mockProducts } from '@/data/mock';
import type { Product } from '@/types';

export default function VirtualTryOnPage() {
    
  // Find a default product that is try-on-able.
  const defaultProduct = useMemo(() => {
    return mockProducts.find(p => p.category.includes("Camisetas") || p.category.includes("Sudaderas"));
  }, []);

  const [customizationOptions, setCustomizationOptions] = useState(null);

  if (!defaultProduct) {
      return (
          <div className="text-center py-10">
              <p>No hay productos disponibles para la prueba virtual en este momento.</p>
          </div>
      )
  }

  return (
    <div className="space-y-12">
       <PageHeaderBanner
        title="Probador Virtual Kal-Z"
        description="¡Sube tu foto y mira cómo te quedan nuestros diseños al instante! Nuestra IA se encarga del resto."
        imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
        dataAiHint="probador virtual ia"
      />
      
      <VirtualTryOnBooth 
        product={defaultProduct}
        customizationOptions={customizationOptions} 
      />
      
      <PilonCarousel />
    </div>
  );
}
