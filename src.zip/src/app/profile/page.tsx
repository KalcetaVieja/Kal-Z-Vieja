
import { ProfileForm } from "@/components/profile/profile-form";
import { mockUserProfile } from "@/data/mock"; // Using mock data for now
import type { UserProfile as UserProfileType } from "@/types"; // Renamed to avoid conflict
import { PageHeaderBanner } from "@/components/layout/page-header-banner";

export default async function ProfilePage() {
  // In a real app, you would fetch the current user's profile data
  // For example, using Firebase Auth and Firestore
  const userProfileData: UserProfileType = mockUserProfile;

  return (
    <div className="space-y-8">
      <PageHeaderBanner
        title="Mi Perfil"
        description="Administra tu información personal y preferencias."
        imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
        dataAiHint="cuenta usuario"
      />
      
      <ProfileForm initialProfile={userProfileData} />
    </div>
  );
}
