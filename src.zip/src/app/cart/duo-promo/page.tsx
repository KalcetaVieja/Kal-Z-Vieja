// src/app/cart/duo-promo/page.tsx
'use client';

import React, { useState } from 'react';
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import Image from 'next/image';
import Link from 'next/link';
import { Shirt, Palette, Brush, ArrowRight, MessageCircle } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import placeholderImages from '@/lib/placeholder-images.json';

const DuoShirtSelector = ({ shirtNumber }: { shirtNumber: 1 | 2 }) => {
  return (
    <Card className="bg-muted/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Shirt className="h-5 w-5" /> Camiseta {shirtNumber}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label className="flex items-center gap-2"><Palette className="h-4 w-4" /> Color</Label>
          <Select defaultValue="negro">
            <SelectTrigger>
              <SelectValue placeholder="Selecciona un color" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="negro">Negro</SelectItem>
              <SelectItem value="blanco">Blanco</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label className="flex items-center gap-2"><Brush className="h-4 w-4" /> Diseño</Label>
          <Select defaultValue="love_therian">
            <SelectTrigger>
              <SelectValue placeholder="Selecciona un diseño" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="love_therian">I Love Therian's</SelectItem>
              <SelectItem value="cuidado_therian">Cuidado con el Therian</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
};

export default function DuoPromoPage() {
  return (
    <div className="space-y-8">
      <PageHeaderBanner
        title="Dúo de Camisetas 'Therian'"
        description="Finaliza la compra de tu promoción especial. ¡Elige tus camisetas y llévatelas a un precio increíble!"
        imageUrl={placeholderImages.duoPromoBanner.src}
        dataAiHint={placeholderImages.duoPromoBanner.dataAiHint}
      />

      <div className="grid lg:grid-cols-3 gap-8 items-start max-w-6xl mx-auto">
        {/* Selection Area */}
        <div className="lg:col-span-2 space-y-6">
            <h2 className="text-xl font-semibold">Elige tu Dúo Perfecto</h2>
            <div className="grid sm:grid-cols-2 gap-6">
                <DuoShirtSelector shirtNumber={1} />
                <DuoShirtSelector shirtNumber={2} />
            </div>
            
            <div className="grid grid-cols-2 gap-4 pt-6">
                 <div className="space-y-2 text-center">
                    <div className="aspect-square relative rounded-md bg-muted/30 overflow-hidden border-2">
                        <Image src={placeholderImages.therian1.src} alt={placeholderImages.therian1.alt} fill className="object-contain p-2" data-ai-hint={placeholderImages.therian1.dataAiHint} />
                    </div>
                    <p className="text-sm font-medium">"I Love Therian's"</p>
                </div>
                 <div className="space-y-2 text-center">
                    <div className="aspect-square relative rounded-md bg-muted/30 overflow-hidden border-2">
                        <Image src={placeholderImages.therian2.src} alt={placeholderImages.therian2.alt} fill className="object-contain p-2" data-ai-hint={placeholderImages.therian2.dataAiHint}/>
                    </div>
                    <p className="text-sm font-medium">"Cuidado con el Therian"</p>
                </div>
            </div>
        </div>

        {/* Summary */}
        <div className="lg:col-span-1 space-y-6 sticky top-24">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Resumen de la Promoción</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Producto:</span>
                <span className="font-semibold">Dúo de Camisetas "Therian"</span>
              </div>
              <Separator />
              <div className="flex justify-between items-baseline">
                <span className="text-muted-foreground">Precio Regular:</span>
                <span className="line-through">$499.80 MXN</span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-muted-foreground">Descuento (10%):</span>
                <span className="font-semibold text-destructive">-$49.90 MXN</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold text-2xl pt-2">
                <span>Total:</span>
                <span className="text-accent">$449.90 MXN</span>
              </div>
               <Badge variant="secondary" className="w-full justify-center py-1">¡Ahorras $49.90!</Badge>
            </CardContent>
            <CardFooter className="flex-col gap-3">
              <Button asChild className="w-full h-14 bg-green-600 hover:bg-green-700 text-white text-lg">
                  <Link href="https://wa.me/527711256832" target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="mr-2 h-5 w-5" /> Finalizar por WhatsApp
                  </Link>
              </Button>
               <Button variant="link" asChild>
                    <Link href="/catalog">&larr; Volver al Catálogo</Link>
                </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
