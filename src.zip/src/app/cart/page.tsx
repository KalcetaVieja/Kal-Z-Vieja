
"use client"

import React, { useState, useEffect } from 'react';
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, ShoppingCart, Minus, Plus, Tag, CreditCard, Info, AlertTriangle, MessageCircle } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import type { CartItem, Product } from "@/types";
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { PilonCarousel } from '@/components/shared/pilon-carousel';
import { useAssistant } from '@/context/assistant-context';
import { mockCartItems } from '@/data/mock';

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>(mockCartItems);
  const { showAssistantMessage } = useAssistant();
  
  useEffect(() => {
    // In a real app, you'd fetch cart items from a service or context
  }, []);


  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) {
      removeItem(productId);
      return;
    }
    setCartItems(items =>
      items.map(item =>
        item.productId === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const removeItem = (productId: string) => {
    const itemToRemove = cartItems.find(item => item.productId === productId);
    if (itemToRemove) {
        setCartItems(items => items.filter(item => item.productId !== productId));
        showAssistantMessage({
          title: "Artículo eliminado",
          message: `"${itemToRemove.name}" ha sido eliminado de tu carrito.`,
        });
    }
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shippingThreshold = 600;
  const shippingCost = subtotal >= shippingThreshold ? 0 : 50; // Ejemplo de costo de envío si no es gratuito
  const total = subtotal + shippingCost;

  const renderMedia = (item: CartItem) => {
    const url = item.imageUrl;
    const itemIsVideo = 'isVideo' in item ? item.isVideo : url.endsWith('.mp4');
    const objectFitClass = itemIsVideo ? "object-cover" : "object-contain";

    if (itemIsVideo) {
      return (
        <video
          src={url}
          width={72}
          height={90}
          autoPlay
          loop={true}
          muted
          playsInline
          className={`rounded-md ${objectFitClass} aspect-[4/5]`}
        />
      );
    }
    return (
      <Image
        src={url}
        alt={item.name}
        width={72}
        height={90}
        className={`rounded-md ${objectFitClass} aspect-[4/5]`}
        data-ai-hint={item.dataAiHint || "prenda ropa"}
        unoptimized={url.endsWith('.gif')}
      />
    );
  };

  if (cartItems.length === 0) {
    return (
      <div className="space-y-8">
        <PageHeaderBanner
          title="Tu Carrito de Compras"
          imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
          dataAiHint="articulos compra"
        />
        <div className="text-center py-10">
          <ShoppingCart className="h-24 w-24 mx-auto text-muted-foreground mb-6" />
          <h1 className="text-3xl font-semibold mb-4">Tu carrito está vacío</h1>
          <p className="text-muted-foreground mb-8">Parece que no has añadido nada a tu carrito todavía.</p>
          <Button asChild size="lg">
            <Link href="/catalog">Empezar a Comprar</Link>
          </Button>
        </div>
        <PilonCarousel />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeaderBanner
        title="Tu Carrito de Compras"
        imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
        dataAiHint="articulos compra"
      />

      <div className="grid lg:grid-cols-3 gap-8 items-start">
        {/* Cart Items List */}
        <div className="lg:col-span-2 space-y-4">
          {cartItems.map(item => (
            <Card key={item.productId} className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 shadow-sm">
              <div className="w-[72px] h-[90px] flex items-center justify-center bg-transparent rounded-md overflow-hidden flex-shrink-0">
                {renderMedia(item)}
              </div>
              <div className="flex-grow">
                <h3 className="font-semibold">{item.name}</h3>
                <p className="text-sm text-muted-foreground">Precio: ${item.price.toFixed(2)} MXN</p>
                {item.customization && <p className="text-xs text-accent">Personalizado</p>}
              </div>
              <div className="flex items-center gap-2 mt-2 sm:mt-0">
                <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(item.productId, item.quantity - 1)}>
                  <Minus className="h-4 w-4" />
                </Button>
                <Input type="number" value={item.quantity} readOnly className="w-12 h-8 text-center" />
                <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(item.productId, item.quantity + 1)}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <p className="font-semibold w-20 text-right mt-2 sm:mt-0">${(item.price * item.quantity).toFixed(2)}</p>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive h-8 w-8" onClick={() => removeItem(item.productId)}>
                <X className="h-5 w-5" />
              </Button>
            </Card>
          ))}
        </div>

        {/* Right Column */}
        <div className="lg:col-span-1 space-y-6">
          {/* Order Summary */}
          <Card className="shadow-lg sticky top-20">
            <CardHeader>
              <CardTitle>Resumen del Pedido</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>${subtotal.toFixed(2)} MXN</span>
              </div>
              <div className="flex justify-between">
                <span>Envío:</span>
                {shippingCost === 0 ? (
                  <span className="text-highlight-green font-semibold">Gratuito</span>
                ) : (
                  <span>${shippingCost.toFixed(2)} MXN</span>
                )}
              </div>
              {shippingCost > 0 && (
                <Alert variant="default" className="p-2 text-xs">
                  <Info className="h-3.5 w-3.5" />
                  <AlertDescription>
                    Envío gratis en compras superiores a ${shippingThreshold.toFixed(2)} MXN.
                  </AlertDescription>
                </Alert>
              )}
              <div className="flex items-center gap-2">
                <Tag className="h-5 w-5 text-muted-foreground" />
                <Input placeholder="Código de Descuento" className="h-9"/>
                <Button variant="outline" size="sm" className="h-9">Aplicar</Button>
              </div>
              <div className="flex justify-between font-bold text-lg pt-4 border-t">
                <span>Total:</span>
                <span>${total.toFixed(2)} MXN</span>
              </div>
            </CardContent>
            <CardFooter>
              <Button size="lg" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" disabled>
                <CreditCard className="mr-2 h-5 w-5" /> Proceder al Pago
              </Button>
            </CardFooter>
          </Card>

          {/* Payment Methods */}
          <Card className="shadow-lg">
              <CardHeader>
                  <CardTitle className="text-lg">Finalizar Compra</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>En Mantenimiento</AlertTitle>
                  <AlertDescription>
                    Las pasarelas de pago están en mantenimiento. Para completar tu pedido, contáctanos.
                  </AlertDescription>
                </Alert>
                <Button asChild className="w-full h-14 bg-green-600 hover:bg-green-700 text-white text-lg">
                  <Link href="https://wa.me/527711256832" target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="mr-2 h-5 w-5" /> Finalizar por WhatsApp
                  </Link>
                </Button>
              </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="py-8">
        <PilonCarousel />
      </div>

       <div className="text-center mt-8">
          <Button variant="link" asChild>
            <Link href="/catalog">&larr; Continuar Comprando</Link>
          </Button>
        </div>
    </div>
  );
}
