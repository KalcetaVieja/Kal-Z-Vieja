
import { DeliveryTable } from "@/components/admin/delivery-table";
import { mockDeliveries } from "@/data/mock"; // Using mock data for now
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { PackageSearch } from "lucide-react";


export default async function AdminDeliveriesPage() {
  // In a real app, you would fetch delivery data and protect this route
  const deliveries = mockDeliveries;

  return (
    <div className="space-y-8">
      <PageHeaderBanner
        title="Gestión de Entregas"
        description="Visualiza y actualiza el estado de las entregas."
        imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
        dataAiHint="seguimiento pedidos"
      />
      
      <DeliveryTable initialDeliveries={deliveries} />
    </div>
  );
}

// This page should ideally be protected and only accessible by admin users.
// Route protection logic (e.g., using middleware or a HOC) would be needed in a real application.
