
"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input"; // For title
import { Send, Brush, AlertTriangle, Info } from "lucide-react";
import Link from 'next/link';
import Image from 'next/image';
import { useAssistant } from '@/context/assistant-context';

export default function MasterPanelPage() {
  const router = useRouter();
  const { showAssistantMessage } = useAssistant();
  const [isMasterAdmin, setIsMasterAdmin] = useState<boolean | null>(null);

  const [pushTitle, setPushTitle] = useState('');
  const [pushMessage, setPushMessage] = useState('');
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    // Simulate auth check for prototype
    const masterAdmin = localStorage.getItem("isKalZVijaMasterAdmin") === "true";
    setIsMasterAdmin(masterAdmin);
    if (!masterAdmin && typeof window !== 'undefined') { // Check typeof window to avoid SSR issues
      // router.replace('/home'); // Redirect if not master admin
    }
  }, [router]);

  const handleSendPush = async () => {
    if (!pushTitle.trim() || !pushMessage.trim()) {
      showAssistantMessage({
        title: "Campos incompletos",
        message: "Por favor, ingresa un título y un mensaje para la notificación.",
        isError: true,
      });
      return;
    }
    setIsSending(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSending(false);
    setPushTitle('');
    setPushMessage('');
    showAssistantMessage({
      title: "Notificación Push Enviada (Simulación)",
      message: `Título: ${pushTitle}, Mensaje: ${pushMessage}`,
    });
    // Actual push notification logic would go here
  };

  if (isMasterAdmin === null) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-10rem)]">
        <p>Verificando acceso...</p>
      </div>
    );
  }

  if (!isMasterAdmin) {
    return (
      <div className="space-y-8 text-center py-10">
         <PageHeaderBanner
          title="Acceso Denegado"
          description="No tienes permisos para acceder a esta sección."
          imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
          dataAiHint="seguridad acceso"
        />
        <AlertTriangle className="h-16 w-16 mx-auto text-destructive" />
        <p className="text-xl text-muted-foreground">
          Esta área es exclusiva para el Master Admin.
        </p>
        <Button onClick={() => router.push('/home')}>Volver al Inicio</Button>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <PageHeaderBanner
        title="Panel Maestro Kalce"
        description="Herramientas exclusivas para la administración de Kal-Z-Vieja."
        imageUrl="https://placehold.co/1200x400/1A1A1A/F0F0F0.png"
        dataAiHint="panel control"
      />

      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center">
            <Send className="mr-3 h-6 w-6 text-primary" />
            Herramienta de Notificaciones Push
          </CardTitle>
          <CardDescription>
            Crea y envía notificaciones push personalizadas a los usuarios de la plataforma.
            <br />
            <strong className="text-accent text-xs">(Funcionalidad simulada para prototipo. Requiere backend.)</strong>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Input
              placeholder="Título de la Notificación"
              value={pushTitle}
              onChange={(e) => setPushTitle(e.target.value)}
              className="text-base"
            />
          </div>
          <div>
            <Textarea
              placeholder="Escribe aquí el mensaje de la notificación push..."
              value={pushMessage}
              onChange={(e) => setPushMessage(e.target.value)}
              rows={5}
              className="text-base"
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSendPush} disabled={isSending} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
            {isSending ? <Image src="/images/splash.gif" alt="Enviando..." width={24} height={24} unoptimized className="mr-2" /> : "Enviar Notificación Push"}
          </Button>
        </CardFooter>
      </Card>

      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center">
            <Brush className="mr-3 h-6 w-6 text-accent" />
            Kal-Z-AI Studio (Acceso Admin)
          </CardTitle>
          <CardDescription>
            Accede al estudio de diseño IA.
            <br />
            <strong className="text-accent text-xs">(Nota: Las funciones "desbloqueadas" son conceptuales para el prototipo.)</strong>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Utiliza todas las herramientas de Kal-Z-AI para crear diseños impactantes que luego podrás promocionar o destacar.
          </p>
        </CardContent>
        <CardFooter>
          <Button asChild className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/kal-z-ai">Ir a Kal-Z-AI Studio</Link>
          </Button>
        </CardFooter>
      </Card>
       <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center">
            <Info className="mr-3 h-6 w-6 text-muted-foreground" />
            Políticas y Documentos
          </CardTitle>
          <CardDescription>
            Accede a los documentos legales de la plataforma desde la categoría "Kalce" en el catálogo (visible solo para ti).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Para gestionar o revisar las políticas de privacidad y términos de servicio, visita la sección "Kalce" en el catálogo de productos. Esta sección es exclusiva para el perfil Master Admin.
          </p>
           <p className="text-xs text-destructive">
            **Importante:** El contenido de estos documentos es solo un placeholder. Debes reemplazarlos con textos legales válidos y adaptados a la legislación (especialmente la mexicana) y a las necesidades de tu negocio. Consulta a un profesional legal.
          </p>
        </CardContent>
         <CardFooter>
          <Button asChild variant="outline" className="w-full">
            <Link href="/catalog">Ir al Catálogo (Sección Kalce)</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
