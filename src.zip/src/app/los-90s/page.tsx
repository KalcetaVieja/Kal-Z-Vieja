
"use client"
import { NinetiesCarousel } from "@/components/catalog/nineties-carousel";
import { HighlightK } from "@/components/layout/highlight-k";

export default function NinetiesPage() {
  return (
    <div className="nineties-tv-container">
      <div className="tv-screen-vignette"></div>
      <div className="scanlines"></div>
      
      <div className="on-air-container">
        <div className="on-air-indicator"></div>
        <span>ON AIR</span>
      </div>

      <div className="tv-content">
        <header className="nineties-header">
          <h1 className="nineties-title">
            <HighlightK text="Los 90s" />
          </h1>
          <p className="nineties-subtitle">
            <HighlightK text="Sintoniza la colección más retro de Kal-Z-Vieja." />
          </p>
        </header>
        
        <main className="w-full">
          <NinetiesCarousel />
        </main>
      </div>
      
      <div className="tv-controls">
         <div className="tv-speaker"></div>
         <div className="tv-knob"></div>
         <div className="tv-knob"></div>
         <div className="tv-brand">KAL-Z-VISION</div>
      </div>
    </div>
  );
}
