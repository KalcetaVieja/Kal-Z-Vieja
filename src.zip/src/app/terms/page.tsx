"use client"

import { useState, useEffect } from 'react';

export default function TermsPage() {
  const [lastUpdated, setLastUpdated] = useState('');

  useEffect(() => {
    setLastUpdated(new Date().toLocaleDateString('es-MX'));
  }, []);

  return (
    <div className="container mx-auto py-12 px-4 prose lg:prose-xl">
      <h1>Términos de Servicio</h1>
      {lastUpdated && <p className="text-muted-foreground">Última actualización: {lastUpdated}</p>}

      <h2>1. Aceptación de los Términos</h2>
      <p>
        Bienvenido a Kal-Z-Vieja. Al acceder o utilizar nuestro sitio web y servicios, aceptas estar sujeto a estos Términos de Servicio ("Términos") y nuestra Política de Privacidad. Si no estás de acuerdo con alguna parte de los términos, no podrás acceder al servicio.
      </p>

      <h2>2. Uso de los Servicios</h2>
      <p>
        Kal-Z-Vieja te proporciona una plataforma para explorar artículos de ropa, personalizarlos con tus propios diseños y texto, y utilizar herramientas de IA para sugerencias de diseño y prueba virtual.
      </p>
      <ul>
        <li>Debes ser mayor de edad en tu jurisdicción para utilizar nuestros servicios o contar con el permiso de un padre o tutor.</li>
        <li>Eres responsable de cualquier actividad que ocurra bajo tu cuenta.</li>
        <li>No puedes utilizar nuestros servicios para ningún propósito ilegal o no autorizado.</li>
      </ul>

      <h2>3. Contenido del Usuario</h2>
      <p>
        Al subir diseños, texto u otro contenido ("Contenido del Usuario") a Kal-Z-Vieja, otorgas a Kal-Z-Vieja una licencia mundial, no exclusiva, libre de regalías para usar, reproducir, modificar y mostrar dicho Contenido del Usuario en relación con la prestación de los Servicios.
      </p>
      <p>
        Garantizas que posees todos los derechos sobre el Contenido del Usuario o que tienes el derecho de otorgarnos la licencia descrita anteriormente, y que tu Contenido del Usuario no infringe los derechos de propiedad intelectual ni ningún otro derecho de terceros.
      </p>

      <h2>4. Propiedad Intelectual</h2>
      <p>
        El Servicio y su contenido original (excluyendo el Contenido del Usuario), características y funcionalidad son y seguirán siendo propiedad exclusiva de Kal-Z-Vieja y sus licenciantes.
      </p>

      <h2>5. Compras y Pagos</h2>
      <p>
        Si deseas comprar cualquier producto o servicio disponible a través del Servicio, es posible que se te solicite que proporciones cierta información relevante para tu Compra. (Detalles sobre pasarelas de pago, seguridad, etc. se añadirían aquí).
      </p>

      <h2>6. Política de Devoluciones y Reembolsos</h2>
      <p>
        Debido a la naturaleza personalizada de nuestros productos, las devoluciones o reembolsos se manejarán caso por caso. Por favor, contáctanos si tienes algún problema con tu pedido. (Se necesitaría una política más detallada).
      </p>
      
      <h2>7. Limitación de Responsabilidad</h2>
      <p>
        En ningún caso Kal-Z-Vieja, ni sus directores, empleados, socios, agentes, proveedores o afiliados, serán responsables de ningún daño indirecto, incidental, especial, consecuente o punitivo, incluyendo, entre otros, pérdida de beneficios, datos, uso, buena voluntad u otras pérdidas intangibles, resultantes de (i) tu acceso o uso o incapacidad para acceder o usar el Servicio; (ii) cualquier conducta o contenido de cualquier tercero en el Servicio; (iii) cualquier contenido obtenido del Servicio; y (iv) acceso no autorizado, uso o alteración de tus transmisiones o contenido, ya sea basado en garantía, contrato, agravio (incluida negligencia) o cualquier otra teoría legal, ya sea que hayamos sido informados o no de la posibilidad de dicho daño.
      </p>

      <h2>8. Modificaciones a los Términos</h2>
      <p>
        Nos reservamos el derecho, a nuestra sola discreción, de modificar o reemplazar estos Términos en cualquier momento. Si una revisión es material, intentaremos proporcionar un aviso de al menos 30 días antes de que entren en vigor los nuevos términos. Lo que constituye un cambio material se determinará a nuestra sola discreción.
      </p>

      <h2>9. Contacto</h2>
      <p>
        Si tienes alguna pregunta sobre estos Términos, por favor contáctanos en <a href="mailto:kalceta.vieja@gmail.com" className="text-accent hover:underline">kalceta.vieja@gmail.com</a>.
      </p>
    </div>
  );
}
