"use client"

import { useState, useEffect } from 'react';

export default function PrivacyPage() {
  const [lastUpdated, setLastUpdated] = useState('');

  useEffect(() => {
    setLastUpdated(new Date().toLocaleDateString('es-MX'));
  }, []);

  return (
    <div className="container mx-auto py-12 px-4 prose lg:prose-xl">
      <h1>Política de Privacidad</h1>
      {lastUpdated && <p className="text-muted-foreground">Última actualización: {lastUpdated}</p>}

      <p>
        En Kal-Z-Vieja, valoramos tu privacidad y nos comprometemos a proteger tu información personal. Esta Política de Privacidad explica cómo recopilamos, usamos, divulgamos y salvaguardamos tu información cuando visitas nuestro sitio web y utilizas nuestros servicios.
      </p>

      <h2>1. Información que Recopilamos</h2>
      <p>Podemos recopilar información sobre ti de varias maneras. La información que podemos recopilar en el Sitio incluye:</p>
      
      <h3>Datos Personales</h3>
      <p>
        Información de identificación personal, como tu nombre, dirección de envío, dirección de correo electrónico y número de teléfono, e información demográfica, como tu edad, sexo, ciudad natal e intereses, que nos proporcionas voluntariamente cuando te registras en el Sitio o cuando eliges participar en diversas actividades relacionadas con el Sitio, como chat en línea y tablones de mensajes.
      </p>

      <h3>Datos Derivados</h3>
      <p>
        Información que nuestros servidores recopilan automáticamente cuando accedes al Sitio, como tu dirección IP, tu tipo de navegador, tu sistema operativo, tus horas de acceso y las páginas que has visto directamente antes y después de acceder al Sitio.
      </p>
      
      <h3>Datos de Dispositivos Móviles</h3>
      <p>
        Información del dispositivo, como la ID, modelo y fabricante de tu dispositivo móvil, e información sobre la ubicación de tu dispositivo, si accedes al Sitio desde un dispositivo móvil.
      </p>

      <h3>Datos de Terceros</h3>
      <p>
        Información de terceros, como información personal o amigos de la red, si conectas tu cuenta a un tercero y otorgas permiso al Sitio para acceder a esta información.
      </p>

      <h2>2. Uso de Tu Información</h2>
      <p>Tener información precisa sobre ti nos permite ofrecerte una experiencia fluida, eficiente y personalizada. Específicamente, podemos usar la información recopilada sobre ti a través del Sitio para:</p>
      <ul>
        <li>Crear y administrar tu cuenta.</li>
        <li>Procesar tus transacciones y entregar los productos y servicios que solicitas.</li>
        <li>Enviarte correos electrónicos sobre tu cuenta o pedido.</li>
        <li>Permitir la comunicación de usuario a usuario.</li>
        <li>Mejorar la eficiencia y el funcionamiento del Sitio.</li>
        <li>Personalizar tu experiencia en el sitio.</li>
        <li>Generar un perfil personal sobre ti para que las futuras visitas al Sitio sean más personalizadas.</li>
        <li>Prevenir actividades fraudulentas y supervisar contra robos.</li>
      </ul>

      <h2>3. Divulgación de Tu Información</h2>
      <p>Podemos compartir información que hemos recopilado sobre ti en ciertas situaciones. Tu información puede ser divulgada de la siguiente manera:</p>
      
      <h3>Por Ley o para Proteger Derechos</h3>
      <p>
        Si creemos que la divulgación de información sobre ti es necesaria para responder a un proceso legal, para investigar o remediar posibles violaciones de nuestras políticas, o para proteger los derechos, la propiedad y la seguridad de otros, podemos compartir tu información según lo permita o exija cualquier ley, norma o regulación aplicable.
      </p>

      <h3>Proveedores de Servicios de Terceros</h3>
      <p>
        Podemos compartir tu información con terceros que realizan servicios para nosotros o en nuestro nombre, incluido el procesamiento de pagos, análisis de datos, entrega de correo electrónico, servicios de alojamiento, servicio al cliente y asistencia de marketing.
      </p>

      <h2>4. Seguridad de Tu Información</h2>
      <p>
        Utilizamos medidas de seguridad administrativas, técnicas y físicas para ayudar a proteger tu información personal. Si bien hemos tomado medidas razonables para asegurar la información personal que nos proporcionas, ten en cuenta que a pesar de nuestros esfuerzos, ninguna medida de seguridad es perfecta o impenetrable, y ningún método de transmisión de datos puede garantizarse contra cualquier intercepción u otro tipo de uso indebido.
      </p>

      <h2>5. Política para Niños</h2>
      <p>
        No solicitamos conscientemente información ni comercializamos a niños menores de 13 años. Si te das cuenta de que hemos recopilado datos de niños menores de 13 años, contáctanos utilizando la información de contacto proporcionada a continuación.
      </p>

      <h2>6. Opciones Concernientes a Tu Información</h2>
      <h3>Información de la Cuenta</h3>
      <p>
        Puedes revisar o cambiar la información de tu cuenta en cualquier momento o cancelar tu cuenta iniciando sesión en la configuración de tu cuenta y actualizando tu cuenta o contactándonos utilizando la información de contacto proporcionada a continuación.
      </p>

      <h2>7. Contacto</h2>
      <p>
        Si tienes preguntas o comentarios sobre esta Política de Privacidad, por favor contáctanos en:
        <br />
        Kal-Z-Vieja
        <br />
        <a href="mailto:kalceta.vieja@gmail.com" className="text-accent hover:underline">kalceta.vieja@gmail.com</a>
        <br />
        Calle Allende #324, Col Centro Pach, Hgo.
      </p>
    </div>
  );
}
