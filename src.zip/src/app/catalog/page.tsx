
"use client";

import React, { useState, useEffect, Suspense, useMemo } from 'react';
import { useSearchParams } from 'next/navigation';
import { mockProducts, mockViralPosts } from "@/data/mock";
import { Input } from "@/components/ui/input";
import { Search, Tag, ShieldAlert, Crown } from "lucide-react";
import type { Product } from "@/types";
import { HighlightK } from '@/components/layout/highlight-k';
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { PilonCarousel } from '@/components/shared/pilon-carousel';
import { ProductCarousel } from "@/components/catalog/product-carousel";
import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { useTheme } from 'next-themes';

// Define the desired order of categories
const categoryOrder: string[] = [
    "Camisetas Manga Corta", 
    "Camisetas Manga Larga", 
    "Sudaderas con Gorro", 
    "Sudaderas sin Gorro",
    "Totebag",
    "Taza",
    "Termo",
];

const categoryThumbnails = [
    { 
        name: 'Camisetas Manga Corta', 
        href: '#camisetas-manga-corta',
        imageUrl: '/images/products/Kalzvieja/camisetas/MC/Mcbasicos/ctamcblanca.png',
        dataAiHint: "camiseta blanca"
    },
    { 
        name: 'Camisetas Manga Larga', 
        href: '#camisetas-manga-larga',
        imageUrl: '/images/products/Kalzvieja/camisetas/ML/BasicosML/ctamlnegro.png',
        dataAiHint: "camiseta manga larga"
    },
    { 
        name: 'Sudaderas con Gorro', 
        href: '#sudaderas-con-gorro',
        imageUrl: '/images/products/Kalzvieja/sudadera/congorro/rosa/sudaderagrosa.png',
        dataAiHint: "sudadera rosa"
    },
    { 
        name: 'Sudaderas sin Gorro', 
        href: '#sudaderas-sin-gorro',
        imageUrl: '/images/products/Kalzvieja/sudadera/singorro/Negro/sudaderanegro.png',
        dataAiHint: "sudadera cuello redondo"
    },
    { 
        name: 'Totebag', 
        href: '#totebag',
        imageUrl: '/images/products/Kalzvieja/totebags/Basic/totebag.png',
        dataAiHint: "bolsa tela"
    },
    { 
        name: 'Taza', 
        href: '#taza',
        imageUrl: '/images/products/Kalzvieja/tazas/tazamagica.png',
        dataAiHint: "taza magica"
    },
    { 
        name: 'Termo', 
        href: '#termo',
        imageUrl: '/images/products/Kalzvieja/Termo/Termo20oz.png',
        dataAiHint: "vaso termico"
    },
];


function CatalogContent() {
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  
  useEffect(() => {
    setAllProducts(mockProducts);
  }, []);

  const filteredProducts = useMemo(() => allProducts.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.category.toLowerCase().includes(searchTerm.toLowerCase())
  ), [allProducts, searchTerm]);

  const productsByCategory = useMemo(() => {
    const grouped: Record<string, Record<string, Product[]>> = {};

    categoryOrder.forEach(category => {
      const categoryProducts = filteredProducts.filter(p => p.category === category);
      if (categoryProducts.length > 0) {
        grouped[category] = {};
        
        const productsBySubCategory: Record<string, Product[]> = {};

        categoryProducts.forEach(product => {
            const subCategory = product.subCategory || "General";
            if (!productsBySubCategory[subCategory]) {
                productsBySubCategory[subCategory] = [];
            }
            productsBySubCategory[subCategory].push(product);
        });
        
        // Sort subcategories, e.g., "Básicos" first
        const sortedSubCategories = Object.keys(productsBySubCategory).sort((a, b) => {
            if (a === "Básicos") return -1;
            if (b === "Básicos") return 1;
            if (a === "Colección") return 1;
            if (b === "Colección") return -1;
            return a.localeCompare(b);
        });

        sortedSubCategories.forEach(subCategory => {
             grouped[category][subCategory] = productsBySubCategory[subCategory];
        });
      }
    });

    return grouped;
  }, [filteredProducts]);

  const top10ViralPosts = mockViralPosts.filter(p => p.design?.baseProductId).slice(0, 10);


  return (
    <div className="space-y-12">
      <div className="relative mt-2 mb-8">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Buscar productos en todo Kal-Z-Vieja..."
          className="pl-9 w-full md:w-2/3 lg:w-1/2 mx-auto text-xs"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

       {/* Category Thumbnails */}
      <section className="-mt-4">
        <div className="flex justify-center gap-4 overflow-x-auto p-2 hide-scrollbar">
            {categoryThumbnails.map(cat => (
                <Link key={cat.name} href={cat.href} className="group flex-shrink-0 text-center w-28">
                    <div className="relative aspect-square w-full rounded-full border-2 border-border/50 group-hover:border-primary transition-all duration-300 overflow-hidden shadow-md">
                        <Image
                            src={cat.imageUrl}
                            alt={`Categoría ${cat.name}`}
                            fill
                            className={cn("object-contain", cat.imageUrl.startsWith('https') ? "p-0" : "p-3 transition-transform duration-300 group-hover:scale-110")}
                            data-ai-hint={cat.dataAiHint}
                        />
                    </div>
                    <span className="mt-2 block text-xs font-medium text-muted-foreground group-hover:text-primary transition-colors">
                        <HighlightK text={cat.name} />
                    </span>
                </Link>
            ))}
        </div>
      </section>

      {/* Main Catalog Section */}
      <section id="kal-z-vieja-catalog" aria-labelledby="catalog-main-title">
        <div className="flex items-center mb-6 pb-2 border-b border-border/50">
            <Tag className="h-6 w-6 text-primary mr-2.5 shrink-0" />
            <h2 id="catalog-main-title" className="text-lg font-semibold text-foreground">
                <HighlightK text="Katálogo Kal-Z-Vieja" />
            </h2>
        </div>
        <div className="space-y-10">
            {Object.entries(productsByCategory).length > 0 ? (
                Object.entries(productsByCategory).map(([category, subCategories]) => (
                    <div key={category} id={category.toLowerCase().replace(/\s+/g, '-')} className="scroll-mt-20 space-y-6">
                        <h3 className="text-base font-semibold text-foreground pl-2">{category}</h3>
                        {Object.entries(subCategories).map(([subCategory, products]) => (
                            <div key={subCategory}>
                                <h4 className="text-sm font-medium text-muted-foreground mb-3 pl-2">{subCategory}</h4>
                                <ProductCarousel products={products} />
                            </div>
                        ))}
                    </div>
                ))
            ) : (
                <div className="text-center py-10 text-muted-foreground">
                    <p>El catálogo está actualmente vacío. Vuelve pronto.</p>
                </div>
            )}
        </div>
      </section>
      
      {/* Khe Viral Section */}
      {top10ViralPosts.length > 0 && (
        <section id="khe-viral" aria-labelledby="category-title-kheviral" className="scroll-mt-20 pt-12">
            <div className="flex items-center mb-6 pb-2 border-b border-border/50">
              <Crown className="h-6 w-6 text-yellow-400 mr-2.5 shrink-0" />
              <h2 id="category-title-kheviral" className="text-lg font-semibold text-foreground">
                  <HighlightK text="Destacados de Khe Viral" />
              </h2>
            </div>
            <ProductCarousel products={top10ViralPosts.map(post => ({...mockProducts.find(p => p.id === post.design?.baseProductId)!, ...post, id: post.id})) as any} />
        </section>
      )}

      <div className="pt-12">
        <PilonCarousel />
      </div>
    </div>
  );
}

export default function CatalogPage() {
    const { theme } = useTheme();
    const [bannerUrl, setBannerUrl] = React.useState("/images/Logos/kalZlogin.png");

    React.useEffect(() => {
        const getBannerSrc = () => {
          const cacheBust = '?v=6';
          switch(theme) {
            case 'green':
              return `/images/Logos/logokalZ.png${cacheBust}`;
            case 'tornasol':
              return `/images/Logos/logo8bit.png${cacheBust}`;
            case 'vieja':
              return `/images/Logos/logo%20grises.png${cacheBust}`;
            default:
              return `/images/Logos/kalZlogin.png${cacheBust}`;
          }
        }
        setBannerUrl(getBannerSrc());
    }, [theme]);
    
    return (
        <>
            <PageHeaderBanner
              title=""
              imageUrl={bannerUrl}
              dataAiHint="logo marca"
            />
            <Suspense fallback={<div className="text-center py-10">Cargando productos...</div>}>
                <CatalogContent />
            </Suspense>
        </>
    )
}
