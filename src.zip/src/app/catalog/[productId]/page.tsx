
"use client";

import Image from "next/image";
import Link from "next/link";
import { useParams } from "next/navigation";
import { mockProducts } from "@/data/mock";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Heart, Wand2, Info, Brush, Plus, Minus } from "lucide-react";
import { VirtualTryOnBooth } from "@/components/try-on/virtual-try-on-booth";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";
import type { Product } from "@/types";
import { Skeleton } from "@/components/ui/skeleton";
import { PilonCarousel } from "@/components/shared/pilon-carousel";
import { useRecentlyViewed } from "@/hooks/use-recently-viewed";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useAssistant } from "@/context/assistant-context";
import { useMyLooks } from "@/context/my-looks-context";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";


const pageTabs = [
    { id: 'info', label: 'Info', icon: Info },
    { id: 'try-on', label: 'Probador', icon: Wand2 },
    { id: 'studio', label: 'Kal-Z-Studio', icon: Brush },
    { id: 'cart', label: 'Carrito', icon: ShoppingCart },
];

export default function ProductDetailPage() {
  const { showAssistantMessage } = useAssistant();
  const params = useParams();
  const productId = params.productId as string;
  const { addRecentlyViewed } = useRecentlyViewed();
  const { looks } = useMyLooks();

  const product = mockProducts.find(p => p.id === productId);

  const [mainImage, setMainImage] = useState<string | null>(null);
  const [appliedDesign, setAppliedDesign] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    setIsClient(true);
    if (product) {
      addRecentlyViewed(product);
      setMainImage(product.imageUrl);
      setAppliedDesign(null); // Reset design when product changes
    }
  }, [product, addRecentlyViewed]);

  const handleQuantityChange = (amount: number) => {
    setQuantity(prev => Math.max(1, prev + amount));
  };

  if (!isClient) {
    return <div className="mx-auto py-8 px-4"><Skeleton className="h-[70vh] w-full" /></div>;
  }
  
  if (!product) {
    return <div className="text-center py-10">Producto no encontrado.</div>;
  }
  
  const gallery = [product.imageUrl, ...(product.galleryImages || [])].slice(0, 3);
  
  const handleAddToCart = () => {
    showAssistantMessage({
      title: "Añadido al Carrito",
      message: `${quantity}x "${product.name}" ha sido añadido a tu carrito.`,
      action: <Button variant="outline" size="sm" asChild><Link href="/cart">Ver Carrito</Link></Button>,
    });
  };

  const handleAddToFavorites = () => {
    showAssistantMessage({
      title: "Añadido a Favoritos",
      message: `${product.name} ha sido añadido a tus favoritos.`,
    });
  };


  return (
    <div className="space-y-12 py-8 px-4">
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr] gap-8 max-w-7xl mx-auto">
        
        {/* Left Column: Image Viewer */}
        <div className="space-y-4 lg:sticky lg:top-20 self-start">
          <div className="aspect-[4/5] relative rounded-lg overflow-hidden shadow-md bg-muted/20">
            {mainImage ? (
                <>
                <Image
                    key={mainImage}
                    src={mainImage}
                    alt={product.name}
                    fill
                    className="object-cover transition-opacity duration-300"
                    data-ai-hint={product.dataAiHint}
                    unoptimized={mainImage.endsWith('.gif')}
                  />
                  {appliedDesign && (
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1/3 h-1/3">
                          <Image src={appliedDesign} alt="Diseño aplicado" fill className="object-contain" />
                      </div>
                  )}
                </>
              ) : (
                <Skeleton className="w-full h-full" />
              )}
          </div>
          {gallery.length > 1 && (
            <div className="flex gap-2 justify-center">
                {gallery.map((img, index) => (
                    <button key={index} onClick={() => setMainImage(img)} className={cn("w-24 h-28 rounded-md overflow-hidden border-2 transition-all", mainImage === img ? "border-primary" : "border-transparent hover:border-muted-foreground")}>
                        <Image src={img} alt={`Vista ${index+1}`} width={96} height={112} className="object-cover w-full h-full" />
                    </button>
                ))}
            </div>
          )}
        </div>
        
        {/* Right Column: Info & Tools Panel */}
        <div className="space-y-6 lg:sticky lg:top-20 self-start">
            <Card className="bg-card/80">
                <Tabs defaultValue="info" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 gap-1 p-1 h-auto">
                        {pageTabs.map((tab) => {
                            const Icon = tab.icon;
                            return (
                                <TabsTrigger key={tab.id} value={tab.id} className="h-full p-0">
                                    <div className="flex flex-col items-center gap-1 py-1">
                                        <Icon className="h-5 w-5" />
                                        <span className="text-xs">{tab.label === 'Studio' ? 'Kal-Z-Studio' : tab.label}</span>
                                    </div>
                                </TabsTrigger>
                            );
                        })}
                    </TabsList>
                    
                    <TabsContent value="info" className="animate-in fade-in-50">
                        <CardHeader>
                            <Badge variant={"secondary"} className="mb-2 w-fit">{product.category}</Badge>
                            <CardTitle className="text-xl">{product.name}</CardTitle>
                            <p className="text-2xl font-semibold text-accent mt-2">${product.price.toFixed(2)} MXN</p>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <CardDescription className="whitespace-pre-line">{product.description}</CardDescription>
                            {(product.availableSizes && product.availableSizes.length > 0 && product.availableSizes[0] !== "N/A") && (
                                <div>
                                <h3 className="text-sm font-medium mb-2">Tamaño:</h3>
                                <div className="flex flex-wrap gap-2">
                                    {product.availableSizes.map(size => (<Button key={size} variant="outline" size="sm">{size}</Button>))}
                                </div>
                                </div>
                            )}
                            {(product.availableColors && product.availableColors.length > 0 && product.availableColors[0] !== "N/A") && (
                                <div>
                                <h3 className="text-sm font-medium mb-2">Color:</h3>
                                <div className="flex flex-wrap gap-2">
                                    {product.availableColors.map(color => (<Button key={color} variant="outline" size="sm" className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-full border" style={{ backgroundColor: color.toLowerCase() === 'negro' ? 'black' : color.toLowerCase() === 'blanco' ? 'white' : color.toLowerCase() === 'rosa' ? '#F472B6' : color.toLowerCase() === 'acid wash' ? '#6B7280' : color.toLowerCase() === 'verde' ? '#10B981' : 'transparent' }}></span>{color}</Button>))}
                                </div>
                                </div>
                            )}
                        </CardContent>
                        <CardFooter className="flex flex-col gap-4 pt-6 border-t">
                            <div className="flex items-center justify-between w-full">
                                <div className="flex items-center gap-2">
                                    <h3 className="text-sm font-medium">Cantidad</h3>
                                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => handleQuantityChange(-1)} disabled={quantity <= 1}>
                                        <Minus className="h-4 w-4" />
                                    </Button>
                                    <span className="flex items-center justify-center w-12 h-8 text-center border rounded-md">{quantity}</span>
                                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => handleQuantityChange(1)}>
                                        <Plus className="h-4 w-4" />
                                    </Button>
                                </div>
                                <Button variant="outline" size="icon" onClick={handleAddToFavorites} className="h-10 w-10">
                                    <Heart className="h-5 w-5" />
                                    <span className="sr-only">Añadir a Favoritos</span>
                                </Button>
                            </div>
                            <Button size="lg" className="w-full" onClick={handleAddToCart}>
                                <ShoppingCart className="mr-2 h-5 w-5" /> Añadir {quantity} al Carrito
                            </Button>
                        </CardFooter>
                    </TabsContent>
                    
                    <TabsContent value="try-on" className="animate-in fade-in-50">
                         <CardHeader>
                            <CardTitle>Probador Virtual</CardTitle>
                            <CardDescription>Mira cómo te queda la prenda al instante usando IA.</CardDescription>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <VirtualTryOnBooth product={product} customizationOptions={null} />
                       </CardContent>
                    </TabsContent>

                    <TabsContent value="studio" className="animate-in fade-in-50">
                        <CardHeader>
                            <CardTitle>Kal-Z-Studio</CardTitle>
                            <CardDescription>Selecciona uno de tus diseños guardados para aplicarlo a esta prenda.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {looks.length > 0 ? (
                                <div className="grid grid-cols-3 gap-2">
                                    {looks.map(look => (
                                        <button key={look.id} onClick={() => setAppliedDesign(look.imageDataUri)} className="aspect-square relative group rounded-md overflow-hidden border-2 border-transparent hover:border-primary focus:border-primary">
                                            <Image src={look.imageDataUri} alt={look.name} fill className="object-contain bg-muted/20" />
                                        </button>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-sm text-muted-foreground text-center py-4">No tienes diseños guardados. ¡<Link href="/kal-z-ai" className="text-accent underline">Crea uno</Link>!</p>
                            )}
                            {appliedDesign && <Button variant="outline" size="sm" className="mt-4 w-full" onClick={() => setAppliedDesign(null)}>Quitar Diseño</Button>}
                        </CardContent>
                    </TabsContent>
                    
                    <TabsContent value="cart" className="animate-in fade-in-50">
                        <CardHeader>
                            <CardTitle>Tu Carrito de Compras</CardTitle>
                        </CardHeader>
                        <CardContent className="text-center space-y-4">
                            <p className="text-muted-foreground">Revisa los artículos en tu carrito o procede al pago.</p>
                            <Button asChild className="w-full">
                                <Link href="/cart">
                                    <ShoppingCart className="mr-2 h-4 w-4" /> Ir al Carrito
                                </Link>
                            </Button>
                        </CardContent>
                    </TabsContent>
                    
                </Tabs>
            </Card>
        </div>
      </div>
      
      <div className="my-12">
        <PilonCarousel />
      </div>

    </div>
  );
}
    
