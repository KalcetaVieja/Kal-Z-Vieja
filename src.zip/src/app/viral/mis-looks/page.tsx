
"use client";

import React from "react";
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { PilonCarousel } from "@/components/shared/pilon-carousel";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Brush, Plus, Share2, Trash2 } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { mockProducts } from "@/data/mock";
import Image from "next/image";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMyLooks } from "@/context/my-looks-context";

export default function MisLooksPage() {
    const { toast } = useToast();
    const { looks, removeLook } = useMyLooks();

    const handleDelete = (lookId: string, lookName: string) => {
        removeLook(lookId);
        toast({
            title: "Diseño Eliminado",
            description: `Tu diseño "${lookName}" ha sido eliminado.`,
        });
    };

    const handleShare = (designName: string) => {
        toast({
            title: "Diseño Publicado (Simulación)",
            description: `¡Tu diseño "${designName}" ahora está en la galería de Khe Viral!`,
        });
    }

  return (
    <div className="space-y-8">
      <PageHeaderBanner
        title="Mis Looks"
        description="Aquí se guardan todos los diseños y avatares que has creado. ¡Publícalos en la galería para que todos los vean!"
        imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
        dataAiHint="mis diseños guardados"
      />

      <Card className="text-center bg-muted/50 p-6 sm:p-8 rounded-lg">
          <CardHeader className="p-0">
            <CardTitle className="text-2xl font-semibold mb-3">Gestiona tus Kreaciones</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <p className="text-muted-foreground max-w-xl mx-auto">
                Desde aquí puedes revisar tus diseños guardados, publicarlos en la galería de "Khe Viral", o eliminarlos. ¡Tus ideas, tus reglas!
            </p>
             <Button asChild className="mt-4">
                <Link href="/kal-z-ai">
                    <Plus className="mr-2 h-4 w-4" /> Crear Nuevo Diseño
                </Link>
            </Button>
          </CardContent>
      </Card>
      
      {looks.length > 0 ? (
        <section id="my-looks-gallery" className="pt-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {looks.map((look) => (
                    <Card key={look.id} className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col h-full group">
                        <CardHeader className="p-0">
                            <div className="aspect-square relative bg-muted/30">
                                <Image 
                                    src={look.imageDataUri} 
                                    alt={look.name} 
                                    layout="fill" 
                                    objectFit="contain" 
                                    className="p-2 transition-transform duration-300 group-hover:scale-105"
                                    data-ai-hint={look.dataAiHint || "diseño usuario"}
                                />
                                {look.baseProductId && (
                                     <Badge variant="secondary" className="absolute top-2 left-2">
                                        {mockProducts.find(p => p.id === look.baseProductId)?.category || 'Prenda'}
                                    </Badge>
                                )}
                            </div>
                        </CardHeader>
                        <CardContent className="p-4 flex-grow">
                            <CardTitle className="text-base mb-1 truncate">{look.name}</CardTitle>
                            <p className="text-xs text-muted-foreground">
                                Creado: {new Date(look.createdAt).toLocaleDateString('es-MX')}
                            </p>
                        </CardContent>
                        <CardFooter className="p-2 border-t flex flex-col gap-2">
                            <Button size="sm" className="w-full" onClick={() => handleShare(look.name)}>
                                <Share2 className="mr-2 h-4 w-4" /> Publicar en Viral
                            </Button>
                            <Button variant="destructive" size="sm" className="w-full" onClick={() => handleDelete(look.id, look.name)}>
                                <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                            </Button>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </section>
      ) : (
        <div className="text-center py-10 border border-dashed rounded-lg">
          <p className="text-muted-foreground">
            No tienes diseños guardados. ¡Ve al <Link href="/kal-z-ai" className="text-accent underline hover:text-accent/80">Kal-Z-AI Studio</Link> para empezar a crear y volverte VIRAL!
          </p>
        </div>
      )}

      <div className="pt-12">
        <PilonCarousel />
      </div>
    </div>
  );
}
