
"use client";

import React from "react";
import Autoplay from "embla-carousel-autoplay";
import { mockViralPosts } from "@/data/mock"; 
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { PilonCarousel } from "@/components/shared/pilon-carousel";
import { ViralCarousel } from "@/components/viral/viral-carousel";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Brush, Upload, Plus, Eye } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";


const AddDesignCard = () => (
    <div className="w-[300px] flex-shrink-0">
        <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col h-full hover:scale-105">
            <CardHeader className="p-0">
                <Link href="/kal-z-ai" className="block aspect-square relative group bg-transparent">
                    <div className="w-full h-full flex items-center justify-center bg-muted/30 group-hover:bg-muted/50 border-2 border-dashed border-border group-hover:border-primary transition-all duration-300 rounded-t-lg">
                        <Plus className="h-24 w-24 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                </Link>
            </CardHeader>
            <CardContent className="p-4 flex-grow">
                <CardTitle className="text-lg mb-1">
                    Crea tu Diseño
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                    Usa el Kal-Z-AI Studio para dar vida a tus ideas y compártelas con la comunidad.
                </p>
            </CardContent>
            <CardFooter className="p-3 border-t">
                <Button asChild variant="outline" size="sm" className="w-full">
                    <Link href="/kal-z-ai">
                        <Brush className="mr-2 h-4 w-4" />
                        Crear Diseño
                    </Link>
                </Button>
            </CardFooter>
        </Card>
    </div>
);


export default function ViralPage() {
  const posts = mockViralPosts; 
  const autoplayPlugin = React.useRef(Autoplay({ delay: 3000, stopOnInteraction: true }));


  return (
    <div className="space-y-8">
      <PageHeaderBanner
        title="Viral: La Galería de la Comunidad"
        description="Explora diseños únicos, obtén un 10% de descuento y apoya a los creadores con una comisión del 10%."
        imageUrl="https://placehold.co/1200x400/2A2A2A/E0E0E0.png"
        dataAiHint="galeria comunidad"
      />

       <Card className="text-center bg-muted/50 p-6 sm:p-8 rounded-lg">
          <CardHeader className="p-0">
            <CardTitle className="text-2xl font-semibold mb-3">¿Cómo funciona "Viral"?</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="list-disc list-inside text-muted-foreground max-w-xl mx-auto text-left space-y-2">
              <li>Crea diseños increíbles en la sección "Kal-Z-AI".</li>
              <li>Guarda tus creaciones favoritas en "Mis Looks".</li>
              <li>Desde "Mis Looks", publica tus diseños aquí para que todos los vean.</li>
              <li>¡Los compradores obtienen un <strong>10% de descuento</strong> en cualquier diseño de "Viral"!</li>
              <li>¡Como creador, recibes una <strong>comisión del 10%</strong> por cada venta de tu diseño! (Se requiere registro completo para recibir comisiones).</li>
            </ul>
          </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Button asChild className="h-20 text-lg">
            <Link href="/kal-z-ai">
                <Brush className="mr-3 h-6 w-6"/>
                Ir al Personalizador Kal-Z-Studio
            </Link>
        </Button>
         <Button asChild variant="outline" className="h-20 text-lg">
            <Link href="/viral/mis-looks">
                <Eye className="mr-3 h-6 w-6"/>
                Ver y Publicar desde "Mis Looks"
            </Link>
        </Button>
      </div>

      <section id="create-your-own" className="pt-4 my-12">
            <h2 className="text-2xl font-semibold text-center mb-6">
                ¡Crea tu Propio Diseño!
            </h2>
            <div className="relative">
                 <Carousel
                    opts={{ align: "start", loop: true }}
                    plugins={[autoplayPlugin.current]}
                    onMouseEnter={autoplayPlugin.current.stop}
                    onMouseLeave={autoplayPlugin.current.reset}
                    className="w-full"
                >
                    <CarouselContent className="-ml-4">
                        {[...Array(5)].map((_, i) => (
                            <CarouselItem key={`add-${i}`} className="pl-4 basis-full sm:basis-1/2 md:basis-1/3 lg:basis-1/4">
                                <AddDesignCard />
                            </CarouselItem>
                        ))}
                    </CarouselContent>
                </Carousel>
            </div>
      </section>

      {posts.length > 0 ? (
        <section id="viral-gallery" className="pt-8 my-12">
            <h2 className="text-2xl font-semibold text-center mb-6">
                Galería de la Comunidad
            </h2>
            <ViralCarousel posts={posts} />
        </section>
      ) : (
        <p className="text-center text-muted-foreground py-10">
          Aún no hay diseños virales. ¡Sé el primero en compartir tu creación desde Kal-Z-AI!
        </p>
      )}

      <div className="my-12">
        <PilonCarousel />
      </div>
    </div>
  );
}
