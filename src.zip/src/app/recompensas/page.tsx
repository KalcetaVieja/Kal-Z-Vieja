
"use client";

import React, { useState, useCallback } from 'react';
import { PageHeaderBanner } from "@/components/layout/page-header-banner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Award, Gift, ListChecks, Target, Star, Settings, User, Wand2, Sparkles, Gem, Save, Info, Shirt, Watch, Sun, Droplet, UserSquare, Hand, Footprints, Glasses, ShoppingBag, VenetianMask, Ticket, Scissors, Copy, Percent, Truck, Loader2, RefreshCw } from "lucide-react";
import Image from "next/image";
import { PilonCarousel } from "@/components/shared/pilon-carousel";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { mockUserProfile } from "@/data/mock";
import { cn } from "@/lib/utils";
import { FileUploader } from "@/components/ui/file-uploader";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { generateAvatar, type GenerateAvatarInput, type GenerateAvatarOutput } from '@/ai/flows/avatar-generator';
import { useAssistant } from '@/context/assistant-context';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Input } from '@/components/ui/input';
import { useMonthlyDeals } from '@/hooks/use-monthly-deals';
import type { Product } from '@/types';
import { HighlightK } from '@/components/layout/highlight-k';
import { useToast } from '@/hooks/use-toast';


const mockTasks = [
    { id: 'task1', text: 'Valora 3 diseños en la sección "Viral"', points: 50, icon: Star, completed: true },
    { id: 'task2', text: 'Realiza una prueba virtual con tu foto', points: 75, icon: Award, completed: true },
    { id: 'task3', text: 'Comparte un producto en tus redes sociales', points: 100, icon: Gift, completed: false }
];

const mockCoupons = [
    {
        id: 'CUPON10',
        title: '10% de Descuento',
        description: 'En tu próxima compra de cualquier camiseta.',
        code: 'KALZ10OFF',
        icon: Percent,
        points: 500,
        color: 'text-primary',
        bgColor: 'bg-primary/10',
        borderColor: 'border-primary/20'
    },
    {
        id: 'CUPONSHIP',
        title: 'Envío Gratis',
        description: 'En pedidos superiores a $400 MXN.',
        code: 'ENVIOGRATIS',
        icon: Truck,
        points: 1000,
        color: 'text-highlight-green',
        bgColor: 'bg-highlight-green/10',
        borderColor: 'border-highlight-green/20'
    },
    {
        id: 'CUPONTOTE',
        title: 'Totebag de Regalo',
        description: 'En la compra de 2 o más sudaderas.',
        code: 'REGALOTOTE',
        icon: Gift,
        points: 1500,
        color: 'text-accent',
        bgColor: 'bg-accent/10',
        borderColor: 'border-accent/20'
    }
];

interface CustomizationOption {
    id: string;
    label: string;
    icon: React.ElementType;
}

const clothingOptions: CustomizationOption[] = [
    { id: "Camiseta", label: "Camiseta", icon: Shirt },
    { id: "Sudadera", label: "Sudadera", icon: Shirt }, // Re-using shirt for now
    { id: "Chaqueta", label: "Chaqueta", icon: Shirt }, // Re-using shirt
    { id: "Top", label: "Top", icon: VenetianMask },
    { id: "Vestido", label: "Vestido", icon: VenetianMask },
    { id: "Pantalón", label: "Pantalón", icon: Footprints },
    { id: "Shorts", label: "Shorts", icon: Footprints },
];

const accessoryOptions: CustomizationOption[] = [
    { id: "Gafas de sol", label: "Gafas", icon: Glasses },
    { id: "Gorro", label: "Gorro", icon: UserSquare },
    { id: "Collar", label: "Collar", icon: VenetianMask },
    { id: "Reloj", label: "Reloj", icon: Watch },
    { id: "Pendientes", label: "Pendientes", icon: VenetianMask },
    { id: "Pañuelo", label: "Pañuelo", icon: VenetianMask },
    { id: "Bolso", label: "Bolso", icon: ShoppingBag },
    { id: "Guantes", label: "Guantes", icon: Hand },
];


const fileToDataUri = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

const completedTasks = mockTasks.filter(t => t.completed).length;
const dailyProgress = (completedTasks / mockTasks.length) * 100;


const OfertaEspecial = () => {
    const { toast } = useToast();
    const [rouletteProducts, setRouletteProducts] = React.useState<Product[]>([]);
    const [isSpinning, setIsSpinning] = React.useState(false);
    const monthlyDeals = useMonthlyDeals(9);

    const spinRoulette = React.useCallback(() => {
        if (monthlyDeals.length > 0) {
            const shuffledPool = [...monthlyDeals].sort(() => 0.5 - Math.random());
            setRouletteProducts(shuffledPool.slice(0, 3));
        }
    }, [monthlyDeals]);

    React.useEffect(() => {
        if (monthlyDeals.length > 0) {
            spinRoulette();
        }
    }, [monthlyDeals, spinRoulette]);

    const handleSpin = () => {
        setIsSpinning(true);
        setRouletteProducts([]);
        setTimeout(() => {
            spinRoulette();
            setIsSpinning(false);
        }, 800);
    };

    return (
        <Card className="shadow-lg card-iridescent mt-8">
            <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold"><HighlightK text="Ruleta de Ofertas del Mes" /></CardTitle>
                <CardDescription>¡Productos seleccionados con 20% de descuento este mes! Gira para ver algunos.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="relative flex items-stretch justify-center gap-4">
                    <div className="p-4 grid grid-cols-3 gap-4 min-h-[120px] bg-muted/20 rounded-md flex-grow">
                        {rouletteProducts.length > 0 ? rouletteProducts.map((product, index) => (
                            <div key={`${product.id}-${index}`} className="block group animate-roulette-drop-in" style={{ animationDelay: `${index * 150}ms` }}>
                                <div className="aspect-square relative rounded-lg overflow-hidden border bg-background/50 shadow-md transition-transform duration-300 group-hover:scale-105 group-hover:shadow-xl h-full">
                                    <Image 
                                        src={product.imageUrl} 
                                        alt={product.name} 
                                        layout="fill"
                                        objectFit="contain"
                                        className="p-2"
                                        data-ai-hint={product.dataAiHint}
                                    />
                                    <div className="absolute bottom-0 left-0 w-full p-2 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                        <p className="text-white text-xs font-bold truncate">{product.name}</p>
                                        <p className="text-white text-xs">${product.price.toFixed(2)}</p>
                                    </div>
                                </div>
                            </div>
                        )) : Array.from({ length: 3 }).map((_, i) => (
                            <div key={i} className="aspect-square rounded-lg bg-background/30 animate-pulse" />
                        ))}
                    </div>

                    <div 
                        className={cn(
                            "flex-shrink-0 flex flex-col items-center justify-center group cursor-pointer",
                            isSpinning && "animate-pull-lever"
                        )}
                        onClick={!isSpinning ? handleSpin : undefined}
                        aria-disabled={isSpinning}
                        role="button"
                        aria-label="Girar ruleta"
                    >
                        <div className="relative z-10 flex items-center justify-center transition-transform group-hover:scale-110 group-active:scale-95 bg-transparent border-none p-0 w-12 h-12">
                            {isSpinning ? <Loader2 className="h-8 w-8 text-white animate-spin" /> : <RefreshCw className="h-8 w-8 icon-iridescent-glow" />}
                        </div>
                        <div className="h-20 flex items-center justify-center -mt-2">
                            <p className="font-bold tracking-widest text-lg text-muted-foreground [writing-mode:vertical-rl] rotate-180">
                                PUSH
                            </p>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default function RecompensasPage() {
    const { showAssistantMessage } = useAssistant();
    const [userPhoto, setUserPhoto] = useState<File | null>(null);
    
    // State for modular customization
    const [clothingDetails, setClothingDetails] = useState<Record<string, string>>({});
    const [accessoryDetails, setAccessoryDetails] = useState<Record<string, string>>({});
    const [additionalPrompt, setAdditionalPrompt] = useState("");

    const [generatedAvatars, setGeneratedAvatars] = useState<GenerateAvatarOutput | null>(null);
    const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [isAvatarSaved, setIsAvatarSaved] = useState(false);
    
    const [revealedCoupons, setRevealedCoupons] = useState<Record<string, boolean>>({});

    const handleRevealCoupon = (couponId: string) => {
        setRevealedCoupons(prev => ({...prev, [couponId]: true}));
        showAssistantMessage({
            title: "¡Cupón Revelado!",
            message: "Ya puedes copiar el código para usarlo en tu próxima compra."
        });
    };

    const copyToClipboard = (code: string) => {
        navigator.clipboard.writeText(code);
        showAssistantMessage({
            title: "¡Código copiado!",
            message: "Pégalo en la sección 'Código de Descuento' de tu carrito para aplicarlo.",
            action: <Button variant="outline" size="sm" asChild><Link href="/cart">Ir al Carrito</Link></Button>
        });
    };

    const handleCustomizationChange = (
      type: 'clothing' | 'accessory',
      item: string,
      description: string
    ) => {
      const setter = type === 'clothing' ? setClothingDetails : setAccessoryDetails;
      setter(prev => ({...prev, [item]: description}));
    };
    
    const [selectedClothingItems, setSelectedClothingItems] = useState<string[]>([]);
    const [selectedAccessoryItems, setSelectedAccessoryItems] = useState<string[]>([]);

    const handleGenerateAvatar = async () => {
        if (!userPhoto) {
            showAssistantMessage({ title: "Falta tu foto", message: "Sube una foto tuya para crear el avatar.", isError: true });
            return;
        }
        setIsGenerating(true);
        setGeneratedAvatars(null);
        setSelectedAvatar(null);
        try {
            const photoUri = await fileToDataUri(userPhoto);

            const input: GenerateAvatarInput = {
                customerPhotoDataUri: photoUri,
                clothing: selectedClothingItems.map(item => ({ item, description: clothingDetails[item] || 'Sin descripción' })),
                accessories: selectedAccessoryItems.map(item => ({ item, description: accessoryDetails[item] || 'Sin descripción' })),
                additionalPrompt: additionalPrompt
            };
            
            const result = await generateAvatar(input);
            if (result.avatarPortraitImageUri && result.avatarFullBodyImageUri) {
                setGeneratedAvatars(result);
                showAssistantMessage({ title: "¡Avatares Generados!", message: "Aquí tienes tus avatares. ¡Elige tu favorito y guárdalo en 'Mis Looks'!" });
            }
        } catch (error) {
            console.error("Error generando avatar:", error);
            showAssistantMessage({ title: "Error de IA", message: `No se pudo generar el avatar: ${error instanceof Error ? error.message : "Error desconocido"}`, isError: true });
        } finally {
            setIsGenerating(false);
        }
    };

    const handleSaveAvatar = async () => {
        if (!selectedAvatar) {
            showAssistantMessage({ title: "Selecciona un Avatar", message: "Haz clic en el avatar que quieres guardar.", isError: true });
            return;
        }
        setIsSaving(true);
        await new Promise(res => setTimeout(res, 1000)); // Simulate saving
        setIsSaving(false);
        setIsAvatarSaved(true);
        showAssistantMessage({ title: "¡Look Guardado!", message: "Tu avatar se ha guardado en 'Mis Looks' y ahora puedes usarlo como foto de perfil." });
    };

  return (
    <div className="space-y-12 rewards-page">
      <PageHeaderBanner
        title="Programa de Recompensas Kal-Z"
        description="Gana puntos, desbloquea premios y disfruta de beneficios exclusivos por ser parte de nuestra comunidad."
        imageUrl="https://placehold.co/1200x400/FFD700/2A2A2A.png"
        dataAiHint="trofeos premios"
      />

      <OfertaEspecial />

      <div className="grid lg:grid-cols-2 gap-8 items-start">
        {/* Left Column */}
        <div className="space-y-8">
            <Card className="shadow-lg card-iridescent">
                <CardHeader>
                    <div className="flex items-center mb-2">
                        <Target className="h-8 w-8 text-primary mr-3" />
                        <CardTitle className="text-xl">Misiones Diarias</CardTitle>
                    </div>
                    <CardDescription>Completa tareas para acumular puntos.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-3">
                    {mockTasks.map(task => {
                        const Icon = task.icon;
                        return (
                        <div key={task.id} className="flex items-center space-x-3 bg-muted/50 p-2 rounded-md">
                            <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                            task.completed ? 'bg-highlight-green' : 'bg-muted'
                            )}>
                                <Icon className={cn("h-5 w-5", task.completed ? 'text-highlight-green-foreground' : 'text-muted-foreground')} />
                            </div>
                            <p className={cn("flex-grow text-sm", task.completed ? 'line-through text-muted-foreground' : 'text-foreground')}>
                                {task.text}
                            </p>
                            <span className="font-semibold text-accent text-sm whitespace-nowrap">+{task.points} pts</span>
                        </div>
                        )
                    })}
                    </div>
                    <div className="mt-4 space-y-2">
                        <div className="flex justify-between items-center text-xs text-muted-foreground">
                            <span>Progreso Diario</span>
                            <span>{completedTasks} / {mockTasks.length}</span>
                        </div>
                        <Progress value={dailyProgress} className="h-2" />
                    </div>
                </CardContent>
            </Card>

            <Card className="shadow-lg card-iridescent">
                <CardHeader>
                    <div className="flex items-center mb-2">
                        <Ticket className="h-8 w-8 text-accent mr-3" />
                        <CardTitle className="text-xl">Cupones Canjeables</CardTitle>
                    </div>
                    <CardDescription>Usa tus Kalcepoints para desbloquear descuentos.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                    {mockCoupons.map((coupon) => {
                        const Icon = coupon.icon;
                        const isRevealed = revealedCoupons[coupon.id];
                        return (
                           <div key={coupon.id} className={cn("border rounded-lg p-3 flex items-center gap-4 transition-all", coupon.borderColor, coupon.bgColor)}>
                               <Icon className={cn("h-8 w-8 flex-shrink-0", coupon.color)} />
                               <div className="flex-grow">
                                   <p className="font-semibold">{coupon.title}</p>
                                   <p className="text-xs text-muted-foreground">{coupon.description}</p>
                               </div>
                               <div className="w-36 flex-shrink-0 text-center">
                                   {isRevealed ? (
                                       <div className="flex flex-col items-center gap-1">
                                           <span className="font-mono text-sm tracking-widest bg-background/50 px-2 py-0.5 rounded-md border border-dashed">
                                               {coupon.code}
                                           </span>
                                           <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => copyToClipboard(coupon.code)}>
                                               <Copy className="h-3 w-3 mr-1.5" /> Copiar
                                           </Button>
                                       </div>
                                   ) : (
                                       <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => handleRevealCoupon(coupon.id)}>
                                           <Scissors className="h-3 w-3 mr-1.5" /> Revelar
                                       </Button>
                                   )}
                               </div>
                           </div>
                        )
                    })}
                </CardContent>
            </Card>
        </div>

        {/* Right Column - Avatar Studio */}
        <div>
            <Card className="shadow-2xl card-iridescent">
                <CardHeader>
                    <CardTitle className="text-2xl flex items-center gap-3">
                        <Wand2 className="h-7 w-7 text-accent" />
                        Avatar Studio (Estilo "Los Sims")
                    </CardTitle>
                    <CardDescription>¡Crea tu avatar 3D con IA! Sube tu foto, describe tu ropa, accesorios y estilo, y mira la magia.</CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                        <div>
                            <Label className="font-semibold flex items-center gap-2 mb-2"><User className="h-4 w-4" /> 1. Sube tu foto</Label>
                            <FileUploader 
                                onFileSelect={setUserPhoto}
                                accept="image/png, image/jpeg"
                                label="Sube una foto clara de tu cara"
                            />
                             <p className="text-xs text-muted-foreground mt-2">Para mejores resultados, usa una foto de frente y con buena iluminación.</p>
                        </div>
                        
                         <div>
                            <Label className="font-semibold flex items-center gap-2 mb-2"><Shirt className="h-4 w-4" /> 2. Elige y Describe tu Ropa</Label>
                            <ToggleGroup type="multiple" value={selectedClothingItems} onValueChange={(items) => setSelectedClothingItems(items)} className="flex flex-wrap gap-2 justify-start">
                                {clothingOptions.map(({id, icon: Icon}) => (
                                <ToggleGroupItem key={id} value={id} aria-label={id} className="flex flex-col h-14 w-14 text-xs">
                                    <Icon className="h-5 w-5 mb-0.5" />
                                    {id}
                                </ToggleGroupItem>
                                ))}
                            </ToggleGroup>
                            <div className="space-y-2 mt-3">
                               {selectedClothingItems.map(item => (
                                 <Input key={item} placeholder={`Describe ${item}...`} onChange={(e) => handleCustomizationChange('clothing', item, e.target.value)} className="h-8 text-xs"/>
                               ))}
                            </div>
                        </div>
                        
                        <div>
                            <Label className="font-semibold flex items-center gap-2 mb-2"><Sun className="h-4 w-4" /> 3. Añade y Describe Accesorios</Label>
                             <ToggleGroup type="multiple" value={selectedAccessoryItems} onValueChange={(items) => setSelectedAccessoryItems(items)} className="flex flex-wrap gap-2 justify-start">
                                {accessoryOptions.map(({id, icon: Icon}) => (
                                <ToggleGroupItem key={id} value={id} aria-label={id} className="flex flex-col h-14 w-14 text-xs">
                                     <Icon className="h-5 w-5 mb-0.5" />
                                    {id}
                                </ToggleGroupItem>
                                ))}
                            </ToggleGroup>
                             <div className="space-y-2 mt-3">
                               {selectedAccessoryItems.map(item => (
                                 <Input key={item} placeholder={`Describe ${item}...`} onChange={(e) => handleCustomizationChange('accessory', item, e.target.value)} className="h-8 text-xs"/>
                               ))}
                            </div>
                        </div>

                        <div>
                             <Label className="font-semibold flex items-center gap-2 mb-2"><Sparkles className="h-4 w-4" /> 4. Detalles Adicionales y Estilo</Label>
                             <Textarea 
                                placeholder="Ej: Pelo color azul, fondo de atardecer, estilo cyberpunk..."
                                value={additionalPrompt}
                                onChange={e => setAdditionalPrompt(e.target.value)}
                                rows={2}
                             />
                        </div>
                        <Button onClick={handleGenerateAvatar} disabled={isGenerating} className="w-full">
                            {isGenerating ? <Image src="/images/splash.gif" alt="Generando..." width={24} height={24} unoptimized className="mr-2" /> : <Wand2 className="mr-2" />}
                            {isGenerating ? "Generando Avatar..." : "Generar Avatar con IA"}
                        </Button>
                    </div>
                     <div className="space-y-4">
                        <Label className="font-semibold flex items-center gap-2"><Gem className="h-4 w-4" /> 5. Resultado (¡Elige tu favorito!)</Label>
                        <div className="w-full grid grid-cols-2 gap-2">
                            {isGenerating ? (
                                <div className="col-span-2 aspect-square flex items-center justify-center">
                                    <div className="text-center">
                                        <Image src="/images/splash.gif" alt="Cargando..." width={128} height={128} unoptimized />
                                        <p className="text-sm mt-2 text-muted-foreground">Creando magia...</p>
                                    </div>
                                </div>
                            ) : generatedAvatars ? (
                                <>
                                    <div 
                                        className={cn("aspect-square relative rounded-lg bg-muted/30 overflow-hidden cursor-pointer transition-all", selectedAvatar === generatedAvatars.avatarPortraitImageUri ? "ring-2 ring-primary" : "hover:opacity-80")}
                                        onClick={() => setSelectedAvatar(generatedAvatars.avatarPortraitImageUri)}
                                    >
                                        <Image src={generatedAvatars.avatarPortraitImageUri} alt="Avatar generado - Retrato" layout="fill" objectFit="contain" className="p-2" />
                                        <div className="absolute bottom-0 w-full bg-black/50 p-1 text-center"><p className="text-white text-xs font-semibold">Retrato</p></div>
                                    </div>
                                    <div 
                                        className={cn("aspect-square relative rounded-lg bg-muted/30 overflow-hidden cursor-pointer transition-all", selectedAvatar === generatedAvatars.avatarFullBodyImageUri ? "ring-2 ring-primary" : "hover:opacity-80")}
                                        onClick={() => setSelectedAvatar(generatedAvatars.avatarFullBodyImageUri)}
                                    >
                                        <Image src={generatedAvatars.avatarFullBodyImageUri} alt="Avatar generado - Cuerpo Completo" layout="fill" objectFit="contain" className="p-2" />
                                        <div className="absolute bottom-0 w-full bg-black/50 p-1 text-center"><p className="text-white text-xs font-semibold">Cuerpo Completo</p></div>
                                    </div>
                                </>
                            ) : (
                                <div className="col-span-2 aspect-square border border-dashed rounded-lg flex items-center justify-center bg-background/30">
                                    <p className="text-sm text-muted-foreground text-center p-4">Tus avatares aparecerán aquí.</p>
                                </div>
                            )}
                        </div>
                     </div>
                </CardContent>
                <CardFooter className="flex-col gap-4">
                    {generatedAvatars && !isGenerating && (
                         <Button onClick={handleSaveAvatar} disabled={isSaving || isAvatarSaved || !selectedAvatar} className="w-full">
                            {isSaving ? <Image src="/images/splash.gif" alt="Guardando..." width={24} height={24} unoptimized className="mr-2" /> : <Save className="mr-2" />}
                            {isAvatarSaved ? "¡Guardado!" : "Guardar en Mis Looks"}
                        </Button>
                    )}
                    {isAvatarSaved && (
                         <Alert variant="default" className="text-center">
                           <Info className="h-4 w-4"/>
                           <AlertTitle>¡Aviso!</AlertTitle>
                           <AlertDescription>
                            Has guardado tu primer look. A partir de ahora, los accesorios premium en el Avatar Studio se desbloquearán con tus <strong>Kalcepoints</strong>.
                           </AlertDescription>
                         </Alert>
                    )}
                </CardFooter>
            </Card>
        </div>
      </div>

      <div className="pt-12">
        <PilonCarousel />
      </div>
    </div>
  );
}

    