
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  galleryImages?: string[];
  category: string;
  subCategory: string;
  availableSizes: string[];
  availableColors: string[];
  dataAiHint?: string;
  isVideo?: boolean; // Nuevo: para marcar si la imageUrl es un video
  staticImageUrlForAI?: string; // Nuevo: imagen estática para IA si el principal es video
}

export interface CustomizationOptions {
  text?: {
    content: string;
    font: string;
    fontFamily: string; // Add this for font selection
    fontSize: number; // Add this for font size
    color: string;
    position: { x: number; y: number };
  };
  design?: {
    url: string;
    position: { x: number; y: number };
    scale: number;
  };
}

export interface UserDesign {
  id: string;
  userId: string;
  productId: string;
  customization: CustomizationOptions;
  finalImageUrl: string;
  isPublic: boolean;
  createdAt: Date;
  dataAiHint?: string;
}

export interface UserProfile {
  id: string;
  email: string;
  displayName?: string;
  profilePictureUrl?: string;
  bio?: string;
  socialLinks?: {
    facebook?: string;
    instagram?: string;
    twitter?: string;
  };
  dataAiHintAvatar?: string;
  isAdminMaster?: boolean; // Added for master admin identification
}

export interface Delivery {
  id: string;
  orderId: string;
  customerName: string;
  address: string;
  status: "pending" | "shipped" | "delivered" | "cancelled";
  items: Array<{ productId: string; quantity: number; name: string }>;
  createdAt: Date;
  estimatedDeliveryDate?: Date;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  imageUrl: string;
  customization?: CustomizationOptions;
  originalPrice?: number;
  viralDesignId?: string;
  dataAiHint?: string;
  isVideo?: boolean; // Añadido para consistencia, aunque en mockCartItems se puede inferir
}

export interface KalZaiDesign {
  id: string;
  userId: string;
  name: string;
  baseProductId?: string;
  imageDataUri: string;
  aiPromptUsed?: string;
  toolsUsed?: string[];
  createdAt: Date;
  isPublic: boolean;
  dataAiHint?: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName?: string;
  userAvatarUrl?: string;
  text: string;
  createdAt: Date;
}

export interface Rating {
  userId: string;
  value: 1 | 2 | 3 | 4 | 5;
  ratedAt: Date;
}

export interface ViralPost {
  id: string;
  kalZaiDesignId: string;
  userId: string;
  userName?: string;
  userAvatarUrl?: string;
  dataAiHintAvatar?: string;
  caption?: string;
  sharedAt: Date;
  comments: Comment[];
  ratings: Rating[];
  averageRating?: number;
  purchasePrice?: number;
  design?: Pick<KalZaiDesign, 'imageDataUri' | 'name' | 'baseProductId' | 'dataAiHint'>;
}
