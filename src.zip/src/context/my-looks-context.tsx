
"use client";

import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect } from 'react';
import type { KalZaiDesign } from '@/types';
import { mockKalZaiDesigns } from '@/data/mock';

const LOOKS_STORAGE_KEY = 'kalz-my-looks';

interface MyLooksContextType {
  looks: KalZaiDesign[];
  addLook: (look: KalZaiDesign) => void;
  removeLook: (lookId: string) => void;
}

const MyLooksContext = createContext<MyLooksContextType | undefined>(undefined);

export const MyLooksProvider = ({ children }: { children: ReactNode }) => {
  const [looks, setLooks] = useState<KalZaiDesign[]>([]);

  // Load looks from localStorage on initial render
  useEffect(() => {
    try {
      const storedLooks = localStorage.getItem(LOOKS_STORAGE_KEY);
      // For the prototype, we initialize with mock data if localStorage is empty
      const initialLooks = storedLooks ? JSON.parse(storedLooks) : mockKalZaiDesigns.filter(d => d.userId === "artistaUrbano" || d.userId === "creadorMistico");
      setLooks(initialLooks);
    } catch (error) {
      console.error("Failed to load looks from localStorage", error);
      // Fallback to mock data on error
      setLooks(mockKalZaiDesigns.filter(d => d.userId === "artistaUrbano" || d.userId === "creadorMistico"));
    }
  }, []);

  // Persist to localStorage whenever looks change
  useEffect(() => {
    try {
      localStorage.setItem(LOOKS_STORAGE_KEY, JSON.stringify(looks));
    } catch (error) {
      console.error("Failed to save looks to localStorage", error);
    }
  }, [looks]);

  const addLook = useCallback((look: KalZaiDesign) => {
    setLooks(prevLooks => [look, ...prevLooks]);
  }, []);

  const removeLook = useCallback((lookId: string) => {
    setLooks(prevLooks => prevLooks.filter(look => look.id !== lookId));
  }, []);

  return (
    <MyLooksContext.Provider value={{ looks, addLook, removeLook }}>
      {children}
    </MyLooksContext.Provider>
  );
};

export const useMyLooks = (): MyLooksContextType => {
  const context = useContext(MyLooksContext);
  if (context === undefined) {
    throw new Error('useMyLooks must be used within a MyLooksProvider');
  }
  return context;
};
