"use client";

import React, { createContext, useState, useContext, ReactNode, useEffect, Dispatch, SetStateAction } from 'react';
import { usePathname } from 'next/navigation';

type Locale = 'es' | 'en';

interface LanguageContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  translate: (translations: Record<Locale, string>) => string;
  pathname: string | null;
  isLoadingPage: boolean;
  setIsLoadingPage: Dispatch<SetStateAction<boolean>>;
  isGuestWelcoming: boolean;
  setIsGuestWelcoming: Dispatch<SetStateAction<boolean>>;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [locale, setLocaleState] = useState<Locale>('es');
  const [isLoadingPage, setIsLoadingPage] = useState(false);
  const [isGuestWelcoming, setIsGuestWelcoming] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const savedLocale = localStorage.getItem('kalzvieja-locale') as Locale | null;
    if (savedLocale && (savedLocale === 'es' || savedLocale === 'en')) {
      setLocaleState(savedLocale);
    }
  }, []);

  const setLocale = (newLocale: Locale) => {
    setIsLoadingPage(true);
    setLocaleState(newLocale);
    localStorage.setItem('kalzvieja-locale', newLocale);
    // Add a small delay to allow the loader to be visible during language change
    setTimeout(() => setIsLoadingPage(false), 500);
  };

  const translate = (translations: Record<Locale, string>): string => {
    return translations[locale] || translations['es'] || '';
  };

  return (
    <LanguageContext.Provider value={{ locale, setLocale, translate, pathname, isLoadingPage, setIsLoadingPage, isGuestWelcoming, setIsGuestWelcoming }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
