
"use client";

import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';

interface AssistantMessage {
  title: string;
  message: string;
  isError?: boolean;
  action?: ReactNode;
}

interface AssistantContextType {
  assistantMessage: AssistantMessage | null;
  showAssistantMessage: (message: AssistantMessage) => void;
  clearAssistantMessage: () => void;
}

const AssistantContext = createContext<AssistantContextType | undefined>(undefined);

export const AssistantProvider = ({ children }: { children: ReactNode }) => {
  const [assistantMessage, setAssistantMessage] = useState<AssistantMessage | null>(null);

  const showAssistantMessage = useCallback((message: AssistantMessage) => {
    setAssistantMessage(message);
  }, []);

  const clearAssistantMessage = useCallback(() => {
    setAssistantMessage(null);
  }, []);

  return (
    <AssistantContext.Provider value={{ assistantMessage, showAssistantMessage, clearAssistantMessage }}>
      {children}
    </AssistantContext.Provider>
  );
};

export const useAssistant = (): AssistantContextType => {
  const context = useContext(AssistantContext);
  if (context === undefined) {
    throw new Error('useAssistant must be used within an AssistantProvider');
  }
  return context;
};
