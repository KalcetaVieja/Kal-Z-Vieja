"use client";

import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect } from 'react';

const HISTORY_KEY = 'kalz-navigation-history';
const MAX_HISTORY_ITEMS = 15;

export interface HistoryEntry {
  path: string;
  title: string;
  timestamp: number;
}

interface NavigationHistoryContextType {
  history: HistoryEntry[];
  addHistoryEntry: (entry: Omit<HistoryEntry, 'timestamp'>) => void;
  clearHistory: () => void;
}

const NavigationHistoryContext = createContext<NavigationHistoryContextType | undefined>(undefined);

export const NavigationHistoryProvider = ({ children }: { children: ReactNode }) => {
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  useEffect(() => {
    try {
      const storedItems = localStorage.getItem(HISTORY_KEY);
      if (storedItems) {
        setHistory(JSON.parse(storedItems));
      }
    } catch (error) {
      console.error("Failed to parse navigation history from localStorage", error);
    }
  }, []);

  const addHistoryEntry = useCallback((entry: Omit<HistoryEntry, 'timestamp'>) => {
    setHistory(prevHistory => {
      if (prevHistory.length > 0 && prevHistory[0].path === entry.path) {
        return prevHistory;
      }
      const newEntry: HistoryEntry = { ...entry, timestamp: Date.now() };
      const newHistory = [newEntry, ...prevHistory];
      const limitedHistory = newHistory.slice(0, MAX_HISTORY_ITEMS);
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(limitedHistory));
      } catch (error) {
        console.error("Failed to save navigation history to localStorage", error);
      }
      return limitedHistory;
    });
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    try {
      localStorage.removeItem(HISTORY_KEY);
    } catch (error) {
      console.error("Failed to clear navigation history from localStorage", error);
    }
  }, []);

  return (
    <NavigationHistoryContext.Provider value={{ history, addHistoryEntry, clearHistory }}>
      {children}
    </NavigationHistoryContext.Provider>
  );
};

export const useNavigationHistory = (): NavigationHistoryContextType => {
  const context = useContext(NavigationHistoryContext);
  if (context === undefined) {
    throw new Error('useNavigationHistory must be used within a NavigationHistoryProvider');
  }
  return context;
};
