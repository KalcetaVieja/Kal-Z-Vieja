
import { config } from 'dotenv';
config();

import '@/ai/flows/virtual-try-on.ts';
import '@/ai/flows/design-suggestions.ts';
import '@/ai/flows/avatar-generator.ts';
import '@/ai/flows/remove-background.ts';
