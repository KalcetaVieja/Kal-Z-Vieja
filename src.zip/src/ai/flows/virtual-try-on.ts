
// VirtualTryOn.tsx
'use server';
/**
 * @fileOverview Un agente de IA para prueba virtual de ropa.
 *
 * - virtualTryOn - Una función que maneja el proceso de prueba virtual.
 * - VirtualTryOnInput - El tipo de entrada para la función virtualTryOn.
 * - VirtualTryOnOutput - El tipo de retorno para la función virtualTryOn.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const VirtualTryOnInputSchema = z.object({
  clothingDataUri: z
    .string()
    .describe(
      "Una foto de la prenda de vestir, como un URI de datos que debe incluir un tipo MIME y usar codificación Base64. Formato esperado: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  customerPhotoDataUri: z
    .string()
    .describe(
      "Una foto del cliente, como un URI de datos que debe incluir un tipo MIME y usar codificación Base64. Formato esperado: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  customizations: z.string().describe('Las personalizaciones elegidas por el usuario.'),
});
export type VirtualTryOnInput = z.infer<typeof VirtualTryOnInputSchema>;

const VirtualTryOnOutputSchema = z.object({
  editedImage: z
    .string()
    .describe(
      "Una foto del cliente usando la prenda de vestir personalizada, como un URI de datos que debe incluir un tipo MIME y usar codificación Base64. Formato esperado: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type VirtualTryOnOutput = z.infer<typeof VirtualTryOnOutputSchema>;

export async function virtualTryOn(input: VirtualTryOnInput): Promise<VirtualTryOnOutput> {
  return virtualTryOnFlow(input);
}

const virtualTryOnFlow = ai.defineFlow(
  {
    name: 'virtualTryOnFlow',
    inputSchema: VirtualTryOnInputSchema,
    outputSchema: VirtualTryOnOutputSchema,
  },
  async input => {
    const {media} = await ai.generate({
      model: 'googleai/gemini-1.5-flash-latest',
      prompt: [
        {media: {url: input.customerPhotoDataUri}},
        {media: {url: input.clothingDataUri}},
        {
          text: `Eres un generador de avatares y mockups hiperrealistas. Tu objetivo es crear una nueva imagen hiperrealista de una persona (de la cintura para arriba) usando la prenda seleccionada. La cara de la persona en la nueva imagen debe basarse directamente en la foto del cliente proporcionada.

**Instrucciones Clave:**

1.  **Fusión Facial:** Analiza la foto del cliente para capturar sus rasgos faciales (ojos, nariz, boca, forma de la cara). Debes usar estos rasgos para generar la cara de la persona en la nueva imagen. El resultado debe parecerse al cliente.
2.  **Generación de Mockup:** NO edites la foto original del cliente. En su lugar, genera una escena completamente nueva con un "mockup" humano (de la cintura para arriba) que vista la prenda proporcionada.
3.  **Ajuste Natural:** La pose, el cuerpo y la iluminación del mockup generado deben ser naturales y realistas, asegurando que la prenda se ajuste de manera creíble. El fondo debe ser neutro (como una pared de estudio o un fondo liso) para no distraer.
4.  **Aplicar Personalizaciones:** Si se proporcionan personalizaciones, aplícalas a la prenda en el mockup. Personalizaciones: \`${input.customizations}\`. Si dice 'Sin personalización adicional', ignóralo.
5.  **Salida Final:** El resultado debe ser únicamente la fotografía del mockup hiperrealista generado. No incluyas texto, logos ni otros elementos ajenos.`,
        },
      ],
      config: {
        responseModalities: ['TEXT', 'IMAGE'],
      },
    });

    if (!media?.url) {
      throw new Error('La IA no pudo generar una imagen de prueba virtual.');
    }

    return {editedImage: media.url};
  }
);
