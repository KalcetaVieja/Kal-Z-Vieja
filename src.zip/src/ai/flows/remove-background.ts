
'use server';

/**
 * @fileOverview Un agente de IA para eliminar el fondo de las imágenes.
 *
 * - removeBackground - Una función que maneja el proceso de eliminación de fondo.
 * - RemoveBackgroundInput - El tipo de entrada para la función removeBackground.
 * - RemoveBackgroundOutput - El tipo de retorno para la función removeBackground.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const RemoveBackgroundInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "La imagen de la cual se eliminará el fondo, como un URI de datos que debe incluir un tipo MIME y usar codificación Base64. Formato esperado: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type RemoveBackgroundInput = z.infer<typeof RemoveBackgroundInputSchema>;

const RemoveBackgroundOutputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "La imagen resultante con el fondo transparente, como un URI de datos. Formato esperado: 'data:image/png;base64,<encoded_data>'."
    ),
});
export type RemoveBackgroundOutput = z.infer<typeof RemoveBackgroundOutputSchema>;

export async function removeBackground(input: RemoveBackgroundInput): Promise<RemoveBackgroundOutput> {
  return removeBackgroundFlow(input);
}

const removeBackgroundFlow = ai.defineFlow(
  {
    name: 'removeBackgroundFlow',
    inputSchema: RemoveBackgroundInputSchema,
    outputSchema: RemoveBackgroundOutputSchema,
  },
  async input => {
    const {media} = await ai.generate({
      model: 'googleai/gemini-1.5-flash-latest',
      prompt: [
        {media: {url: input.imageDataUri}},
        {
          text: `Tu tarea es identificar el sujeto principal (persona, objeto, animal, etc.) y eliminar completamente el fondo. El resultado DEBE ser una imagen PNG del sujeto principal aislado sobre un fondo perfectamente transparente.

          **Instrucciones Críticas:**
          1.  **Fondo Transparente:** La imagen de salida DEBE tener un fondo perfectamente transparente.
          2.  **Aislar el Sujeto:** Solo el sujeto principal debe permanecer. Todos los demás elementos del fondo deben ser eliminados.
          3.  **NO Alterar el Sujeto:** No cambies los colores, la forma ni ninguna parte del sujeto principal. El sujeto debe ser preservado exactamente como está en la imagen original.`,
        },
      ],
      config: {
        responseModalities: ['TEXT', 'IMAGE'],
        safetySettings: [
            { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
            { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
            { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
            { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
        ]
      },
    });

    if (!media?.url) {
      throw new Error('La IA no pudo procesar la imagen para quitar el fondo.');
    }

    return {imageDataUri: media.url};
  }
);
