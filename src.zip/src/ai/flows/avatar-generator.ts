
'use server';

/**
 * @fileOverview Un agente de IA para generar avatares 3D estilizados.
 *
 * - generateAvatar - Una función que maneja el proceso de creación de avatares.
 * - GenerateAvatarInput - El tipo de entrada para la función generateAvatar.
 * - GenerateAvatarOutput - El tipo de retorno para la función generateAvatar.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CustomizationDetailSchema = z.object({
    item: z.string(),
    description: z.string(),
});

const GenerateAvatarInputSchema = z.object({
  customerPhotoDataUri: z
    .string()
    .describe(
      "Una foto del cliente, como un URI de datos que debe incluir un tipo MIME y usar codificación Base64. Formato esperado: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  clothing: z.array(CustomizationDetailSchema).describe('Una lista de prendas de vestir y sus descripciones detalladas.'),
  accessories: z.array(CustomizationDetailSchema).describe('Una lista de accesorios y sus descripciones detalladas.'),
  additionalPrompt: z.string().optional().describe('Instrucciones adicionales del usuario para detalles como el color del pelo, el fondo, etc.'),
});
export type GenerateAvatarInput = z.infer<typeof GenerateAvatarInputSchema>;


const GenerateAvatarOutputSchema = z.object({
  avatarPortraitImageUri: z
    .string()
    .describe(
      "La imagen generada del retrato del avatar, como un URI de datos. Formato esperado: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  avatarFullBodyImageUri: z
    .string()
    .describe(
      "La imagen generada del avatar de cuerpo completo, como un URI de datos. Formato esperado: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type GenerateAvatarOutput = z.infer<typeof GenerateAvatarOutputSchema>;

export async function generateAvatar(input: GenerateAvatarInput): Promise<GenerateAvatarOutput> {
  return generateAvatarFlow(input);
}

const generateAvatarFlow = ai.defineFlow(
  {
    name: 'generateAvatarFlow',
    inputSchema: GenerateAvatarInputSchema,
    outputSchema: GenerateAvatarOutputSchema,
  },
  async (input) => {
    const generateImage = async (promptType: 'portrait' | 'fullBody') => {
      let specificInstructions = '';
      if (promptType === 'portrait') {
        specificInstructions = 'Focus on creating a detailed and stylized **close-up portrait** from the chest up. The background should be simple and complementary.';
      } else {
        specificInstructions = 'Create a **full-body shot** of the character, showing them from head to toe, including their shoes and the complete outfit described. The character should be in a dynamic or neutral pose against a simple background that matches the style.';
      }
      
      const formatDetails = (items: z.infer<typeof CustomizationDetailSchema>[]) => {
        if (items.length === 0) return 'Ninguno';
        return items.map(item => `- ${item.item}: ${item.description}`).join('\n');
      };

      const clothingDetails = formatDetails(input.clothing);
      const accessoriesDetails = formatDetails(input.accessories);

      const {media} = await ai.generate({
        model: 'googleai/gemini-1.5-flash-latest',
        prompt: [
          {media: {url: input.customerPhotoDataUri}},
          {
            text: `Eres un diseñador experto de avatares 3D con un estilo que fusiona la estética de "Los Sims" y "Fortnite", pero con un toque de realismo estilizado tipo Pixar. Tu tarea es transformar la foto de un usuario en un avatar 3D estilizado y de alta calidad basado en sus selecciones detalladas.

**Instrucciones Clave:**
1.  **Estilo del Avatar:** El resultado final debe ser un personaje 3D atractivo, moderno y con personalidad. Considera estilos como "Realismo Estilizado", "Plastilina Digital" o la fusión "Sims/Fortnite". El avatar debe ser "cool".
2.  **Referencia Facial:** Usa los rasgos faciales de la persona en la foto como la referencia principal para crear la cara del avatar. Captura su esencia, pero adáptala al estilo 3D solicitado.
3.  **Combinar Elementos:** Viste al avatar con la ropa y los accesorios descritos a continuación, prestando atención a los detalles específicos que el usuario ha proporcionado.

**Detalles de Personalización del Usuario:**

*   **Ropa Principal y Detalles:**
${clothingDetails}

*   **Accesorios a Incluir y Detalles:**
${accessoriesDetails}

*   **Instrucciones Adicionales (Pelo, Fondo, etc.):** ${input.additionalPrompt || 'El diseñador tiene libertad creativa.'}

**Reglas de Generación de Imagen:**
*   **Encuadre:** Sigue estrictamente estas instrucciones de encuadre: ${specificInstructions}
*   **Fondo:** El fondo debe ser simple, complementario (un degradado de color suave o una pared de estudio) y no debe distraer la atención del avatar.
*   **Salida Limpia:** El resultado debe ser únicamente la imagen del avatar 3D generado. No incluyas texto, logos ni otros elementos ajenos.`,
          },
        ],
        config: {
          responseModalities: ['TEXT', 'IMAGE'],
        },
      });

      if (!media?.url) {
        throw new Error(`La IA no pudo generar una imagen para el tipo: ${promptType}`);
      }
      return media.url;
    };

    const [portraitUrl, fullBodyUrl] = await Promise.all([
      generateImage('portrait'),
      generateImage('fullBody'),
    ]);

    return {
      avatarPortraitImageUri: portraitUrl,
      avatarFullBodyImageUri: fullBodyUrl,
    };
  }
);
