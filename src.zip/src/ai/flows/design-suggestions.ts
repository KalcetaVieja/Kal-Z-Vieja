
'use server';

/**
 * @fileOverview Proporciona sugerencias de diseño asistidas por IA basadas en las preferencias del usuario para la personalización de ropa.
 *
 * - designSuggestions - Una función que genera sugerencias de diseño.
 * - DesignSuggestionsInput - El tipo de entrada para la función designSuggestions.
 * - DesignSuggestionsOutput - El tipo de retorno para la función designSuggestions.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DesignSuggestionsInputSchema = z.object({
  style: z
    .string()
    .describe(
      'El estilo artístico seleccionado por el usuario (p. ej., Dibujo, Realista, Caricatura).'
    ),
  topic: z
    .string()
    .describe(
      'El tema o idea principal que el usuario quiere en el diseño (p. ej., un perro astronauta, flores de cerezo).'
    ),
});

export type DesignSuggestionsInput = z.infer<typeof DesignSuggestionsInputSchema>;

const DesignSuggestionsOutputSchema = z.object({
  images: z.array(
    z.object({
      imageDataUri: z.string().describe("La imagen generada como un URI de datos que debe incluir un tipo MIME y usar codificación Base64. Formato esperado: 'data:<mimetype>;base64,<encoded_data>'."),
    })
  ).length(3).describe('Una lista de exactamente 3 imágenes de diseño generadas en base a las preferencias del usuario.'),
});

export type DesignSuggestionsOutput = z.infer<typeof DesignSuggestionsOutputSchema>;

export async function designSuggestions(input: DesignSuggestionsInput): Promise<DesignSuggestionsOutput> {
  return designSuggestionsFlow(input);
}

const designSuggestionsFlow = ai.defineFlow(
  {
    name: 'designSuggestionsFlow',
    inputSchema: DesignSuggestionsInputSchema,
    outputSchema: DesignSuggestionsOutputSchema,
  },
  async input => {
    const generateImage = async () => {
        const {media} = await ai.generate({
            model: 'googleai/imagen-4.0-fast-generate-001',
            prompt: `Tu tarea es generar un único diseño gráfico moderno y de aspecto profesional. Este diseño está destinado a ser impreso en una camiseta, pero NO DEBES generar una imagen de una camiseta.

            **INSTRUCCIONES CRÍTICAS:**
            1.  **DISEÑO AISLADO:** La salida debe ser ÚNICAMENTE el diseño gráfico en sí. NO incluyas una camiseta, un modelo, una prenda de vestir ni ningún otro producto.
            2.  **FONDO SIMPLE:** El diseño debe estar sobre un fondo simple, de un solo color y que no distraiga (por ejemplo, gris claro, blanco o un degradado suave). Esto es para facilitar la eliminación posterior del fondo. NO uses un fondo transparente inicialmente.
            3.  **ADHERIRSE AL PROMPT:** El diseño debe seguir estrictamente el estilo y tema solicitados por el usuario.

            **Estilo Artístico:** ${input.style}
            **Tema/Idea del Diseño:** ${input.topic}

            **Ejemplo de lo que NO se debe hacer:** Generar una foto de una persona vistiendo una camiseta con el diseño.
            **Ejemplo de lo que SÍ se debe hacer:** Generar solo el elemento de diseño (por ejemplo, solo el perro genial, solo el patrón abstracto) sobre un fondo de color sólido y simple.
            `,
        });
        if (!media?.url) {
            throw new Error("AI failed to generate an image.");
        }
        return { imageDataUri: media.url };
    };

    // Generate 3 images in parallel
    const imagePromises = [generateImage(), generateImage(), generateImage()];
    const images = await Promise.all(imagePromises);

    return { images };
  }
);
