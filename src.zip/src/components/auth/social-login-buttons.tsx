
"use client"

import React from 'react';
import { Button } from "@/components/ui/button"
import { FacebookIcon, MessageCircle, User } from "lucide-react"
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import Link from 'next/link';
import { useLanguage } from '@/context/language-context';

const GoogleIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="24px" height="24px">
    <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/>
    <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/>
    <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/>
    <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.574l0.012-0.012l6.19,5.238C39.902,35.697,44,30.438,44,24C44,22.659,43.862,21.35,43.611,20.083z"/>
  </svg>
);

const MASTER_ADMIN_EMAIL = "kalceta.vieja@gmail.com";

interface SocialLoginButtonsProps {}

export function SocialLoginButtons({}: SocialLoginButtonsProps) {
  const router = useRouter();
  const { toast } = useToast();
  const { setIsLoadingPage, setIsGuestWelcoming } = useLanguage();

  const handleLogin = (provider: string, isAdminAttempt: boolean = false) => {
    localStorage.setItem("isLoggedIn", "true");

    if (provider === 'Invitado') {
      localStorage.removeItem("isKalZVijaMasterAdmin");
      setIsGuestWelcoming(true); // Trigger animation
      // Navigate immediately, the welcome animation will play over the next screen
      router.push("/auth/guest-setup");
    } else {
      setIsLoadingPage(true);
      if (isAdminAttempt) {
        localStorage.setItem("isKalZVijaMasterAdmin", "true");
        toast({
          title: "¡Acceso de Master Admin Koncedido!",
          description: `Has iniciado sesión komo ${MASTER_ADMIN_EMAIL}.`,
        });
        router.push("/auth/setup");
      } else { // Other social logins
        localStorage.removeItem("isKalZVijaMasterAdmin");
        toast({
          title: `Inicio de Sesión kon ${provider} (Simulado)`,
          description: '¡Bienvenido de nuevo a Kal-Z-Vieja!',
        });
        router.push("/auth/setup");
      }
    }
  };
  
  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-md">
      {/* For prototype, this is the master admin login */}
      <div className="w-full tremble-1">
        <button onClick={() => handleLogin('Google', true)} className="btn btn-google w-full">
          Google
        </button>
      </div>

      <div className="w-full tremble-2">
        <button onClick={() => handleLogin('Facebook')} className="btn btn-facebook w-full">
          Facebook
        </button>
      </div>
      
      <div className="w-full tremble-3">
       <Link href="https://wa.me/525661252862" target="_blank" rel="noopener noreferrer" className="w-full">
        <button className="btn btn-whatsapp w-full">
            WhatsApp
        </button>
      </Link>
      </div>

      <div className="relative flex py-2 items-center w-full">
        <div className="flex-grow border-t border-muted-foreground/50"></div>
        <span className="flex-shrink mx-4 text-muted-foreground text-xs">O</span>
        <div className="flex-grow border-t border-muted-foreground/50"></div>
      </div>
      
      <div className="w-full">
        <Button onClick={() => handleLogin('Invitado')} variant="secondary" className="w-full h-12">
            <User className="mr-2 h-4 w-4"/>
            Entrar como Invitado
        </Button>
      </div>

    </div>
  );
}
