
"use client"

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { FileUploader } from '@/components/ui/file-uploader';
import { UserCircle, Save, Facebook, Instagram, Twitter } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';
import type { UserProfile } from '@/types';

interface ProfileFormProps {
  initialProfile: UserProfile;
}

export function ProfileForm({ initialProfile }: ProfileFormProps) {
  const [displayName, setDisplayName] = useState(initialProfile.displayName || '');
  const [bio, setBio] = useState(initialProfile.bio || '');
  const [profilePicture, setProfilePicture] = useState<File | null>(null);
  const [profilePicturePreview, setProfilePicturePreview] = useState<string | null>(initialProfile.profilePictureUrl || null);
  const [socialLinks, setSocialLinks] = useState(initialProfile.socialLinks || { facebook: '', instagram: 'https://www.instagram.com/kalzvieja?igsh=MWk4MnJtZXBpMmUxeg==', twitter: '' });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handlePictureUpload = (file: File | null) => {
    setProfilePicture(file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicturePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else if (!initialProfile.profilePictureUrl) { 
      setProfilePicturePreview(null);
    } else { 
       setProfilePicturePreview(initialProfile.profilePictureUrl);
    }
  };

  const handleSocialLinkChange = (platform: keyof NonNullable<UserProfile['socialLinks']>, value: string) => {
    setSocialLinks(prev => ({ ...prev, [platform]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsLoading(false);
    toast({
      title: "Perfil Actualizado",
      description: "Tu información de perfil ha sido guardada con éxito.",
    });
  };

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-xl">
      <form onSubmit={handleSubmit}>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center">
            <UserCircle className="mr-2 h-6 w-6 text-accent" />
            Personalizar Perfil
          </CardTitle>
          <CardDescription>Actualiza tu foto, información personal y redes sociales.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="avatar">Foto de Perfil</Label>
            <div className="flex items-center gap-4">
              {profilePicturePreview ? (
                <Image 
                  src={profilePicturePreview} 
                  alt="Vista previa del avatar" 
                  width={80} 
                  height={80} 
                  className="rounded-full object-cover aspect-square"
                  data-ai-hint={initialProfile.dataAiHintAvatar || "avatar persona"}
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center">
                  <UserCircle className="w-10 h-10 text-muted-foreground" />
                </div>
              )}
              <FileUploader 
                id="avatar"
                onFileSelect={handlePictureUpload} 
                accept="image/jpeg, image/png" 
                label="Cambiar foto (JPG, PNG)"
                className="max-w-xs"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="displayName">Nombre de Usuario</Label>
            <Input 
              id="displayName" 
              value={displayName} 
              onChange={(e) => setDisplayName(e.target.value)} 
              placeholder="Tu nombre visible"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Biografía</Label>
            <Textarea 
              id="bio" 
              value={bio} 
              onChange={(e) => setBio(e.target.value)} 
              placeholder="Cuéntanos un poco sobre ti..." 
              rows={3} 
            />
          </div>

          <div className="space-y-4">
            <h3 className="text-md font-medium">Redes Sociales</h3>
            <div className="space-y-2">
              <Label htmlFor="facebook">Facebook</Label>
              <div className="flex items-center">
                <Facebook className="h-5 w-5 mr-2 text-muted-foreground" />
                <Input 
                  id="facebook" 
                  value={socialLinks?.facebook || ''} 
                  onChange={(e) => handleSocialLinkChange('facebook', e.target.value)} 
                  placeholder="Enlace a tu perfil de Facebook" 
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="instagram">Instagram</Label>
              <div className="flex items-center">
                <Instagram className="h-5 w-5 mr-2 text-muted-foreground" />
                <Input 
                  id="instagram" 
                  value={socialLinks?.instagram || ''} 
                  onChange={(e) => handleSocialLinkChange('instagram', e.target.value)} 
                  placeholder="Enlace a tu perfil de Instagram" 
                />
              </div>
            </div>
             <div className="space-y-2">
              <Label htmlFor="twitter">Twitter / X</Label>
              <div className="flex items-center">
                <Twitter className="h-5 w-5 mr-2 text-muted-foreground" />
                <Input 
                  id="twitter" 
                  value={socialLinks?.twitter || ''} 
                  onChange={(e) => handleSocialLinkChange('twitter', e.target.value)} 
                  placeholder="Enlace a tu perfil de Twitter/X" 
                />
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isLoading} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
            {isLoading ? <Image src="/images/splash.gif" alt="Guardando..." width={24} height={24} unoptimized className="mr-2" /> : <Save className="mr-2 h-4 w-4" />}
            Guardar Cambios
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
