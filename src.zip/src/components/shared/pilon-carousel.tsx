
"use client"

import React, { useState, useEffect } from 'react';
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import type { Product } from "@/types";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel"
import Autoplay from "embla-carousel-autoplay";
import { PackagePlus } from "lucide-react";
import { HighlightK } from "@/components/layout/highlight-k"; 
import { useAssistant } from '@/context/assistant-context';
import { useMonthlyDeals } from '@/hooks/use-monthly-deals';

export function PilonCarousel() {
  const { showAssistantMessage } = useAssistant();
  const [isClient, setIsClient] = useState(false);
  
  // Use the new hook to get the monthly deals
  const pilonProducts = useMonthlyDeals(9);
  
  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleAddToPilon = (product: Product) => {
    // Simulate adding to cart
    showAssistantMessage({
      title: "¡Pilón Añadido!",
      message: `${product.name} ha sido añadido a tu carrito.`,
    });
  };

  const renderMedia = (item: Product) => {
    const url = item.imageUrl;
    const itemIsVideo = item.isVideo;
    const objectFitClass = itemIsVideo ? "object-cover" : "object-contain";

    if (itemIsVideo) {
      return (
        <video
          src={url}
          width={0}
          height={0}
          autoPlay
          loop={true}
          muted
          playsInline
          className={`rounded-md ${objectFitClass} p-0 group-hover:scale-105 transition-transform w-full h-full`}
        />
      );
    }
    return (
      <Image
        src={url}
        alt={item.name}
        fill
        className={`rounded-md ${objectFitClass} group-hover:scale-105 transition-transform`}
        data-ai-hint={item.dataAiHint || "prenda ropa"}
        unoptimized={url.endsWith('.gif')}
      />
    );
  };
  
  if (!isClient || pilonProducts.length === 0) {
    return null;
  }

  return (
    <section className="mt-12 pt-8 border-t">
      <h2 className="text-2xl font-semibold text-center mb-6"><HighlightK text="El Pilón (Ofertas del Mes)" /></h2>
      <Carousel
        opts={{
          align: "start",
          loop: true,
        }}
        plugins={[
          Autoplay({
            delay: 3000,
            stopOnInteraction: true,
          }),
        ]}
        className="w-full"
      >
        <CarouselContent className="-ml-2">
          {[...pilonProducts, ...pilonProducts].map((product, index) => ( // Duplicate for smooth loop
            <CarouselItem key={`${product.id}-${index}`} className="pl-2 basis-[200px]">
              <Card className="overflow-hidden h-full flex flex-col">
                <Link href={`/catalog/${product.id}`} className="block aspect-square relative group bg-transparent">
                   {renderMedia(product)}
                </Link>
                <CardContent className="p-2 flex-grow flex flex-col">
                  <h3 className="text-xs font-medium group-hover:text-accent transition-colors truncate">
                    <Link href={`/catalog/${product.id}`}>{product.name}</Link>
                  </h3>
                  <p className="text-[11px] text-muted-foreground mb-1 truncate h-7 leading-tight">{product.description.substring(0,40)}...</p>
                  <p className="text-sm font-semibold mt-auto">${product.price.toFixed(2)} MXN</p>
                </CardContent>
                <CardFooter className="p-1.5 border-t">
                  <Button size="sm" className="w-full text-xs h-7" onClick={() => handleAddToPilon(product)}>
                    <PackagePlus className="mr-1 h-3.5 w-3.5" /> Agregar
                  </Button>
                </CardFooter>
              </Card>
            </CarouselItem>
          ))}
        </CarouselContent>
      </Carousel>
    </section>
  );
}
