
"use client"

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { FileUploader } from '@/components/ui/file-uploader';
import { Sparkles, Wand2, History, ShoppingCart } from 'lucide-react';
import { virtualTryOn, type VirtualTryOnInput } from '@/ai/flows/virtual-try-on';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import type { Product, CustomizationOptions } from '@/types';
import { useAssistant } from '@/context/assistant-context';
import { cn } from '@/lib/utils';
import Link from 'next/link';

interface VirtualTryOnBoothProps {
  product: Product;
  customizationOptions: CustomizationOptions | null;
}

const RECENT_PHOTO_KEY = 'kalz-try-on-recent-photo';

const fileToDataUri = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

async function dataUriToBlob(dataUri: string): Promise<Blob> {
    const response = await fetch(dataUri);
    return await response.blob();
}


async function pathToDataUri(path: string): Promise<string> {
  const absolutePath = path.startsWith('/') ? `${window.location.origin}${path}` : path;
  try {
    const response = await fetch(absolutePath);
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${path}, status: ${response.status}`);
    }
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error("Error converting path to Data URI:", error);
    throw error;
  }
}

export function VirtualTryOnBooth({ product, customizationOptions }: VirtualTryOnBoothProps) {
  const [customerPhoto, setCustomerPhoto] = useState<File | null>(null);
  const [customerPhotoPreview, setCustomerPhotoPreview] = useState<string | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { showAssistantMessage } = useAssistant();

  const handlePhotoSelected = async (file: File | null) => {
    setCustomerPhoto(file);
    if (file) {
      const dataUri = await fileToDataUri(file);
      setCustomerPhotoPreview(dataUri);
      localStorage.setItem(RECENT_PHOTO_KEY, dataUri);
      setGeneratedImage(null);
    } else {
      setCustomerPhotoPreview(null);
    }
  };

  const loadRecentPhoto = async () => {
    const recentPhotoUri = localStorage.getItem(RECENT_PHOTO_KEY);
    if (recentPhotoUri) {
      setCustomerPhotoPreview(recentPhotoUri);
      const blob = await dataUriToBlob(recentPhotoUri);
      const file = new File([blob], "foto-reciente.png", { type: blob.type });
      setCustomerPhoto(file);
      setGeneratedImage(null);
      toast({ title: "Foto Reciente Cargada", description: "Se ha cargado la última foto que utilizaste." });
    } else {
      toast({ title: "Sin Foto Reciente", description: "No hemos encontrado una foto guardada para el probador.", variant: "default" });
    }
  };

  const handleTryOn = async () => {
    if (!customerPhoto) {
      toast({ title: "Error", description: "Por favor, sube una foto tuya.", variant: "destructive" });
      return;
    }
   
    setIsLoading(true);
    setGeneratedImage(null);

    try {
      const customerPhotoDataUri = await fileToDataUri(customerPhoto);
      
      let clothingImageForAI: string;
      if (product.isVideo && product.staticImageUrlForAI) {
        clothingImageForAI = product.staticImageUrlForAI;
      } else {
        clothingImageForAI = product.imageUrl;
      }

      const clothingDataUri = clothingImageForAI.startsWith('data:') ? clothingImageForAI : await pathToDataUri(clothingImageForAI);

      const customizationString = customizationOptions 
        ? `Texto: ${customizationOptions.text?.content || 'Ninguno'}. Diseño: ${customizationOptions.design?.url ? 'Aplicado' : 'Ninguno'}` 
        : 'Sin personalización adicional.';

      const input: VirtualTryOnInput = {
        clothingDataUri: clothingDataUri,
        customerPhotoDataUri: customerPhotoDataUri,
        customizations: customizationString,
      };
      
      const result = await virtualTryOn(input);

      if (result.editedImage) {
        setGeneratedImage(result.editedImage);
        toast({ title: "¡Éxito!", description: "Tu prueba virtual está lista." });
      } else {
        throw new Error("La IA no devolvió una imagen editada.");
      }

    } catch (error) {
      console.error("Error en el probador virtual:", error);
      toast({
        title: "Error en el Probador Kal-Z",
        description: `Ocurrió un problema: ${error instanceof Error ? error.message : String(error)}.`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleAddToCart = () => {
    showAssistantMessage({
      title: "Producto Añadido (Simulación)",
      message: `${product.name} (con tu prueba virtual) ha sido añadido al carrito.`,
      action: <Button variant="outline" size="sm" asChild><Link href="/cart">Ver Carrito</Link></Button>,
    });
  };

  const displayImage = generatedImage || customerPhotoPreview;

  return (
    <Card className="shadow-none border-none bg-transparent">
      <CardContent className="p-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          
          {/* Left Column: Image Display */}
          <div className="lg:sticky lg:top-24 space-y-4">
            <h3 className="text-lg font-semibold text-center">Vista Previa</h3>
            <div className="relative w-full aspect-[4/5] border-2 border-dashed rounded-lg flex items-center justify-center bg-background/30 overflow-hidden">
                {isLoading ? (
                    <div className="text-center text-muted-foreground p-4">
                        <Image src="/images/splash.gif" alt="Generando..." width={128} height={128} unoptimized />
                        <p className="mt-2 text-sm">Generando magia...</p>
                    </div>
                ) : displayImage ? (
                    <Image src={displayImage} alt="Vista previa del probador virtual" fill className="object-contain p-2" data-ai-hint="prueba virtual resultado"/>
                ) : (
                    <div className="text-center text-muted-foreground p-4">
                        <Wand2 className="h-10 w-10 mx-auto" />
                        <p className="mt-2 text-sm font-semibold text-foreground">Tu resultado aparecerá aquí</p>
                        <p className="text-xs">Sube tu foto y presiona "Probar Prenda".</p>
                    </div>
                )}
            </div>
          </div>

          {/* Right Column: Controls */}
          <div className="space-y-6">
            <CardTitle>Instrucciones del Probador</CardTitle>
            <ol className="list-decimal list-inside text-muted-foreground space-y-2 text-sm">
                <li>Sube una foto tuya de cuerpo completo, sin nadie más alrededor.</li>
                <li>Para mejores resultados, usa una foto con un fondo blanco o de color sólido.</li>
                <li>Presiona el botón "Probar Prenda con IA" y espera el resultado.</li>
            </ol>
            
            <div className="space-y-3">
              <FileUploader onFileSelect={handlePhotoSelected} accept="image/jpeg, image/png" label="Sube tu foto" />
              <Button variant="outline" size="sm" className="w-full" onClick={loadRecentPhoto}>
                  <History className="mr-2 h-4 w-4"/> Usar Foto Reciente
              </Button>
            </div>
            
            <div className="flex flex-col gap-3">
                <Button 
                    onClick={handleTryOn} 
                    disabled={isLoading || !customerPhoto} 
                    className="w-full text-lg h-12"
                >
                    {isLoading ? (
                        <Image src="/images/splash.gif" alt="Generando..." width={24} height={24} unoptimized className="mr-2" />
                    ) : (
                        <Sparkles className="mr-2 h-5 w-5" />
                    )}
                    {isLoading ? 'Generando...' : 'Probar Prenda con IA'}
                </Button>

                <Button 
                    onClick={handleAddToCart}
                    variant="secondary"
                    disabled={!generatedImage}
                    className="w-full text-lg h-12"
                >
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Agregar al Carrito
                </Button>
            </div>
          </div>

        </div>
      </CardContent>
    </Card>
  );
}
