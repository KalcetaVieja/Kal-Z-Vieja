
"use client"

import React, { useState, ChangeEvent, DragEvent } from 'react';
import { UploadCloud, File as FileIcon, X } from 'lucide-react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface FileUploaderProps {
  onFileSelect: (file: File | null) => void;
  accept?: string; 
  label?: string;
  id?: string;
  className?: string;
}

export function FileUploader({ 
  onFileSelect, 
  accept = "image/*", 
  label = "Arrastra y suelta o haz clic para subir",
  id = "file-upload",
  className 
}: FileUploaderProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;
    updateFile(file);
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
    const file = event.dataTransfer.files?.[0] || null;
    updateFile(file);
  };

  const updateFile = (file: File | null) => {
    setSelectedFile(file);
    onFileSelect(file);
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setPreviewUrl(null);
    }
  }

  const handleDragOver = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(true);
  };
  
  const handleDragLeave = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
  };

  const removeFile = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    onFileSelect(null);
    const fileInput = document.getElementById(id) as HTMLInputElement;
    if (fileInput) fileInput.value = '';
  };

  return (
    <div className={cn("w-full", className)}>
      <label
        htmlFor={id}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={cn(
          "flex items-center w-full h-12 border-2 border-dashed rounded-lg cursor-pointer", // Reduced height
          "bg-muted hover:bg-muted/80 transition-colors px-3", // Added padding
          isDragging ? "border-accent" : "border-border",
          selectedFile && previewUrl ? "p-1 justify-between" : "p-3 justify-center" // Adjusted padding for preview
        )}
      >
        {selectedFile ? (
          <>
            <div className="flex items-center gap-2 overflow-hidden">
              {previewUrl ? (
                <Image src={previewUrl} alt="Vista previa" width={32} height={32} className="object-contain rounded-sm" />
              ) : (
                <FileIcon className="w-6 h-6 flex-shrink-0 text-muted-foreground" />
              )}
              <div className="flex flex-col text-left overflow-hidden">
                <p className="text-sm text-foreground truncate">{selectedFile.name}</p>
                <p className="text-xs text-muted-foreground">{(selectedFile.size / 1024).toFixed(2)} KB</p>
              </div>
            </div>
            <Button
              variant="destructive"
              size="icon"
              className="flex-shrink-0 h-7 w-7 ml-2"
              onClick={(e) => { e.preventDefault(); removeFile(); }}
              aria-label="Quitar archivo"
            >
              <X className="h-4 w-4" />
            </Button>
          </>
        ) : (
          <div className="flex items-center justify-center text-center w-full">
            <UploadCloud className="w-5 h-5 mr-2 text-muted-foreground" />
            <p className="text-sm text-foreground">
              <span className="font-semibold">Sube tu imagen</span>
            </p>
          </div>
        )}
        <input id={id} type="file" className="hidden" onChange={handleFileChange} accept={accept} />
      </label>
    </div>
  );
}
