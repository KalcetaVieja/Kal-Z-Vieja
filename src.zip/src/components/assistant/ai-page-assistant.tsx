
"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useLanguage } from "@/context/language-context";
import { HelpCircle, LayoutGrid, Brush, ShoppingCart, Mail, X, Smartphone, Home, Shirt, Dog, Crown, Gift, ArrowRight, Wand2, Info } from "lucide-react";
import { HighlightK } from "@/components/layout/highlight-k";
import { usePathname } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAssistant } from "@/context/assistant-context";
import { cn } from "@/lib/utils";
import { useTheme } from "next-themes";

const assistantTranslations = {
  es: {
    assistantTitle: "Hey, ¿qué te gustaría hacer, Kalceto?",
    closeAssistant: "Cerrar Asistente",
    assistantAriaLabel: "Abrir asistente de ayuda Kal-Z-Vieja",
    orientationTitle: "Recomendación de Visualización",
    orientationDesc: "Para una mejor experiencia con los módulos de IA y contenedores extendidos, te recomendamos usar la web en modo horizontal.",
    gotIt: "¡Entendido!",
    goToKatalog: "Ir al KATÁLOGO",
    goToKalZStudio: "Diseñar con KAL-Z-STUDIO",
    goToCart: "Ver mi Carrito",
    goToContact: "Contacto y Ayuda",
    howToCustomize: "¿Cómo personalizo?",
    viewNineties: "Ver Colección Los 90s",
    exploreViral: "Explorar Diseños Virales",
    howTryOnWorks: "¿Cómo funciona el Probador?",
    viewShippingPolicies: "Ver Políticas de Envío",
    addToFavorites: "Añadir a Favoritos",
    needInspiration: "Necesito Inspiración",
    saveMyDesign: "Guardar mi Diseño",
    goToViralGallery: "Ir a la Galería Viral",
    howToPublish: "¿Cómo publico mi diseño?",
    viewMyRewards: "Ver mis Rekompensas",
    howToEarnPoints: "¿Cómo gano más puntos?",
    viewDailyMissions: "Ver Misiones Diarias",
  },
  en: {
    assistantTitle: "Hey, what would you like to do, Kalceto?",
    closeAssistant: "Close Assistant",
    assistantAriaLabel: "Open Kal-Z-Vieja help assistant",
    orientationTitle: "Display Recommendation",
    orientationDesc: "For a better experience with the AI modules and extended containers, we recommend using the web app in horizontal mode.",
    gotIt: "Got It!",
    goToKatalog: "Go to KATALOG",
    goToKalZStudio: "Design with KAL-Z-STUDIO",
    goToCart: "View my Cart",
    goToContact: "Contact & Help",
    howToCustomize: "How do I customize?",
    viewNineties: "View The 90s Collection",
    exploreViral: "Explore Viral Designs",
    howTryOnWorks: "How does the Try-On work?",
    viewShippingPolicies: "View Shipping Policies",
    addToFavorites: "Add to Favorites",
    needInspiration: "I need inspiration",
    saveMyDesign: "Save my Design",
    goToViralGallery: "Go to the Viral Gallery",
    howToPublish: "How do I publish my design?",
    viewMyRewards: "View my Rewards",
    howToEarnPoints: "How do I earn more points?",
    viewDailyMissions: "View Daily Missions",
  },
};

interface AssistantOption {
  key: keyof typeof assistantTranslations.es;
  href?: string;
  action?: () => void;
  icon: React.ElementType;
}

const defaultOptions: AssistantOption[] = [
  { key: "goToKatalog", href: "/catalog", icon: LayoutGrid },
  { key: "goToKalZStudio", href: "/kal-z-ai", icon: Brush },
  { key: "goToCart", href: "/cart", icon: ShoppingCart },
];

export function AiPageAssistant() {
  const { locale, isLoadingPage } = useLanguage();
  const { assistantMessage, clearAssistantMessage } = useAssistant();
  const pathname = usePathname();
  const { toast } = useToast();
  const { theme } = useTheme();
  const [assistantSrc, setAssistantSrc] = React.useState("/images/Logos/Viejita/Viejita.png");
  const [isOpen, setIsOpen] = React.useState(false);
  const [isClient, setIsClient] = React.useState(false);
  const isMobile = useIsMobile();
  const [showOrientationPopover, setShowOrientationPopover] = React.useState(false);
  const popoverTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);

  React.useEffect(() => {
    const getAssistantImage = () => {
      switch (theme) {
        case 'tornasol':
          return '/images/Logos/Viejita/Viejita 8bit.png';
        case 'vieja':
          return '/images/Logos/Viejita/Viejita gris.png';
        case 'green':
          return '/images/Logos/Viejita/Viejita.png';
        default:
          return '/images/Logos/Viejita/Viejita.png';
      }
    };
    setAssistantSrc(getAssistantImage());
  }, [theme]);

  React.useEffect(() => {
    setIsClient(true);
    if (isMobile) {
      const hasSeenRecommendation = localStorage.getItem('hasSeenOrientationRecommendation');
      if (!hasSeenRecommendation) {
        setIsOpen(true);
        setShowOrientationPopover(true);
        localStorage.setItem('hasSeenOrientationRecommendation', 'true');
      }
    }
  }, [isMobile]);

  React.useEffect(() => {
    if (assistantMessage) {
        setShowOrientationPopover(false);
        setIsOpen(true);
        if (popoverTimeoutRef.current) {
            clearTimeout(popoverTimeoutRef.current);
        }
        popoverTimeoutRef.current = setTimeout(() => {
            setIsOpen(false);
            clearAssistantMessage();
        }, 5000);
    }
  }, [assistantMessage, clearAssistantMessage]);

  const handleClose = () => {
    if (popoverTimeoutRef.current) {
        clearTimeout(popoverTimeoutRef.current);
    }
    setIsOpen(false);
    clearAssistantMessage();
    setShowOrientationPopover(false);
  };

  const t = (key: keyof (typeof assistantTranslations.es)) => {
    let text = assistantTranslations[locale][key] || assistantTranslations["es"][key] || String(key);
    const isTitleLike = key.toLowerCase().includes('title') || key.toLowerCase().includes('nav') || key.startsWith('goTo');
    if (isTitleLike) {
        text = text.replace(/k/g, "K");
    }
    return text;
  }

  const getContextualOptions = (): AssistantOption[] => {
    if (pathname.startsWith('/catalog/')) {
      return [
        { key: "howTryOnWorks", href: "/virtual-try-on", icon: Wand2 },
        { key: "viewShippingPolicies", href: "/terms", icon: Mail },
        { key: "addToFavorites", action: () => toast({ title: "Próximamente", description: "Pronto podrás guardar tus productos favoritos." }), icon: Gift },
      ];
    }
    if (pathname.startsWith('/catalog')) {
      return [
        { key: "howToCustomize", href: "/kal-z-ai", icon: HelpCircle },
        { key: "viewNineties", href: "/los-90s", icon: Dog },
        { key: "exploreViral", href: "/viral", icon: Crown },
      ];
    }
    if (pathname.startsWith('/kal-z-ai') || pathname.startsWith('/virtual-try-on')) {
      return [
        { key: "howTryOnWorks", href: "/virtual-try-on", icon: Wand2 },
        { key: "needInspiration", action: () => toast({ title: "Inspiración", description: "Usa el Generador de IA para obtener ideas creativas." }), icon: HelpCircle },
        { key: "saveMyDesign", action: () => toast({ title: "Próximamente", description: "Pronto podrás guardar tus diseños en tu perfil." }), icon: Gift },
      ];
    }
    if (pathname.startsWith('/viral')) {
      return [
          { key: "howToPublish", href: "/kal-z-ai", icon: HelpCircle },
          { key: "viewMyRewards", href: "/recompensas", icon: Gift },
          { key: "goToKatalog", href: "/catalog", icon: LayoutGrid },
      ];
    }
    if (pathname.startsWith('/recompensas')) {
      return [
          { key: "howToEarnPoints", action: () => toast({title: "Gana Puntos", description: "Completa misiones diarias y semanales para acumular Kalcepoints."}), icon: HelpCircle },
          { key: "goToKatalog", href: "/catalog", icon: LayoutGrid },
          { key: "goToKalZStudio", href: "/kal-z-ai", icon: Brush },
      ];
    }
    return defaultOptions;
  };

  if (!isClient) {
    return null;
  }
  
  const currentOptions = getContextualOptions().slice(0, 3);
  const currentMessage = assistantMessage;

  return (
    <div className="relative assistant-container">
      {/* Normal State */}
      <div
        className={cn(
          'absolute inset-0',
          isLoadingPage && 'animate-whirlwind-out'
        )}
      >
        <Popover open={isOpen && !isLoadingPage} onOpenChange={setIsOpen}>
          <PopoverTrigger asChild>
            <button
              aria-label={t("assistantAriaLabel")}
              className="w-full h-full"
              disabled={isLoadingPage}
            >
              <div className="absolute -top-5 left-1/2 -translate-x-1/2 whitespace-nowrap assistant-help-text">
                ¿Necesitas Ayuda?
              </div>
              <Image
                src={assistantSrc}
                alt="Asistente Kal-Z Vieja"
                width={160}
                height={160}
                className="relative"
                data-ai-hint="asistente ayuda"
                unoptimized
              />
            </button>
          </PopoverTrigger>
          <PopoverContent
            side="top"
            align="end"
            className="w-64 rounded-xl shadow-2xl border-border bg-card p-0"
            onOpenAutoFocus={(e) => e.preventDefault()} 
          >
            <div className="p-4 space-y-3">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-md font-semibold flex items-center text-card-foreground">
                  <HighlightK text={currentMessage?.title || t(showOrientationPopover ? "orientationTitle" : "assistantTitle")} />
                </h3>
                <Button variant="ghost" size="icon" onClick={handleClose} className="h-7 w-7 text-muted-foreground hover:text-destructive">
                  <X className="h-4 w-4" />
                  <span className="sr-only"><HighlightK text={t("closeAssistant")} /></span>
                </Button>
              </div>
              {currentMessage ? (
                <div className="space-y-4 text-center">
                    <Info className="h-10 w-10 text-accent mx-auto" />
                    <p className="text-sm text-muted-foreground"><HighlightK text={currentMessage.message} /></p>
                    {currentMessage.action}
                </div>
              ) : showOrientationPopover ? (
                <div className="space-y-4 text-center">
                    <Smartphone className="h-10 w-10 text-accent mx-auto" />
                    <p className="text-sm text-muted-foreground"><HighlightK text={t("orientationDesc")} /></p>
                    <Button onClick={handleClose} className="w-full"><HighlightK text={t("gotIt")} /></Button>
                </div>
              ) : (
                <ul className="space-y-2">
                  {currentOptions.map((option) => {
                    const Icon = option.icon;
                    const content = (
                      <span className="flex items-center gap-2.5">
                        <Icon className="h-4 w-4 text-primary/80" />
                        <HighlightK text={t(option.key)} />
                      </span>
                    );

                    return (
                      <li key={option.key}>
                        <Button
                          variant="ghost"
                          className="w-full justify-start px-3 py-2 text-sm h-auto text-card-foreground hover:bg-accent/50 hover:text-accent-foreground"
                          onClick={() => {
                            if (option.action) option.action();
                            setIsOpen(false);
                          }}
                          asChild={!!option.href}
                        >
                          {option.href ? <Link href={option.href}>{content}</Link> : content}
                        </Button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  );
}
