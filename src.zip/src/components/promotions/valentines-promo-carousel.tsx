
"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
  type CarouselApi,
} from "@/components/ui/carousel";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart } from "lucide-react";
import { cn } from "@/lib/utils";

const promotions = [
  {
    title: "Dúo de Tazas",
    description: "Dos tazas personalizables para compartir un café... o lo que surja. ¡Añade tu diseño!",
    originalPrice: 174.00,
    discountedPrice: 156.60,
    discount: "10%",
    imageUrl: "https://picsum.photos/seed/promo-tazas/800/600",
    dataAiHint: "tazas amor",
    href: "/catalog/kzv-tazab-1",
  },
  {
    title: "Combo Pareja",
    description: "Una camiseta y una taza para que hagan juego. ¡El doble de estilo, el doble de amor!",
    originalPrice: 549.84,
    discountedPrice: 494.86,
    discount: "10%",
    imageUrl: "https://picsum.photos/seed/promo-combo/800/600",
    dataAiHint: "pareja ropa",
    href: "/catalog/kzv-mc-1",
  },
  {
    title: "Dúo de Sudaderas",
    description: "Dos sudaderas con gorro para estar cómodos y abrigados. ¡Perfectas para maratonear series juntos!",
    originalPrice: 1276.00,
    discountedPrice: 1084.60,
    discount: "15%",
    imageUrl: "https://picsum.photos/seed/promo-sudaderas/800/600",
    dataAiHint: "pareja abrazados",
    href: "/catalog/kzv-scg-2",
  },
];

export function ValentinesPromoCarousel() {
  const [api, setApi] = React.useState<CarouselApi>();
  const [current, setCurrent] = React.useState(0);

  React.useEffect(() => {
    if (!api) {
      return;
    }

    setCurrent(api.selectedScrollSnap());

    const onSelect = () => {
      setCurrent(api.selectedScrollSnap());
    };

    api.on("select", onSelect);

    return () => {
      api.off("select", onSelect);
    };
  }, [api]);

  return (
    <section className="container mx-auto px-4 my-16">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold flex items-center justify-center gap-2">
            <Heart className="text-primary h-7 w-7" />
            Especial de San Valentín
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
            Encuentra el regalo perfecto para este 14 de Febrero.
        </p>
      </div>
      <Carousel setApi={setApi} className="w-full">
        <CarouselContent>
          {promotions.map((promo, index) => (
            <CarouselItem key={index}>
              <Card className="bg-primary/5 border-primary/20 shadow-lg overflow-hidden">
                <CardContent className="grid md:grid-cols-2 items-center p-0">
                  <div className="relative aspect-[4/3] w-full h-full">
                    <Image
                      src={promo.imageUrl}
                      alt={promo.title}
                      fill
                      className="object-cover"
                      data-ai-hint={promo.dataAiHint}
                    />
                  </div>
                  <div className="p-6 sm:p-8 md:p-10 space-y-4">
                    <Badge variant="secondary">San Valentín</Badge>
                    <h3 className="text-2xl font-bold">{promo.title}</h3>
                    <p className="text-muted-foreground">{promo.description}</p>
                    <div className="flex items-baseline gap-3">
                      <p className="text-3xl font-bold text-primary">
                        ${promo.discountedPrice.toFixed(2)}
                      </p>
                      <p className="text-lg line-through text-muted-foreground">
                        ${promo.originalPrice.toFixed(2)}
                      </p>
                       <Badge variant="secondary">{promo.discount} OFF</Badge>
                    </div>
                    <Button asChild size="lg">
                      <Link href={promo.href}>Ver Oferta</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 z-10 hidden sm:flex" />
        <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 z-10 hidden sm:flex" />
      </Carousel>
      <div className="py-4 flex justify-center gap-2">
        {promotions.map((_, index) => (
          <button
            key={index}
            onClick={() => api?.scrollTo(index)}
            className={cn(
              "h-2 w-2 rounded-full transition-all",
              current === index ? "w-4 bg-primary" : "bg-primary/30"
            )}
            aria-label={`Ir a la promoción ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
}
