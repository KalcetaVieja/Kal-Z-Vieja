
"use client";

import React, { useRef } from 'react';
import { ViralPostCard } from './viral-post-card';
import type { ViralPost } from '@/types';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface ViralCarouselProps {
  posts: ViralPost[];
}

export function ViralCarousel({ posts }: ViralCarouselProps) {
  const sliderRef = useRef<HTMLDivElement>(null);

  const scrollSlider = (direction: number) => {
    if (sliderRef.current) {
      const scrollAmount = 320; // Corresponds to card width (300) + gap (16)
      sliderRef.current.scrollBy({ left: direction * scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative w-full">
      <Button
        variant="outline"
        size="icon"
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-background/50 hover:bg-accent text-foreground hover:text-accent-foreground hidden sm:flex"
        onClick={() => scrollSlider(-1)}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <div
        ref={sliderRef}
        className="flex gap-4 overflow-x-auto p-4 hide-scrollbar"
      >
        {posts.map((post) => (
          <div key={post.id} className="flex-shrink-0 w-[320px] sm:w-[340px]">
            <ViralPostCard post={post} />
          </div>
        ))}
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-background/50 hover:bg-accent text-foreground hover:text-accent-foreground hidden sm:flex"
        onClick={() => scrollSlider(1)}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>
    </div>
  );
}
