
"use client";

import React, { useState, useEffect } from 'react';
import { MessageSquare, Star, ShoppingCart } from "lucide-react";
import { mockProducts } from "@/data/mock";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import type { ViralPost } from "@/types";
import { Skeleton } from "@/components/ui/skeleton";

export function ViralPostCard({ post }: { post: ViralPost }) {
  const associatedDesign = post.design;
  const product = mockProducts.find(p => p.id === associatedDesign?.baseProductId);
  const [formattedDate, setFormattedDate] = useState<string | null>(null);

  useEffect(() => {
    // Format the date only on the client side to prevent hydration mismatch
    setFormattedDate(new Date(post.sharedAt).toLocaleDateString('es-MX'));
  }, [post.sharedAt]);

  return (
    <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col h-full hover:scale-105">
      <CardHeader className="p-0">
        {associatedDesign && (
          <Link href={`/catalog/${product?.id}?viral_design_id=${post.id}`} className="block aspect-square relative bg-transparent">
            <Image
              src={associatedDesign.imageDataUri}
              alt={associatedDesign.name || "Diseño de la comunidad"}
              fill
              className="object-contain p-2"
              data-ai-hint={associatedDesign.dataAiHint || "ropa comunidad"}
            />
          </Link>
        )}
      </CardHeader>
      <CardContent className="p-4 flex-grow">
        <CardTitle className="text-lg mb-1">
          <Link href={`/catalog/${product?.id}?viral_design_id=${post.id}`} className="hover:text-accent transition-colors">
            {associatedDesign?.name || "Diseño Impactante"}
          </Link>
        </CardTitle>
        <p className="text-xs text-muted-foreground">Compartido por: {post.userName || post.userId.substring(0,8)}...</p>
        <span className="text-xs text-muted-foreground block">
          Fecha: {formattedDate ? formattedDate : <Skeleton className="h-4 w-20 inline-block" />}
        </span>
        <div className="flex items-center gap-2 mt-2">
          <Star className="h-4 w-4 text-yellow-400" />
          <span className="text-sm">{post.averageRating?.toFixed(1) || "N/A"} ({post.ratings.length} valoraciones)</span>
        </div>
        <div className="flex items-center gap-1 mt-1 text-muted-foreground">
          <MessageSquare className="h-4 w-4" /> 
          <span className="text-sm">{post.comments.length} comentarios</span>
        </div>
      </CardContent>
      <CardFooter className="p-3 border-t flex flex-col items-stretch gap-2">
         {post.purchasePrice && product && (
           <>
            <div className="text-center">
                <p className="text-xs text-muted-foreground">Base: {product.name}</p>
                <p className="text-lg font-semibold text-accent">${post.purchasePrice.toFixed(2)} MXN <Badge variant="destructive">10% OFF</Badge></p>
                <p className="text-xs text-muted-foreground line-through">${(product.price).toFixed(2)} MXN</p>
            </div>
            <Button asChild variant="default" size="sm" className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                <Link href={`/catalog/${product?.id}?viral_design_id=${post.id}`}>
                    <ShoppingCart className="mr-1.5 h-4 w-4" /> Comprar Diseño
                </Link>
            </Button>
           </>
        )}
        <Button variant="outline" size="sm" className="w-full">Ver Comentarios</Button>
      </CardFooter>
    </Card>
  );
}
