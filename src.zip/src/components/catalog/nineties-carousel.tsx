
"use client";

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { mockProducts } from '@/data/mock';
import Link from 'next/link';
import { CassetteTape } from 'lucide-react';

const ninetiesProducts = []; // Empty for now as per user request

export function NinetiesCarousel() {
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        if (ninetiesProducts.length > 1) {
            const slideInterval = setInterval(() => {
                moveSlide(1);
            }, 4000); // Change slide every 4 seconds
            return () => clearInterval(slideInterval); // Cleanup on component unmount
        }
    }, []);

    const moveSlide = (direction: number) => {
        setCurrentIndex(prevIndex => (prevIndex + direction + ninetiesProducts.length) % ninetiesProducts.length);
    };

    if (ninetiesProducts.length === 0) {
        return (
            <div className="text-center text-[#e0faff] py-10 my-8 space-y-4">
                <CassetteTape className="h-16 w-16 mx-auto" />
                <p>Esta colección no está disponible por el momento.</p>
                <p className="text-xs">Vuelve a sintonizar pronto.</p>
            </div>
        );
    }

    const getClassName = (index: number) => {
        const totalItems = ninetiesProducts.length;
        if (totalItems <= 1) return 'active'; // Always active if only one item

        if (index === currentIndex) return 'active';
        
        const nextIndex = (currentIndex + 1) % totalItems;
        if (index === nextIndex) return 'next';

        const prevIndex = (currentIndex - 1 + totalItems) % totalItems;
        if (index === prevIndex) return 'prev';
        
        return 'hidden'; // Hide cards that are not active, next, or prev
    };

    return (
        <div className="carousel-container my-8">
            <button className="nineties-nav left" onClick={() => moveSlide(-1)}>&#10094;</button>

            <div className="nineties-carousel">
                {ninetiesProducts.map((product, index) => (
                    <div key={product.id} className={`nineties-carousel-item ${getClassName(index)}`}>
                        <Link href={`/catalog/${product.id}`} className="block w-full h-full">
                            <Image
                                src={product.imageUrl}
                                alt={product.name}
                                width={300}
                                height={450}
                                className="object-cover"
                                data-ai-hint={product.dataAiHint}
                                unoptimized={product.imageUrl.endsWith('.gif')}
                            />
                            <p>{product.name}</p>
                        </Link>
                    </div>
                ))}
            </div>
            
            <button className="nineties-nav right" onClick={() => moveSlide(1)}>&#10095;</button>
        </div>
    );
}
