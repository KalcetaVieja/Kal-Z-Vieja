
"use client";

import React from 'react';
import Image from "next/image";
import Link from "next/link";
import type { Product } from "@/types";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Ruler, Palette } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { cn } from '@/lib/utils';


interface ProductCardProps {
  product: Product;
  href?: string; // Optional href to make the whole card a link
}

interface QuickViewContentProps {
  product: Product;
  productLink: string;
}

// This is the content for the quick view dialog, defined outside to prevent re-renders
const QuickViewContent = ({ product, productLink }: QuickViewContentProps) => (
  <>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-transparent">
        {product.isVideo ? (
           <video
            src={product.imageUrl}
            autoPlay
            loop={true}
            muted
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            className="object-contain"
            data-ai-hint={product.dataAiHint}
            unoptimized={product.imageUrl.endsWith('.gif')}
          />
        )}
      </div>
      <div className="space-y-4">
        <DialogHeader className="p-0 text-left">
          <DialogTitle className="text-2xl">{product.name}</DialogTitle>
          <DialogDescription>{product.description}</DialogDescription>
        </DialogHeader>
        
        <Separator />

        {(product.availableColors && product.availableColors.length > 0 && product.availableColors[0] !== 'N/A') && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-2"><Palette className="h-4 w-4" /> Colores Disponibles</h4>
            <div className="flex flex-wrap gap-2">
              {product.availableColors.map(color => (
                  <div key={color} className="flex items-center gap-2 p-2 border rounded-md bg-background">
                      <span className="h-4 w-4 rounded-full border" style={{ backgroundColor: color.toLowerCase() === 'negro' ? 'black' : color.toLowerCase() === 'blanco' ? 'white' : color.toLowerCase() === 'rosa' ? '#F472B6' : color.toLowerCase() === 'acid wash' ? '#6B7280' : color.toLowerCase() === 'verde' ? '#10B981' : 'transparent' }}></span>
                      <span className="text-xs">{color}</span>
                  </div>
              ))}
            </div>
          </div>
        )}
        
        {(product.availableSizes && product.availableSizes.length > 0 && product.availableSizes[0] !== 'N/A') && (
          <div className="space-y-2">
             <h4 className="text-sm font-semibold flex items-center gap-2"><Ruler className="h-4 w-4" /> Tallas Disponibles</h4>
            <div className="flex flex-wrap gap-2">
              {product.availableSizes.map(size => (
                <Badge key={size} variant="secondary">{size}</Badge>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
    <div className="mt-6 text-center">
       <Button asChild size="lg">
          <Link href={productLink}>
             <Eye className="mr-2 h-4 w-4" /> Ver Detalles Completos
          </Link>
       </Button>
    </div>
  </>
);


export function ProductCard({ product, href }: ProductCardProps) {
  const productLink = href || `/catalog/${product.id}`;
  
  return (
    <Dialog>
      <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col h-full group bg-transparent backdrop-blur-none border-none">
        <CardHeader className="p-0">
          <DialogTrigger asChild>
            <button className="block aspect-[3/4] relative bg-transparent focus:outline-none group">
              {product.isVideo ? (
                  <video
                  src={product.imageUrl}
                  autoPlay
                  loop={true}
                  muted
                  playsInline
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
              ) : (
                  <Image
                  src={product.imageUrl}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                  data-ai-hint={product.dataAiHint}
                  unoptimized={product.imageUrl.endsWith('.gif')}
                  />
              )}
               <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Eye className="h-10 w-10 text-white drop-shadow-lg"/>
              </div>
            </button>
          </DialogTrigger>
        </CardHeader>
        <CardContent className="p-2 sm:p-3 flex-grow">
          <CardTitle className="text-base sm:text-lg mb-0.5">
            <Link href={productLink} className="hover:text-accent transition-colors">
              {product.name}
            </Link>
          </CardTitle>
          <p className="text-sm text-muted-foreground mb-1 sm:mb-1.5 h-8 sm:h-9 overflow-hidden line-clamp-2">{product.description}</p>
          <p className="text-base sm:text-lg font-semibold text-foreground">${product.price.toFixed(2)} MXN</p>
        </CardContent>
        <CardFooter className="p-2 sm:p-3 border-t">
          <Button asChild size="sm" variant="outline" className="w-full text-xs sm:text-sm h-8 sm:h-9 px-2 sm:px-3 shadow-[0_0_8px_hsl(var(--accent))] hover:shadow-[0_0_15px_hsl(var(--accent))] transition-shadow">
            <Link href={productLink}>
              <span className="flex items-center justify-center w-full h-full">
                <Eye className="mr-1 h-3 w-3 sm:mr-1.5 sm:h-3.5 sm:w-3.5" /> Ver Producto
              </span>
            </Link>
          </Button>
        </CardFooter>
      </Card>

      <DialogContent className="max-w-3xl bg-card/95 backdrop-blur-lg">
         <QuickViewContent product={product} productLink={productLink} />
      </DialogContent>
    </Dialog>
  )
}
