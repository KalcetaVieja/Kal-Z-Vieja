
"use client";

import React, { useRef } from 'react';
import { ProductCard } from "./product-card";
import type { Product } from "@/types";
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProductCarouselProps {
  products: Product[];
  size?: 'default' | 'small';
}

export function ProductCarousel({ products, size = 'default' }: ProductCarouselProps) {
  const sliderRef = useRef<HTMLDivElement>(null);

  const cardWidthClass = size === 'small' ? 'w-full max-w-[200px]' : 'w-full max-w-[300px] sm:max-w-[340px]';

  const scrollSlider = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const scrollAmount = sliderRef.current.clientWidth * 0.8; // Scroll 80% of the visible width
      sliderRef.current.scrollBy({ 
        left: direction === 'left' ? -scrollAmount : scrollAmount, 
        behavior: 'smooth' 
      });
    }
  };

  if (!products || products.length === 0) {
    return null;
  }

  return (
    <div className="relative w-full">
      <Button
        variant="outline"
        size="icon"
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-background/50 hover:bg-accent text-foreground hover:text-accent-foreground hidden sm:flex"
        onClick={() => scrollSlider('left')}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <div
        ref={sliderRef}
        className="flex gap-4 overflow-x-auto p-4 hide-scrollbar"
      >
        {products.map((product) => (
          <div key={product.id} className={cn("flex-shrink-0", cardWidthClass)}>
            <ProductCard product={product} />
          </div>
        ))}
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-background/50 hover:bg-accent text-foreground hover:text-accent-foreground hidden sm:flex"
        onClick={() => scrollSlider('right')}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>
    </div>
  );
}
