"use client";

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import Autoplay from "embla-carousel-autoplay";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Eye } from 'lucide-react';
import type { Product } from '@/types';
import { cn } from '@/lib/utils';
import { Badge } from '../ui/badge';
import { HighlightK } from '../layout/highlight-k';

interface FeaturedProductCarouselProps {
    products: Product[];
    title: string;
}

export function FeaturedProductCarousel({ products, title }: FeaturedProductCarouselProps) {
    const plugin = React.useRef(
        Autoplay({ delay: 4000, stopOnInteraction: true })
    );

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4"><HighlightK text={title} /></h2>
            <Carousel
                plugins={[plugin.current]}
                className="w-full"
                onMouseEnter={plugin.current.stop}
                onMouseLeave={plugin.current.reset}
                opts={{
                    loop: true,
                }}
            >
                <CarouselContent className="-ml-4">
                    {products.map((product) => (
                        <CarouselItem key={product.id} className="pl-4 basis-1/2 sm:basis-1/3 md:basis-1/4 lg:basis-1/5">
                            <div className="p-1">
                                <Card className="overflow-hidden bg-card/50 backdrop-blur-sm border-border/50 shadow-lg transition-all duration-300 hover:shadow-xl hover:border-primary">
                                    <CardHeader className="p-0 relative h-[400px]">
                                        <Image
                                            src={product.imageUrl}
                                            alt={product.name}
                                            fill
                                            className="object-cover transition-transform duration-500 group-hover:scale-105"
                                            data-ai-hint={product.dataAiHint}
                                            unoptimized={product.imageUrl.endsWith('.gif')}
                                        />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                                        <div className="absolute bottom-0 left-0 p-4">
                                            <Badge variant="secondary" className="mb-2 text-xs">
                                                <HighlightK text={product.category} />
                                            </Badge>
                                            <h3 className="text-xl font-bold text-white drop-shadow-md">
                                                <HighlightK text={product.name} />
                                            </h3>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="p-4">
                                        <p className="text-sm text-muted-foreground h-10 line-clamp-2">
                                            {product.description}
                                        </p>
                                    </CardContent>
                                    <CardFooter className="flex justify-between items-center p-4 pt-0">
                                        <p className="text-xl font-semibold text-accent">${product.price.toFixed(2)}</p>
                                        <Button asChild size="sm">
                                            <Link href={`/catalog/${product.id}`}>
                                                <Eye className="mr-2 h-4 w-4" /> Ver Producto
                                            </Link>
                                        </Button>
                                    </CardFooter>
                                </Card>
                            </div>
                        </CarouselItem>
                    ))}
                </CarouselContent>
                <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 z-10" />
                <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 z-10" />
            </Carousel>
        </div>
    );
}
