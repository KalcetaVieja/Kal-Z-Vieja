
"use client";

import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ShoppingCart, CreditCard, Wand2, Palette, Text, Star, Image as ImageIcon, MessageCircle, Pencil, Brush, Camera, Zap, Feather, BrainCircuit, Sparkles, Loader2, Save, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from '@/components/ui/scroll-area';
import Image from 'next/image';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { FileUploader } from '@/components/ui/file-uploader';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from 'next/link';
import { ImageViewer2D } from './image-viewer-2d';
import type { CustomizationOptions, KalZaiDesign } from '@/types';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { designSuggestions, type DesignSuggestionsInput } from '@/ai/flows/design-suggestions';
import { removeBackground, type RemoveBackgroundInput } from '@/ai/flows/remove-background';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { useMyLooks } from '@/context/my-looks-context';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../ui/alert-dialog';
import { toPng } from 'html-to-image';
import { Separator } from '../ui/separator';


export interface ShirtColor {
  name: string;
  hex: string;
  imageUrl: string;
  dataAiHint?: string;
}

interface PreMadeDesign {
  id: string;
  name: string;
  imageUrl: string;
  dataAiHint: string;
}

interface AiGeneratedImageState {
  id: string;
  originalUri: string;
  noBgUri: string | null;
  isProcessingBg: boolean;
  showNoBg: boolean;
}

const preMadeDesigns: PreMadeDesign[] = [
  { id: 'design-kalz-logo', name: 'Logo Kal-Z', imageUrl: '/images/designs/diseñocamisetakalzlogo.png', dataAiHint: 'logo kalz' },
  { id: 'design-chanfle', name: 'Enjoy the Chanfle', imageUrl: '/images/designs/enjoythechanfle.png', dataAiHint: 'diseño chanfle' },
  { id: 'design-metafisica', name: 'Metafísica Kalz', imageUrl: '/images/designs/metafiscakalz.png', dataAiHint: 'diseño metafisica' },
  { id: 'design-pinfroieud', name: 'Pin-Froieud', imageUrl: '/images/designs/pinfroieud.png', dataAiHint: 'diseño freud' },
  { id: 'design-kalzcolores', name: 'Kalz Colores', imageUrl: '/images/designs/kalzcolores.png', dataAiHint: 'logo colores' },
  { id: 'design-kalzderretida', name: 'Kalz Derretida', imageUrl: '/images/designs/kalzderretida.png', dataAiHint: 'logo derretido' },
  { id: 'design-kalzlogo2', name: 'Logo Kalz 2', imageUrl: '/images/designs/kalzlogo2.png', dataAiHint: 'logo kalz' },
  { id: 'design-manobrillo', name: 'Mano Brillo', imageUrl: '/images/designs/manobrillo.png', dataAiHint: 'mano brillante' },
  { id: 'design-nepegirl', name: 'Nepe Girl', imageUrl: '/images/designs/nepegirl.png', dataAiHint: 'chica anime' },
  { id: 'design-pellitodiablo', name: 'Pellito Diablo', imageUrl: '/images/designs/pellitodiablo.png', dataAiHint: 'perrito diablo' },
];

const creationTypes = [
  { id: 'Dibujo', label: 'Dibujo', icon: Brush },
  { id: 'Realista', label: 'Realista', icon: Camera },
  { id: 'Caricatura', label: 'Caricatura', icon: Feather },
  { id: 'Anime', label: 'Anime', icon: Zap },
  { id: 'Minimalista', label: 'Minimalista', icon: Pencil },
  { id: 'Abstracto', label: 'Abstracto', icon: BrainCircuit },
];

const availableSizes: string[] = ['S', 'M', 'L', 'XL', 'XXL'];

const availableFonts: { name: string, style: string }[] = [
    { name: 'Bageki', style: 'Bageki Luxury' },
    { name: 'Anton', style: 'Anton, sans-serif' },
    { name: 'Bebas Neue', style: 'Bebas Neue, sans-serif' },
    { name: 'Caveat', style: 'Caveat, cursive' },
    { name: 'Comfortaa', style: 'Comfortaa, sans-serif' },
    { name: 'Courier Prime', style: 'Courier Prime, monospace' },
    { name: 'Dancing Script', style: 'Dancing Script, cursive' },
    { name: 'Fjalla One', style: 'Fjalla One, sans-serif' },
    { name: 'Georgia', style: 'Georgia, serif' },
    { name: 'Impact', style: 'Impact, sans-serif' },
    { name: 'Lato', style: 'Lato, sans-serif' },
    { name: 'Lobster', style: 'Lobster, cursive' },
    { name: 'Merriweather', style: 'Merriweather, serif' },
    { name: 'Montserrat', style: 'Montserrat, sans-serif' },
    { name: 'Oswald', style: 'Oswald, sans-serif' },
    { name: 'Pacifico', style: 'Pacifico, cursive' },
    { name: 'Playfair Display', style: 'Playfair Display, serif' },
    { name: 'Poppins', style: 'Poppins, sans-serif' },
    { name: 'Roboto', style: 'Roboto, sans-serif' },
    { name: 'Shadows Into Light', style: 'Shadows Into Light, cursive' },
    { name: 'Source Code Pro', style: 'Source Code Pro, monospace' },
];


const shirtColors: ShirtColor[] = [
  { name: 'Acid Wash', hex: '#6B7280', imageUrl: '/images/products/Kalzvieja/camisetas/MC/Mcbasicos/ctamcacidwash.png', dataAiHint: 'camiseta acid wash' },
  { name: 'Blanco', hex: '#FFFFFF', imageUrl: '/images/products/Kalzvieja/camisetas/MC/Mcbasicos/ctamcblanca.png', dataAiHint: 'camiseta blanca' },
  { name: 'Negro', hex: '#000000', imageUrl: '/images/products/Kalzvieja/camisetas/MC/Mcbasicos/ctamcnegra.png', dataAiHint: 'camiseta negra' },
  { name: 'Rosa', hex: '#F472B6', imageUrl: '/images/products/Kalzvieja/camisetas/MC/Mcbasicos/ctamcrosa.png', dataAiHint: 'camiseta rosa' },
  { name: 'Verde', hex: '#10B981', imageUrl: '/images/products/Kalzvieja/camisetas/MC/Mcbasicos/ctamcverde.png', dataAiHint: 'camiseta verde' },
];

interface InteractiveCustomizerProps {
  onCustomizationChange: (options: CustomizationOptions | null) => void;
}


export function InteractiveCustomizer({ onCustomizationChange }: InteractiveCustomizerProps) {
  const { toast } = useToast();
  const { addLook } = useMyLooks();
  const previewRef = useRef<HTMLDivElement>(null);
  
  // Customization State
  const [selectedShirtColor, setSelectedShirtColor] = useState<ShirtColor>(shirtColors[2]);
  const [selectedSize, setSelectedSize] = useState<string>('M');
  const [selectedDesign, setSelectedDesign] = useState<PreMadeDesign | null>(null);
  const [uploadedImage, setUploadedImage] = useState<File | null>(null);
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null);
  const [isRemovingBg, setIsRemovingBg] = useState(false);
  
  // AI Generator State
  const [aiTopic, setAiTopic] = useState('');
  const [aiSelectedType, setAiSelectedType] = useState<string>(creationTypes[0].id);
  const [aiGeneratedImages, setAiGeneratedImages] = useState<AiGeneratedImageState[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  const [actionType, setActionType] = useState<'studio' | 'viral'>('studio');
  const [lookName, setLookName] = useState('');
  
  // Consolidated text state
  const [customText, setCustomText] = useState<CustomizationOptions['text']>({
    content: '',
    fontFamily: availableFonts[0].style,
    fontSize: 32,
    color: '#FFFFFF',
    position: { x: 50, y: 40 },
  });

  const handleTextChange = (field: keyof NonNullable<CustomizationOptions['text']>, value: any) => {
    setCustomText(prev => ({ ...prev!, [field]: value }));
  };

  const handleTextPositionChange = (position: { x: number; y: number }) => {
    handleTextChange('position', position);
  };

  const fileToDataUri = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };


  const handleFileSelect = (file: File | null) => {
    setUploadedImage(file);
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setUploadedImageUrl(reader.result as string);
        setSelectedDesign(null); // Clear pre-made design
      };
      reader.readAsDataURL(file);
    } else {
      setUploadedImageUrl(null);
    }
  };
  
  const handleAddToCart = () => {
    toast({
      title: "Artículo Añadido (Simulación)",
      description: `La camiseta ${selectedShirtColor.name} con tu diseño ha sido añadida al carrito.`,
      action: <Button variant="outline" size="sm" asChild><Link href="/cart">Ver Carrito</Link></Button>,
    });
  };

  const handleSaveToLooks = async () => {
      if (!previewRef.current) {
        toast({ title: "Error", description: "No se pudo capturar la vista previa del diseño."});
        return;
      }
      if (!lookName.trim()) {
        toast({ title: "Falta el nombre", description: "Por favor, dale un nombre a tu creación."});
        return;
      }

      try {
        const dataUrl = await toPng(previewRef.current, { cacheBust: true });
        const newLook: KalZaiDesign = {
          id: `look-${Date.now()}`,
          userId: "currentUser", // Placeholder for actual user ID
          name: lookName,
          baseProductId: 'kzv-mc-negra-basica', // Placeholder for the actual product ID
          imageDataUri: dataUrl,
          createdAt: new Date(),
          isPublic: false, // Default to private
        };

        addLook(newLook);
        setLookName(''); // Reset name field
        toast({
          title: "¡Diseño Guardado!",
          description: `"${newLook.name}" ha sido guardado en "Mis Looks".`,
          action: <Button variant="outline" size="sm" asChild><Link href="/viral/mis-looks">Ver Mis Looks</Link></Button>,
        });

      } catch (err) {
        console.error('oops, something went wrong!', err);
        toast({ title: "Error al Guardar", description: "No se pudo generar la imagen del diseño.", variant: "destructive" });
      }
    };

  const handleRemoveBg = async () => {
    if (!uploadedImageUrl) {
        toast({
            title: "No hay imagen",
            description: "Sube una imagen primero para poder quitarle el fondo.",
            variant: "destructive"
        });
        return;
    }
    
    setIsRemovingBg(true);
    try {
        const input: RemoveBackgroundInput = { imageDataUri: uploadedImageUrl };
        const result = await removeBackground(input);
        if (result.imageDataUri) {
            setUploadedImageUrl(result.imageDataUri);
            toast({
                title: "¡Fondo Eliminado!",
                description: "La IA ha eliminado el fondo de tu imagen. El resultado está en la vista previa."
            });
        }
    } catch (error) {
        console.error("Error quitando el fondo:", error);
        toast({
            title: "Error de IA",
            description: `No se pudo quitar el fondo: ${error instanceof Error ? error.message : "Error desconocido"}`,
            variant: "destructive"
        });
    } finally {
        setIsRemovingBg(false);
    }
  }
  
  const designUrlToApply = selectedDesign?.imageUrl || uploadedImageUrl;

  const getAiPlaceholderText = () => {
    switch(aiSelectedType) {
      case 'Dibujo': return "Ej: 'Un león con gafas de sol'...";
      case 'Realista': return "Ej: 'Un retrato fotorrealista de un tigre'...";
      case 'Caricatura': return "Ej: 'Un científico loco con pelo alborotado'...";
      case 'Anime': return "Ej: 'Una chica mágica con un báculo estelar'...";
      case 'Minimalista': return "Ej: 'Una sola línea continua de un rostro'...";
      case 'Abstracto': return "Ej: 'Explosión de colores y formas'...";
      default: return "Ej: 'Un perro astronauta flotando'...";
    }
  }

  const handleGenerateDesigns = async () => {
    if (!aiSelectedType) {
      toast({ title: "Selecciona un estilo", description: "Por favor, elige un estilo para tu diseño.", variant: "destructive" });
      return;
    }
    if (!aiTopic.trim()) {
      toast({ title: "Describe tu idea", description: "Por favor, dinos sobre qué tema quieres el diseño.", variant: "destructive" });
      return;
    }
    setIsAiLoading(true);
    setAiGeneratedImages([]);
    try {
      const input: DesignSuggestionsInput = { style: aiSelectedType, topic: aiTopic };
      const result = await designSuggestions(input);
      if (result.images && result.images.length > 0) {
        const newImages: AiGeneratedImageState[] = result.images.map((img, i) => ({
            id: `gen-${i}-${Date.now()}`,
            originalUri: img.imageDataUri,
            noBgUri: null,
            isProcessingBg: false,
            showNoBg: false,
        }));
        setAiGeneratedImages(newImages);
        toast({ title: "¡Diseños Generados!", description: "Aquí tienes algunas ideas visuales. Haz clic en una para usarla." });
      } else {
        toast({ title: "Sin Resultados", description: "La IA no pudo generar diseños. Intenta ser más específico." });
      }
    } catch (error) {
      console.error("Error generando diseños:", error);
      toast({
        title: "Error al Generar Diseños",
        description: `Ocurrió un problema: ${error instanceof Error ? error.message : String(error)}`,
        variant: "destructive",
      });
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleToggleAiImageBg = async (imageId: string) => {
    const imageIndex = aiGeneratedImages.findIndex(img => img.id === imageId);
    if (imageIndex === -1) return;

    const imageState = aiGeneratedImages[imageIndex];

    // If we already have the no-bg version, just toggle visibility
    if (imageState.noBgUri) {
        setAiGeneratedImages(prev => prev.map(img => img.id === imageId ? {...img, showNoBg: !img.showNoBg} : img));
        return;
    }

    // Otherwise, process it
    setAiGeneratedImages(prev => prev.map(img => img.id === imageId ? {...img, isProcessingBg: true} : img));

    try {
        const result = await removeBackground({ imageDataUri: imageState.originalUri });
        setAiGeneratedImages(prev => prev.map(img => 
            img.id === imageId 
                ? {...img, noBgUri: result.imageDataUri, isProcessingBg: false, showNoBg: true} 
                : img
        ));
        toast({ title: "¡Fondo Eliminado!", description: "Puedes volver a hacer clic para restaurarlo." });
    } catch (error) {
        console.error("Error removing AI image background:", error);
        toast({ title: "Error de IA", description: "No se pudo quitar el fondo de esta imagen.", variant: "destructive" });
        setAiGeneratedImages(prev => prev.map(img => img.id === imageId ? {...img, isProcessingBg: false} : img));
    }
  };

  React.useEffect(() => {
    const options: CustomizationOptions = {};
    if (customText?.content) {
      options.text = customText;
    }
    if (designUrlToApply) {
      options.design = { url: designUrlToApply, position: {x: 0, y: 0}, scale: 1};
    }
    onCustomizationChange(Object.keys(options).length > 0 ? options : null);
  }, [selectedShirtColor, selectedSize, designUrlToApply, customText, onCustomizationChange]);


  return (
    <div className="space-y-6">
      <section className={cn(
          "w-full rounded-lg shadow-2xl p-3 sm:p-4 md:p-6",
          "bg-black/40 text-card-foreground"
        )}
      >
        <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_1fr] gap-4 md:gap-6 items-start min-h-[700px]">
          
          {/* Left Panel: T-shirt Preview */}
          <div ref={previewRef} className="w-full h-full flex flex-col items-center justify-center bg-muted/20 rounded-lg p-4 self-stretch min-h-[600px] lg:min-h-0 lg:sticky lg:top-20">
             <ImageViewer2D
                baseImageUrl={selectedShirtColor.imageUrl}
                designUrl={designUrlToApply}
                customText={customText}
                onTextPositionChange={handleTextPositionChange}
             />
          </div>

          {/* Right Panel: All Tools */}
          <Card className="w-full lg:sticky lg:top-20 bg-transparent h-full">
             <ScrollArea className="h-full max-h-[calc(100vh-6rem)]">
               <div className="p-4">
                  <Tabs defaultValue="diseño" className="w-full">
                      <TabsList className="grid w-full grid-cols-3 h-auto p-1">
                          <TabsTrigger value="diseño" className="flex-col gap-1 h-auto py-1.5"><Palette className="h-4 w-4"/>Diseño</TabsTrigger>
                          <TabsTrigger value="texto" className="flex-col gap-1 h-auto py-1.5"><Text className="h-4 w-4"/>Texto</TabsTrigger>
                          <TabsTrigger value="finalizar" className="flex-col gap-1 h-auto py-1.5"><ShoppingCart className="h-4 w-4"/>Finalizar</TabsTrigger>
                      </TabsList>
                      
                      <div className="py-4">
                          {/* TAB: DISEÑO */}
                          <TabsContent value="diseño" className="mt-0 space-y-6">
                              {/* Producto Base */}
                              <div className="space-y-4">
                                  <h3 className="text-lg font-semibold text-foreground">Producto Base</h3>
                                  <div>
                                      <h4 className="text-sm font-semibold text-foreground mb-2">Elige Color</h4>
                                       <div className="flex items-center justify-start gap-2 flex-wrap">
                                          {shirtColors.map((color) => (
                                            <Button
                                              key={color.name}
                                              variant="outline"
                                              size="icon"
                                              className={cn(
                                                "w-8 h-8 rounded-full border-2 transition-all duration-200 hover:scale-110",
                                                selectedShirtColor.name === color.name ? 'border-primary ring-2 ring-primary ring-offset-2 ring-offset-background' : 'border-muted-foreground/50',
                                                color.hex === '#FFFFFF' ? 'border-input' : '',
                                              )}
                                              style={{ backgroundColor: color.hex }}
                                              onClick={() => setSelectedShirtColor(color)}
                                              aria-label={`Color ${color.name}`}
                                              data-ai-hint={color.dataAiHint}
                                            />
                                          ))}
                                        </div>
                                  </div>
                                  <div>
                                      <h4 className="text-sm font-semibold text-foreground mb-2">Elige Talla</h4>
                                      <div className="flex items-center justify-start gap-2 flex-wrap">
                                        {availableSizes.map((size) => (
                                          <Button key={size} variant={selectedSize === size ? 'default' : 'outline'} size="sm" className="h-8 rounded-md transition-all duration-200" onClick={() => setSelectedSize(size)}>
                                            {size}
                                          </Button>
                                        ))}
                                      </div>
                                  </div>
                              </div>
                              <Separator />
                              {/* Contenido del Diseño */}
                              <div>
                                  <h3 className="text-lg font-semibold text-foreground mb-4">Añadir Diseño</h3>
                                  <Tabs defaultValue="ia" className="w-full">
                                      <TabsList className="grid w-full grid-cols-3 h-auto p-1">
                                          <TabsTrigger value="ia" className="flex-col gap-1 h-auto py-1.5 text-xs"><Wand2 className="h-4 w-4"/>Generar con IA</TabsTrigger>
                                          <TabsTrigger value="prediseñados" className="flex-col gap-1 h-auto py-1.5 text-xs"><Star className="h-4 w-4"/>Prediseñados</TabsTrigger>
                                          <TabsTrigger value="subir" className="flex-col gap-1 h-auto py-1.5 text-xs"><ImageIcon className="h-4 w-4"/>Subir Imagen</TabsTrigger>
                                      </TabsList>
                                      <div className="py-4">
                                          <TabsContent value="ia" className="mt-0 space-y-4">
                                             <div>
                                                <Label className="text-sm font-semibold mb-2 block">1. Estilo de Dibujo</Label>
                                                <div className="grid grid-cols-3 gap-2">
                                                    {creationTypes.map(({ id, label, icon: Icon }) => (
                                                    <Button
                                                        key={id}
                                                        variant={aiSelectedType === id ? "default" : "outline"}
                                                        onClick={() => setAiSelectedType(id)}
                                                        className="flex flex-col h-14 gap-1 text-xs"
                                                    >
                                                        <Icon className="h-4 w-4" />
                                                        <span>{label}</span>
                                                    </Button>
                                                    ))}
                                                </div>
                                                </div>
                                                <div>
                                                <Label htmlFor="topic-input" className="text-sm font-semibold mb-2 block">2. Describe tu Idea</Label>
                                                <Textarea id="topic-input" placeholder={getAiPlaceholderText()} value={aiTopic} onChange={(e) => setAiTopic(e.target.value)} rows={3} className="text-sm"/>
                                                </div>
                                                <Button onClick={handleGenerateDesigns} disabled={isAiLoading} className="w-full">
                                                {isAiLoading ? <Image src="/images/splash.gif" alt="Generando..." width={24} height={24} unoptimized className="mr-2" /> : <Sparkles className="mr-2 h-4 w-4" />}
                                                {isAiLoading ? 'Generando...' : 'Generar Diseños'}
                                                </Button>
                                                {aiGeneratedImages.length > 0 && !isAiLoading && (
                                                <div className="space-y-2">
                                                    <h3 className="text-sm font-semibold text-foreground">Resultados (Clic para usar)</h3>
                                                    <ScrollArea className="h-auto">
                                                    <div className="grid grid-cols-3 gap-2 pr-3">
                                                        {aiGeneratedImages.map((image) => (
                                                        <div key={image.id}>
                                                            <button
                                                            className="aspect-square relative group rounded-md overflow-hidden border-2 border-transparent hover:border-primary focus:border-primary focus:outline-none transition-all w-full"
                                                            onClick={() => {
                                                                const imageUrl = image.showNoBg && image.noBgUri ? image.noBgUri : image.originalUri;
                                                                setUploadedImageUrl(imageUrl);
                                                                setSelectedDesign(null);
                                                                toast({ title: "Diseño de IA aplicado", description: "El diseño generado ahora está en la vista previa." });
                                                            }}
                                                            >
                                                            <Image src={image.showNoBg && image.noBgUri ? image.noBgUri : image.originalUri} alt={`Diseño generado`} layout="fill" objectFit="contain" className="bg-white/10" data-ai-hint={`${aiSelectedType} ${aiTopic}`}/>
                                                            </button>
                                                            <Button size="sm" variant="ghost" className="w-full h-7 text-xs mt-1" onClick={() => handleToggleAiImageBg(image.id)} disabled={image.isProcessingBg}>
                                                                {image.isProcessingBg ? <Loader2 className="h-4 w-4 animate-spin"/> : <Wand2 className="h-4 w-4 mr-1"/>}
                                                                {image.isProcessingBg ? '' : (image.showNoBg ? 'Restaurar Fondo' : 'Quitar Fondo')}
                                                            </Button>
                                                        </div>
                                                        ))}
                                                    </div>
                                                    </ScrollArea>
                                                </div>
                                                )}
                                                {isAiLoading && (
                                                    <div className="flex justify-center items-center h-[150px]">
                                                        <Image src="/images/splash.gif" alt="Cargando diseños..." width={100} height={100} unoptimized />
                                                    </div>
                                                )}
                                          </TabsContent>
                                          <TabsContent value="prediseñados" className="mt-0 space-y-4">
                                                <ScrollArea className="h-[400px]">
                                                    <div className="grid grid-cols-3 gap-2 pr-3">
                                                    {preMadeDesigns.map(design => (
                                                        <button
                                                        key={design.id}
                                                        onClick={() => { setSelectedDesign(design.id === selectedDesign?.id ? null : design); setUploadedImageUrl(null); }}
                                                        className={cn("relative aspect-square w-full rounded-md border-2 p-1 transition-all", selectedDesign?.id === design.id ? 'border-primary ring-2 ring-primary' : 'border-transparent hover:border-muted-foreground')}
                                                        >
                                                        <Image src={design.imageUrl} alt={design.name} layout="fill" objectFit="contain" className="bg-white/10 rounded-sm" data-ai-hint={design.dataAiHint}/>
                                                        </button>
                                                    ))}
                                                    </div>
                                                </ScrollArea>
                                          </TabsContent>
                                          <TabsContent value="subir" className="mt-0 space-y-4">
                                              <div className="space-y-2">
                                                <FileUploader
                                                    onFileSelect={handleFileSelect}
                                                    accept="image/png, image/jpeg"
                                                    label="Sube tu imagen (PNG, JPG)"
                                                    id="user-design-upload"
                                                />
                                                </div>
                                                <Button variant="outline" onClick={handleRemoveBg} className="w-full" disabled={!uploadedImageUrl || isRemovingBg}>
                                                    {isRemovingBg ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wand2 className="mr-2 h-4 w-4" />}
                                                    {isRemovingBg ? 'Procesando...' : 'Quitar Fondo con IA'}
                                                </Button>
                                          </TabsContent>
                                      </div>
                                  </Tabs>
                              </div>
                          </TabsContent>
                          
                          {/* TAB: TEXTO */}
                          <TabsContent value="texto" className="mt-0 space-y-4">
                              <div className="space-y-2">
                                <label className="text-sm font-semibold text-foreground">Añade Texto</label>
                                <Input type="text" placeholder="Tu texto aquí..." value={customText?.content} onChange={(e) => handleTextChange('content', e.target.value)} className="h-9" />
                              </div>
                              <div className="space-y-2">
                                <label className="text-sm font-semibold text-foreground">Tipografía</label>
                                <Select onValueChange={(value) => handleTextChange('fontFamily', value)} defaultValue={customText?.fontFamily}>
                                  <SelectTrigger className="h-9"><SelectValue placeholder="Tipografía" /></SelectTrigger>
                                  <SelectContent>{availableFonts.map(font => (<SelectItem key={font.style} value={font.style} style={{ fontFamily: font.style }}>{font.name}</SelectItem>))}</SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <label className="text-sm font-semibold text-foreground">Color de Texto</label>
                                <div className="flex items-center gap-2">
                                  <Input type="color" value={customText?.color} onChange={(e) => handleTextChange('color', e.target.value)} className="w-16 h-10 p-1" />
                                  <span className="text-sm p-2 rounded-md border" style={{ color: customText?.color }}>{(customText?.color || '').toUpperCase()}</span>
                                </div>
                              </div>
                              <div className="space-y-2">
                                <label className="text-sm font-semibold text-foreground">Tamaño: {customText?.fontSize}px</label>
                                <Slider defaultValue={[customText?.fontSize || 32]} max={80} min={12} step={1} onValueChange={(value) => handleTextChange('fontSize', value[0])} />
                              </div>
                          </TabsContent>

                          {/* TAB: FINALIZAR */}
                          <TabsContent value="finalizar" className="mt-0 space-y-4">
                                <div className="space-y-4">
                                    <div>
                                    <Label className="text-sm font-medium mb-2 block text-center">¿Cuál es el propósito de tu creación?</Label>
                                    <RadioGroup defaultValue="studio" value={actionType} onValueChange={(value) => setActionType(value as any)} className="grid grid-cols-2 gap-2">
                                        <div>
                                        <RadioGroupItem value="studio" id="r-studio" className="peer sr-only" />
                                        <Label htmlFor="r-studio" className="flex flex-col items-center justify-center rounded-md border-2 border-muted bg-popover p-3 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                            <Brush className="mb-1 h-5 w-5" />
                                            Comprar
                                        </Label>
                                        </div>
                                        <div>
                                        <RadioGroupItem value="viral" id="r-viral" className="peer sr-only" />
                                        <Label htmlFor="r-viral" className="flex flex-col items-center justify-center rounded-md border-2 border-muted bg-popover p-3 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                            <Save className="mb-1 h-5 w-5" />
                                            Guardar para "Khe Viral"
                                        </Label>
                                        </div>
                                    </RadioGroup>
                                    </div>

                                    {actionType === 'studio' && (
                                    <div className="flex flex-col sm:flex-row justify-center gap-3">
                                        <Button
                                            onClick={handleAddToCart}
                                            className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1 px-6 py-3 text-base sm:text-lg rounded-lg shadow-lg hover:shadow-xl hover:brightness-110 transform hover:scale-105 transition-all duration-300"
                                        >
                                            <ShoppingCart className="mr-2 h-5 w-5" /> Agregar al carrito.
                                        </Button>
                                        <Button
                                            variant="outline"
                                            className="flex-1 border-accent text-accent hover:bg-accent hover:text-accent-foreground px-6 py-3 text-base sm:text-lg rounded-lg shadow-lg hover:shadow-xl hover:brightness-110 transform hover:scale-105 transition-all duration-300"
                                            onClick={() => toast({ title: "Compra Directa (Simulación)", description: "Esta función te llevaría directamente a la página de pago." })}
                                        >
                                            <CreditCard className="mr-2 h-5 w-5" /> Comprar ahora.
                                        </Button>
                                    </div>
                                    )}
                                    
                                    {actionType === 'viral' && (
                                        <AlertDialog>
                                            <AlertDialogTrigger asChild>
                                                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground flex-1 px-6 py-3 text-base sm:text-lg rounded-lg shadow-lg hover:shadow-xl hover:brightness-110 transform hover:scale-105 transition-all duration-300">
                                                <Save className="mr-2 h-5 w-5" /> Guardar en Mis Looks
                                                </Button>
                                            </AlertDialogTrigger>
                                            <AlertDialogContent>
                                                <AlertDialogHeader>
                                                <AlertDialogTitle>Nombra tu Kreación</AlertDialogTitle>
                                                <AlertDialogDescription>
                                                    Dale un nombre único a tu diseño para guardarlo en "Mis Looks".
                                                </AlertDialogDescription>
                                                </AlertDialogHeader>
                                                <div className="py-2">
                                                <Input
                                                        value={lookName}
                                                        onChange={(e) => setLookName(e.target.value)}
                                                        placeholder="Ej: Gato Cyberpunk, Fuego Abstracto..."
                                                    />
                                                </div>
                                                <AlertDialogFooter>
                                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                <AlertDialogAction onClick={handleSaveToLooks} disabled={!lookName.trim()}>
                                                    Guardar Look
                                                </AlertDialogAction>
                                                </AlertDialogFooter>
                                            </AlertDialogContent>
                                        </AlertDialog>
                                    )}

                                    <div className="text-center">
                                        <Button asChild variant="link" className="text-muted-foreground">
                                        <a href="https://wa.me/527711256832" target="_blank" rel="noopener noreferrer">
                                            <MessageCircle className="mr-2 h-4 w-4" /> ¿Necesitas hablar con un experto?
                                        </a>
                                    </Button>
                                    </div>
                                </div>
                          </TabsContent>
                      </div>
                  </Tabs>
                </div>
             </ScrollArea>
           </Card>

        </div>
      </section>
    </div>
  );
}
