
"use client";

import React, { CSSProperties, useState, useRef, MouseEvent, TouchEvent } from 'react';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import type { CustomizationOptions } from '@/types';

interface ImageViewer2DProps {
  baseImageUrl: string;
  designUrl?: string | null;
  customText: CustomizationOptions['text'];
  onTextPositionChange: (position: { x: number; y: number }) => void;
}

export function ImageViewer2D({ baseImageUrl, designUrl, customText, onTextPositionChange }: ImageViewer2DProps) {
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  
  // Offset between the cursor and the top-left corner of the text element
  const offsetRef = useRef({ x: 0, y: 0 });

  const handleDragStart = (clientX: number, clientY: number) => {
    if (!textRef.current || !containerRef.current) return;

    const textRect = textRef.current.getBoundingClientRect();
    const containerRect = containerRef.current.getBoundingClientRect();

    // The cursor position relative to the container's top-left corner
    const cursorXInContainer = clientX - containerRect.left;
    const cursorYInContainer = clientY - containerRect.top;

    // The text element's top-left corner position relative to the container
    const textXInContainer = textRef.current.offsetLeft;
    const textYInContainer = textRef.current.offsetTop;

    offsetRef.current = {
        x: cursorXInContainer - textXInContainer,
        y: cursorYInContainer - textYInContainer,
    };
    
    setIsDragging(true);
    // Prevent default text selection behavior
    document.body.style.userSelect = 'none';
  };
  
  const handleDragMove = (clientX: number, clientY: number) => {
    if (!isDragging || !containerRef.current || !textRef.current) return;

    const containerRect = containerRef.current.getBoundingClientRect();
    
    // Calculate new position relative to the container, in pixels
    let newX = clientX - containerRect.left - offsetRef.current.x;
    let newY = clientY - containerRect.top - offsetRef.current.y;
    
    // Constrain position to stay within the container boundaries
    newX = Math.max(0, Math.min(newX, containerRect.width - textRef.current.offsetWidth));
    newY = Math.max(0, Math.min(newY, containerRect.height - textRef.current.offsetHeight));

    // Convert pixel position to percentage for styling
    const newXPercent = (newX / containerRect.width) * 100;
    const newYPercent = (newY / containerRect.height) * 100;

    onTextPositionChange({ x: newXPercent, y: newYPercent });
  };
  
  const handleDragEnd = () => {
    setIsDragging(false);
    document.body.style.userSelect = '';
  };

  // Mouse event handlers
  const onMouseDown = (e: MouseEvent<HTMLDivElement>) => handleDragStart(e.clientX, e.clientY);
  const onMouseMove = (e: MouseEvent<HTMLDivElement>) => handleDragMove(e.clientX, e.clientY);
  const onMouseUp = () => handleDragEnd();
  const onMouseLeave = () => handleDragEnd();

  // Touch event handlers
  const onTouchStart = (e: TouchEvent<HTMLDivElement>) => handleDragStart(e.touches[0].clientX, e.touches[0].clientY);
  const onTouchMove = (e: TouchEvent<HTMLDivElement>) => handleDragMove(e.touches[0].clientX, e.touches[0].clientY);
  const onTouchEnd = () => handleDragEnd();


  const textStyle: CSSProperties = {
    color: customText?.color || '#FFFFFF',
    fontFamily: customText?.fontFamily || 'Arial, sans-serif',
    fontSize: `${customText?.fontSize || 16}px`,
    position: 'absolute',
    top: `${customText?.position?.y || 50}%`,
    left: `${customText?.position?.x || 50}%`,
    // transform: 'translate(-50%, -50%)', // Center based on its own width/height
    whiteSpace: 'pre-wrap',
    textShadow: '1px 1px 2px rgba(0,0,0,0.2)',
    cursor: isDragging ? 'grabbing' : 'grab',
    userSelect: 'none',
    touchAction: 'none',
    zIndex: 10,
    padding: '4px', // Add some padding to make it easier to grab
  };

  return (
    <div 
        className="relative w-full h-full flex items-center justify-center"
        ref={containerRef}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseLeave}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
    >
      <div className="relative w-[80%] aspect-square">
        <Image
          key={baseImageUrl}
          src={baseImageUrl}
          alt="Prenda base"
          fill
          className="object-contain transition-opacity duration-300"
          priority
        />
        
        {designUrl && (
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1/4 h-1/4"
            style={{ pointerEvents: 'none' }}
          >
            <Image
              src={designUrl}
              alt="Diseño aplicado"
              fill
              className="object-contain"
            />
          </div>
        )}

        {customText?.content && (
          <div 
            ref={textRef}
            style={textStyle}
            onMouseDown={onMouseDown}
            onTouchStart={onTouchStart}
          >
            {customText.content}
          </div>
        )}
      </div>
    </div>
  );
}
    
