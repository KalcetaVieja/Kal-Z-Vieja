
"use client"

import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Truck, CheckCircle, XCircle, Edit3 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import type { Delivery } from "@/types";
import { Input } from '@/components/ui/input';

interface DeliveryTableProps {
  initialDeliveries: Delivery[];
}

const statusVariantMap: Record<Delivery["status"], "default" | "secondary" | "outline" | "destructive"> = {
  pending: "default",
  shipped: "secondary",
  delivered: "outline",
  cancelled: "destructive",
};

const statusTextMap: Record<Delivery["status"], string> = {
  pending: "Pendiente",
  shipped: "Enviado",
  delivered: "Entregado",
  cancelled: "Cancelado",
};

const StatusIconMap: Record<Delivery["status"], React.ElementType> = {
  pending: Truck,
  shipped: Truck,
  delivered: CheckCircle,
  cancelled: XCircle,
};

export function DeliveryTable({ initialDeliveries }: DeliveryTableProps) {
  const [deliveries, setDeliveries] = useState<Delivery[]>(initialDeliveries);
  const [searchTerm, setSearchTerm] = useState('');

  const handleStatusChange = (deliveryId: string, newStatus: Delivery["status"]) => {
    setDeliveries(prev => 
      prev.map(d => d.id === deliveryId ? { ...d, status: newStatus } : d)
    );
  };

  const filteredDeliveries = deliveries.filter(delivery =>
    delivery.orderId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    delivery.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    delivery.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <Input
        placeholder="Buscar por ID de pedido, cliente, dirección..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="max-w-sm"
      />
      <div className="rounded-md border shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID Pedido</TableHead>
              <TableHead>Cliente</TableHead>
              <TableHead>Dirección</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Fecha Creación</TableHead>
              <TableHead>Artículos</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredDeliveries.length > 0 ? (
              filteredDeliveries.map((delivery) => {
                const StatusIcon = StatusIconMap[delivery.status];
                return (
                  <TableRow key={delivery.id}>
                    <TableCell className="font-medium">{delivery.orderId}</TableCell>
                    <TableCell>{delivery.customerName}</TableCell>
                    <TableCell>{delivery.address}</TableCell>
                    <TableCell>
                      <Badge variant={statusVariantMap[delivery.status]} className="capitalize">
                        <StatusIcon className="mr-1 h-3.5 w-3.5" />
                        {statusTextMap[delivery.status]}
                      </Badge>
                    </TableCell>
                    <TableCell>{new Date(delivery.createdAt).toLocaleDateString('es-MX')}</TableCell>
                    <TableCell>{delivery.items.map(item => `${item.name} (x${item.quantity})`).join(', ')}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menú</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => alert(`Ver detalles del pedido ${delivery.orderId}`)}>
                            <Edit3 className="mr-2 h-4 w-4" /> Ver/Editar Detalles
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleStatusChange(delivery.id, 'shipped')} disabled={delivery.status === 'shipped' || delivery.status === 'delivered' || delivery.status === 'cancelled'}>
                            Marcar como Enviado
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleStatusChange(delivery.id, 'delivered')} disabled={delivery.status === 'delivered' || delivery.status === 'cancelled'}>
                            Marcar como Entregado
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleStatusChange(delivery.id, 'cancelled')} disabled={delivery.status === 'cancelled' || delivery.status === 'delivered'} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                            Cancelar Pedido
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">
                  No se encontraron entregas.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
