'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useLanguage } from '@/context/language-context';
import { cn } from '@/lib/utils';

type BubbleStyle = {
  animationDelay: string;
  left: string;
  animationDuration: string;
  transform: string;
};

export function PageLoader() {
  const { isLoadingPage } = useLanguage();
  const [bubbleStyles, setBubbleStyles] = useState<BubbleStyle[]>([]);

  useEffect(() => {
    // Generate styles only on the client side to prevent hydration mismatch.
    const styles = Array.from({ length: 40 }).map(() => ({
      animationDelay: `${Math.random() * 5}s`,
      left: `${Math.random() * 100}vw`,
      animationDuration: `${Math.random() * 3 + 5}s`,
      transform: `scale(${Math.random() * 0.5 + 0.5})`,
    }));
    setBubbleStyles(styles);
  }, []);

  return (
    <div
      className={cn(
        "page-loader-overlay",
        isLoadingPage ? "opacity-100" : "opacity-0 pointer-events-none"
      )}
    >
      {/* Map to create multiple bubble icons */}
      {bubbleStyles.map((style, i) => (
        <Image
          key={i}
          src="/images/splash.gif"
          alt=""
          width={80}
          height={80}
          unoptimized
          className="page-loader-icon"
          style={style}
          data-ai-hint="icono carga"
        />
      ))}
       <p className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white font-custom text-lg font-semibold mt-4 text-center animate-pulse">Cargando...</p>
    </div>
  );
}
