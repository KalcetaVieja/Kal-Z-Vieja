
"use client"

import * as React from "react"
import { Palette } from "lucide-react"
import { useTheme } from "next-themes"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme()

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon">
          <Palette className={cn(
            "h-[1.2rem] w-[1.2rem] transition-all",
            theme === 'black' && 'text-pink-500',
            theme === 'pink' && 'text-pink-400',
            theme === 'tornasol' && 'kalz-iridescent-text-flow',
          )} />
          <span className="sr-only">Cambiar tema</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => setTheme("black")}>
          <Palette className="mr-2 h-4 w-4" />
          Black (Negro/Rosa)
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setTheme("pink")}>
          <Palette className="mr-2 h-4 w-4" />
          Pink (Rosa/Blanco)
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setTheme("tornasol")}>
          <Palette className="mr-2 h-4 w-4" />
          Tornasol
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
