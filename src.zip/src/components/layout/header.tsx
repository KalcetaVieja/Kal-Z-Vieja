
"use client"

import Link from "next/link"
import { Menu, UserCircle, Brush, Home, Mail, Camera, Globe, Shield, LogOut, UserCog, Shirt, Crown, Gift, Palette, ChevronDown, Eye, Package, CassetteTape, X, ArrowLeft, History, Ticket, Gem, Percent, Truck, Copy, Sparkles, ShoppingCart, Minus, Plus } from "lucide-react" 
import * as React from "react"
import { useRouter } from "next/navigation"; // Added for redirection

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger, SheetClose, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent
} from "@/components/ui/dropdown-menu"
import { useLanguage } from "@/context/language-context"
import { HighlightK } from "./highlight-k";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "next-themes"
import { cn } from "@/lib/utils"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { useRecentlyViewed } from "@/hooks/use-recently-viewed"
import { Separator } from "../ui/separator"
import Image from "next/image"
import { useNavigationHistory } from "@/context/navigation-history-context";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card";
import { Dialog, DialogContent, DialogTrigger, DialogClose, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import type { CartItem } from '@/types';
import { useAssistant } from '@/context/assistant-context';
import { mockCartItems } from '@/data/mock';

const navLinkDefinitions = [
  { href: "/home", translationKey: "homeNav", icon: Home },
  { href: "/catalog", translationKey: "katalogNav", icon: Shirt },
  { href: "/kal-z-ai", translationKey: "kalZStudioNav", icon: Brush },
  { href: "/recompensas", translationKey: "rewardsNav", icon: Gift },
  { href: "/mayoristas", translationKey: "mayoristasNav", icon: Package },
];

const specialLinkDefinitions = [
    { href: "/viral", translationKey: "viralNav", icon: Crown },
    { href: "/los-90s", translationKey: "ninetiesNav", icon: CassetteTape },
];
const upcomingLink = { href: "/recompensas", translationKey: "kalcepointsNav", icon: Gift };


const translations = {
  es: {
    homeNav: "Home",
    katalogNav: "Kal-Z-Vieja",
    kalZStudioNav: "Kal-Z-Studio",
    viralNav: "Khe Viral",
    mayoristasNav: "Mayoristas",
    rewardsNav: "Rekompensas",
    contactNav: "Contacto", 
    ninetiesNav: "Los 90s",
    africaNav: "África",
    kalcepointsNav: "Kalcepoints",
    comingSoon: "Próximamente",
    moreCategories: "Más Kategorías",
    moreCategoriesDesc: "Explora colecciones y secciones especiales",
    kalceAdm: "KalceMaster",
    login: "Iniciar Sesión",
    logout: "Cerrar Sesión",
    myProfile: "Mi Perfil",
    myOrders: "Mis Pedidos",
    userMenu: "Menú de Usuario",
    helloUser: "Hola,",
    language: "Idioma",
    spanish: "Español",
    english: "Inglés",
    mobileMenuTitle: "Menú", 
    mobileMenuDesc: "Navegación principal del sitio Kal-Z-Vieja",
    theme: "Tema",
    themeVieja: "Vieja (Boceto)",
    themeTornasol: "Tornasol",
    themeGreen: "Green (Militar)",
    cart: "Carrito de Compras",
    viralGallery: "Galería de la Comunidad",
    myLooks: "Mis Looks",
    kalcepointsTitle: "Kalcepoints y Cupones",
    kalcepointsDesc: "Tus recompensas y puntos disponibles.",
    yourBalance: "Tu Saldo",
    points: "Puntos",
    availableCoupons: "Cupones Disponibles",
    redeemPoints: "Canjear Puntos por Artículos",
    coupon10: "10% de Descuento",
    coupon10Desc: "En tu próxima compra de camiseta.",
    couponShip: "Envío Gratis",
    couponShipDesc: "En pedidos superiores a $400 MXN.",
    couponTote: "Totebag de Regalo",
    couponToteDesc: "En la compra de 2+ sudaderas.",
    copyCode: "Copiar Código",
    codeCopied: "Código Copiado",
    couponCopiedDesc: 'El código "{code}" ha sido copiado.',
  },
  en: {
    homeNav: "Home",
    katalogNav: "Kal-Z-Vieja", 
    kalZStudioNav: "Kal-Z-Studio",
    viralNav: "Khe Viral", 
    mayoristasNav: "Wholesalers",
    rewardsNav: "Rekompensas", 
    contactNav: "Contact",
    ninetiesNav: "The 90s",
    africaNav: "Africa",
    kalcepointsNav: "Kalcepoints",
    comingSoon: "Coming Soon",
    moreCategories: "More Kategories",
    moreCategoriesDesc: "Explore special collections and sections",
    kalceAdm: "KalceMaster",
    login: "Login",
    logout: "Logout",
    myProfile: "My Profile",
    myOrders: "My Orders",
    userMenu: "User Menu",
    helloUser: "Hello,",
    language: "Language",
    spanish: "Spanish",
    english: "English",
    mobileMenuTitle: "Menu",
    mobileMenuDesc: "Main site navigation for Kal-Z-Vieja",
    theme: "Tema",
    themeVieja: "Vieja (Sketch)",
    themeTornasol: "Iridescent",
    themeGreen: "Green (Military)",
    cart: "Shopping Cart",
    viralGallery: "Community Gallery",
    myLooks: "My Looks",
    kalcepointsTitle: "Kalcepoints & Coupons",
    kalcepointsDesc: "Your available rewards and points.",
    yourBalance: "Your Balance",
    points: "Points",
    availableCoupons: "Available Coupons",
    redeemPoints: "Redeem Points for Items",
    coupon10: "10% Discount",
    coupon10Desc: "On your next t-shirt purchase.",
    couponShip: "Free Shipping",
    couponShipDesc: "On orders over $400 MXN.",
    couponTote: "Free Totebag",
    couponToteDesc: "With the purchase of 2+ hoodies.",
    copyCode: "Copy Code",
    codeCopied: "Code Copied",
    couponCopiedDesc: 'The code "{code}" has been copied.',
  }
};

const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);
  const [user, setUser] = React.useState<{name: string, email?: string, isAdminMaster?: boolean} | null>(null);
  const languageContext = useLanguage();
  const { locale, setIsLoadingPage } = languageContext;
  const { toast } = useToast();
  const [isClient, setIsClient] = React.useState(false);
  const router = useRouter(); // For redirection

  React.useEffect(() => {
    setIsClient(true); 
    const loggedIn = localStorage.getItem("isLoggedIn") === "true";
    setIsAuthenticated(loggedIn);
    if (loggedIn) {
      const isMasterAdmin = localStorage.getItem("isKalZVijaMasterAdmin") === "true";
      if (isMasterAdmin) {
        setUser({ name: "Master Kal-Z", email: "kalceta.vieja@gmail.com", isAdminMaster: true });
      } else {
        const profileName = localStorage.getItem('userProfileName') || "Kalceto";
        setUser({ name: profileName, email: "usuario@ejemplo.com", isAdminMaster: false });
      }
    } else {
      setUser(null);
    }
  }, []); 

  const handleLogout = () => {
    // Clear all session/user related data
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("isKalZVijaMasterAdmin");
    localStorage.removeItem("userProfileName");
    localStorage.removeItem("userState");
    localStorage.removeItem("userTheme");

    setIsAuthenticated(false);
    setUser(null);

    toast({
        title: locale === 'es' ? "Sesión Cerrada" : "Logged Out",
        description: locale === 'es' ? "Has cerrado sesión correctamente." : "You have been logged out successfully."
    });
    
    setIsLoadingPage(true);
    // Redirect to login page
    router.replace('/auth/login'); 
  };

  return { isAuthenticated, user, handleLogout, setIsAuthenticated, setUser, isClient };
};


export function Header() {
  const {isAuthenticated, user, handleLogout, isClient } = useAuth();
  const { theme, setTheme } = useTheme();
  const { locale, setLocale } = useLanguage();
  const { toast } = useToast();
  const { recentlyViewed, clearRecentlyViewed } = useRecentlyViewed();
  const { history, clearHistory } = useNavigationHistory();
  const hasRecentlyViewed = recentlyViewed.length > 0;
  
  // Cart Logic
  const [cartItems, setCartItems] = React.useState<CartItem[]>(mockCartItems);
  const { showAssistantMessage } = useAssistant();

  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) {
      removeItem(productId);
      return;
    }
    setCartItems(items =>
      items.map(item =>
        item.productId === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const removeItem = (productId: string) => {
    const itemToRemove = cartItems.find(item => item.productId === productId);
    if (itemToRemove) {
        setCartItems(items => items.filter(item => item.productId !== productId));
        showAssistantMessage({
          title: "Artículo eliminado",
          message: `"${itemToRemove.name}" ha sido eliminado de tu carrito.`,
        });
    }
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const renderMedia = (item: CartItem) => {
    const url = item.imageUrl;
    const itemIsVideo = item.isVideo ?? url.endsWith('.mp4');
    
    if (itemIsVideo) {
      return <video src={url} width={100} height={125} autoPlay loop muted playsInline className="object-cover w-full h-full" />;
    }
    return <Image src={url} alt={item.name} fill className="object-contain p-2" data-ai-hint={item.dataAiHint || "prenda ropa"} unoptimized={url.endsWith('.gif')} />;
  };

  const t = (key: keyof typeof translations.es, isTitleLike: boolean = false) => {
    let text = translations[locale][key] || translations['es'][key] || String(key);

    const titleKeys = ["kalZStudioNav", "viralNav", "katalogNav", "viralGallery", "myLooks", "ninetiesNav", "rewardsNav", "homeNav", "kalceAdm", "africaNav", "mayoristasNav", "kalcepointsTitle"];
    if (titleKeys.includes(key)) {
        return text;
    }

    if (isTitleLike) {
      text = text.replace(/Catálogo/gi, "KATÁLOGO")
                 .replace(/Katalogo/gi, "KATÁLOGO") 
                 .replace(/Recompensas/gi, "REKOMPENSAS")
                 .replace(/Kalce Adm/gi, "KALCE ADM");
      text = text.replace(/k/g, "K");
    } else {
      text = text.replace(/Katálogo/gi, "Catálogo")
                 .replace(/Katalogo/gi, "Catalog") 
                 .replace(/Rekompensas/gi, "Recompensas");
    }
    return text;
  };
  
  const copyCouponToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({
      title: t('codeCopied'),
      description: t('couponCopiedDesc').replace('{code}', code),
    });
  };

  const iconMap: Record<string, React.ElementType> = {
      '/home': Home,
      '/catalog': Shirt,
      '/kal-z-ai': Brush,
      '/recompensas': Gift,
      '/mayoristas': Package,
      '/viral': Crown,
      '/los-90s': CassetteTape,
      '/cart': ShoppingCart,
      '/profile': UserCircle,
      '/contact': Mail,
      '/viral/mis-looks': Eye,
      '/auth/setup': UserCog
  };

  const getIconForPath = (path: string): React.ElementType => {
      if (iconMap[path]) {
        return iconMap[path];
      }
      if (path.startsWith('/catalog/')) {
        return Shirt;
      }
      if (path.startsWith('/viral/')) {
        return Crown;
      }
      return History; // Default
  };

  if (!isClient) {
    return (
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <div className="flex-1 flex justify-center">
             {/* Placeholder for nav */}
          </div>
          <div className="flex items-center gap-0.5 md:gap-1">
            {/* Placeholder for actions */}
          </div>
        </div>
      </header>
    );
  }

  const renderDesktopNavLink = (link: any) => {
    const linkText = t(link.translationKey as any, true);
    if (link.sublinks) {
        return (
            <DropdownMenu key={link.translationKey}>
                <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="text-sm font-medium text-foreground/70 transition-colors hover:text-foreground hover:bg-accent/10 px-2 py-1 h-auto flex items-center gap-0.5">
                       {link.icon && <link.icon className="h-3 w-3" />}
                        <HighlightK text={linkText} />
                       <ChevronDown className="h-3 w-3 ml-1" />
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                    {link.sublinks.map((sublink: any) => (
                        <DropdownMenuItem key={sublink.href} asChild>
                            <Link href={sublink.href} className="flex items-center gap-2">
                                {sublink.icon && <sublink.icon className="h-4 w-4" />}
                                <HighlightK text={t(sublink.translationKey as any, true)} />
                            </Link>
                        </DropdownMenuItem>
                    ))}
                </DropdownMenuContent>
            </DropdownMenu>
        );
    }
    return (
        <Link
            key={link.href}
            href={link.href}
            className="text-sm font-medium text-foreground/70 transition-colors hover:text-foreground flex items-center gap-1 hover:bg-accent/10 px-2 py-1 rounded-md"
            aria-label={linkText.trim() === '' ? 'Home' : linkText}
        >
            {link.icon && <link.icon className="h-4 w-4" />}
            {linkText.trim() !== '' && <HighlightK text={linkText} />}
        </Link>
    );
  }
  
  const renderMobileNavLink = (link: any, closeSheet: () => void) => {
      const linkText = t(link.translationKey as any, true);
      return (
           <Link
            key={link.href}
            href={link.href}
            onClick={closeSheet}
            className="flex items-center gap-2 text-md font-medium text-foreground/80 transition-colors hover:text-foreground rounded-md px-2.5 py-2 hover:bg-accent/10"
          >
              {link.icon && <link.icon className="h-4 w-4" />}
              <HighlightK text={linkText.trim() === '' ? 'Home' : linkText} />
          </Link>
      )
  }

  const renderSpecialLink = (link: any, closeSheet: () => void) => {
      const linkText = t(link.translationKey as any, true);
      return (
          <Link
            key={link.href}
            href={link.href}
            onClick={closeSheet}
            className="flex items-center gap-2 text-md font-medium text-foreground/80 transition-colors hover:text-foreground rounded-md px-2.5 py-2 hover:bg-accent/10"
          >
              {link.icon && <link.icon className="h-4 w-4" />}
              <HighlightK text={linkText} />
          </Link>
      )
  }


  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between">
        {/* Left side: Special Menu Trigger */}
        <div className="flex items-center">
          {/* HISTORY SIDEBAR */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <History className="h-5 w-5" />
                <span className="sr-only">Abrir historial de navegación</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[320px] p-0 flex flex-col">
              <SheetHeader className="p-4 pb-2 flex-row justify-between items-center border-b">
                  <div className="space-y-0.5 text-left">
                      <SheetTitle className="text-lg">Historial</SheetTitle>
                      <SheetDescription className="text-xs">
                          Páginas que has visitado recientemente.
                      </SheetDescription>
                  </div>
                  <Button variant="outline" size="sm" onClick={clearHistory}>
                      Limpiar
                  </Button>
              </SheetHeader>
              <div className="flex-grow overflow-y-auto">
                  {history.length > 0 ? (
                      <div className="p-4 grid grid-cols-2 gap-3">
                          {history.map((entry, index) => {
                              const Icon = getIconForPath(entry.path);
                              return (
                              <SheetClose key={entry.path + entry.timestamp} asChild>
                                  <Link href={entry.path}>
                                      <Card 
                                          className="h-28 flex flex-col justify-center items-center p-2 text-center group hover:bg-accent/10 hover:border-accent transition-all duration-300 cursor-pointer"
                                          style={{ animation: `fadeInUp 0.4s ${index * 0.05}s ease-out forwards`, opacity: 0 }}
                                      >
                                          <Icon className="h-6 w-6 mb-2 text-accent group-hover:scale-110 transition-transform" />
                                          <p className="text-xs font-semibold leading-tight">{entry.title}</p>
                                          <p className="text-[10px] text-muted-foreground truncate w-full px-1">{entry.path}</p>
                                      </Card>
                                  </Link>
                              </SheetClose>
                          )})}
                      </div>
                  ) : (
                      <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground p-4">
                          <History className="h-12 w-12 mb-4"/>
                          <p className="text-sm font-semibold text-foreground">Tu historial está vacío</p>
                          <p className="text-xs">Navega por el sitio para ver tus páginas recientes aquí.</p>
                      </div>
                  )}
              </div>
            </SheetContent>
          </Sheet>

          {/* KALCEPOINTS SIDEBAR */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <Ticket className="h-5 w-5" />
                <span className="sr-only">Abrir panel de Kalcepoints</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[320px] p-0 flex flex-col">
              <SheetHeader className="p-4 border-b">
                <SheetTitle className="text-lg"><HighlightK text={t('kalcepointsTitle', true)} /></SheetTitle>
                <SheetDescription className="text-xs">
                  <HighlightK text={t('kalcepointsDesc')} />
                </SheetDescription>
              </SheetHeader>
              <div className="flex-grow overflow-y-auto p-4 space-y-6">
                
                <Card>
                  <CardHeader className="p-3">
                    <CardTitle className="text-base"><HighlightK text={t('yourBalance')}/></CardTitle>
                  </CardHeader>
                  <CardContent className="p-3 pt-0">
                    <div className="text-3xl font-bold flex items-center gap-2">
                      <Gem className="h-6 w-6 text-accent"/>
                      1,250 <span className="text-lg font-medium text-muted-foreground"><HighlightK text={t('points')}/></span>
                    </div>
                  </CardContent>
                </Card>

                <div>
                  <h3 className="text-md font-semibold mb-3"><HighlightK text={t('availableCoupons')}/></h3>
                  <div className="space-y-3">
                    <Card className="bg-primary/10 border-primary/20">
                      <div className="flex items-center p-3 gap-3">
                        <Percent className="h-7 w-7 text-primary flex-shrink-0"/>
                        <div className="flex-grow">
                          <p className="font-semibold text-sm"><HighlightK text={t('coupon10')}/></p>
                          <p className="text-xs text-muted-foreground"><HighlightK text={t('coupon10Desc')}/></p>
                        </div>
                        <Button size="sm" variant="ghost" onClick={() => copyCouponToClipboard('KALZ10OFF')}>
                          <Copy className="h-4 w-4 mr-1.5"/> <HighlightK text={t('copyCode')}/>
                        </Button>
                      </div>
                    </Card>
                    <Card className="bg-green-500/10 border-green-500/20">
                       <div className="flex items-center p-3 gap-3">
                        <Truck className="h-7 w-7 text-green-500 flex-shrink-0"/>
                        <div className="flex-grow">
                          <p className="font-semibold text-sm"><HighlightK text={t('couponShip')}/></p>
                          <p className="text-xs text-muted-foreground"><HighlightK text={t('couponShipDesc')}/></p>
                        </div>
                        <Button size="sm" variant="ghost" onClick={() => copyCouponToClipboard('ENVIOGRATIS')}>
                          <Copy className="h-4 w-4 mr-1.5"/> <HighlightK text={t('copyCode')}/>
                        </Button>
                      </div>
                    </Card>
                    <Card className="bg-accent/10 border-accent/20">
                      <div className="flex items-center p-3 gap-3">
                        <Gift className="h-7 w-7 text-accent flex-shrink-0"/>
                        <div className="flex-grow">
                          <p className="font-semibold text-sm"><HighlightK text={t('couponTote')}/></p>
                          <p className="text-xs text-muted-foreground"><HighlightK text={t('couponToteDesc')}/></p>
                        </div>
                        <Button size="sm" variant="ghost" onClick={() => copyCouponToClipboard('REGALOTOTE')}>
                          <Copy className="h-4 w-4 mr-1.5"/> <HighlightK text={t('copyCode')}/>
                        </Button>
                      </div>
                    </Card>
                  </div>
                </div>

              </div>
              <div className="p-4 border-t">
                  <Button className="w-full" asChild>
                      <Link href="/recompensas">
                          <Sparkles className="mr-2 h-4 w-4"/> <HighlightK text={t('redeemPoints')}/>
                      </Link>
                  </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>


        {/* Desktop Navigation - Centered */}
        <nav className="hidden md:flex items-center gap-4">
          {navLinkDefinitions.map(renderDesktopNavLink)}
        </nav>

        {/* Right side actions */}
        <div className="flex items-center gap-1 md:gap-2">
          {hasRecentlyViewed && (
             <Popover>
                <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-9 w-9">
                        <Eye className="h-5 w-5" />
                        <span className="sr-only">Ver productos recientes</span>
                    </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-80 bg-card/80 backdrop-blur-lg">
                    <div className="flex items-center justify-between mb-2">
                        <p className="font-semibold text-sm">Vistos Recientemente</p>
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={(e) => { e.preventDefault(); clearRecentlyViewed(); }}>
                            <X className="h-4 w-4" />
                            <span className="sr-only">Limpiar recientes</span>
                        </Button>
                    </div>
                    <Separator className="mb-3" />
                    <div className="flex items-center gap-3">
                    {recentlyViewed.map(product => (
                        <Link key={product.id} href={`/catalog/${product.id}`} className="group relative aspect-square w-14 h-14 block rounded-md overflow-hidden border-2 border-transparent hover:border-primary transition-all">
                            <Image
                                src={product.imageUrl}
                                alt={product.name}
                                layout="fill"
                                objectFit="contain"
                                className="p-1 bg-muted/50 rounded-md"
                                data-ai-hint={product.dataAiHint}
                                unoptimized={product.imageUrl.endsWith('.gif')}
                            />
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                <Eye className="h-6 w-6 text-white" />
                            </div>
                        </Link>
                    ))}
                    </div>
                </PopoverContent>
            </Popover>
          )}

           <Dialog>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <ShoppingCart className="h-5 w-5" />
                <span className="sr-only">Abrir carrito</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-[95vw] w-[95vw] h-[90vh] flex flex-col p-4 sm:p-6 bg-card/90 backdrop-blur-xl">
              <DialogHeader>
                <DialogTitle>Tu Carrito</DialogTitle>
                <DialogDescription>
                  Revisa los artículos de tu carrito aquí.
                </DialogDescription>
              </DialogHeader>

              {cartItems.length > 0 ? (
                <div className="flex-grow flex flex-col space-y-4 mt-4">
                  <div className="flex-grow overflow-y-auto pr-2">
                      <div className="flex flex-col gap-4">
                      {cartItems.map(item => (
                          <Card key={item.productId} className="flex items-center gap-4 p-3 shadow-sm bg-muted/30">
                              <div className="w-20 h-24 sm:w-24 sm:h-30 flex-shrink-0 bg-transparent rounded-md overflow-hidden relative">
                                {renderMedia(item)}
                              </div>
                              <div className="flex-grow">
                                <h3 className="font-semibold text-sm sm:text-base">{item.name}</h3>
                                <p className="text-xs text-muted-foreground">Precio: ${item.price.toFixed(2)} MXN</p>
                                {item.customization && <p className="text-xs text-accent mt-1">Personalizado</p>}
                              </div>
                              <div className="flex items-center gap-2">
                                <Button variant="outline" size="icon" className="h-7 w-7 sm:h-8 sm:w-8" onClick={() => updateQuantity(item.productId, item.quantity - 1)}>
                                  <Minus className="h-4 w-4" />
                                </Button>
                                <span className="w-8 text-center font-semibold">{item.quantity}</span>
                                <Button variant="outline" size="icon" className="h-7 w-7 sm:h-8 sm:w-8" onClick={() => updateQuantity(item.productId, item.quantity + 1)}>
                                  <Plus className="h-4 w-4" />
                                </Button>
                              </div>
                              <p className="font-semibold w-24 text-right text-sm sm:text-base">${(item.price * item.quantity).toFixed(2)}</p>
                              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive h-8 w-8" onClick={() => removeItem(item.productId)}>
                                <X className="h-5 w-5" />
                              </Button>
                          </Card>
                      ))}
                      </div>
                  </div>

                  <div className="flex-shrink-0 pt-4 border-t space-y-4">
                    <div className="flex justify-between font-bold text-lg">
                      <span>Subtotal:</span>
                      <span>${subtotal.toFixed(2)} MXN</span>
                    </div>
                    <DialogClose asChild>
                      <Button size="lg" className="w-full" asChild>
                          <Link href="/cart">
                              Ir al Carrito y Pagar
                          </Link>
                      </Button>
                    </DialogClose>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center flex-grow text-center text-muted-foreground">
                  <ShoppingCart className="h-20 w-20 mb-4" />
                  <h3 className="text-xl font-semibold text-foreground">Tu carrito está vacío</h3>
                  <p className="mb-6">Parece que no has añadido nada todavía.</p>
                  <DialogClose asChild>
                    <Button asChild>
                      <Link href="/catalog">Empezar a Comprar</Link>
                    </Button>
                  </DialogClose>
                </div>
              )}
            </DialogContent>
          </Dialog>

          {isAuthenticated ? (
             <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9">
                  {user?.isAdminMaster ? <UserCog className="h-6 w-6 text-primary" /> : <UserCircle className="h-6 w-6" />}
                   <span className="sr-only"><HighlightK text={t('userMenu')} /></span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" side="bottom">
                <DropdownMenuLabel><HighlightK text={t('helloUser')} /> {user?.name && <HighlightK text={user.name} />}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile"><HighlightK text={t('myProfile')} /></Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin/deliveries"><HighlightK text={t('myOrders')} /></Link>
                </DropdownMenuItem>
                 <DropdownMenuSeparator />

                 {/* Theme and Language Submenu */}
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger>
                     <Palette className={cn(
                        "mr-2 h-4 w-4",
                        theme === 'vieja' && 'text-gray-500',
                     )} />
                      <span className={cn(theme === 'tornasol' && 'kalz-iridescent-text-flow')}><HighlightK text={t('theme')} /></span>
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent>
                     <DropdownMenuItem onClick={() => setTheme("vieja")}>
                        <HighlightK text={t('themeVieja')} />
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setTheme("tornasol")}>
                        <HighlightK text={t('themeTornasol')} />
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setTheme("green")}>
                        <HighlightK text={t('themeGreen')} />
                      </DropdownMenuItem>
                  </DropdownMenuSubContent>
                </DropdownMenuSub>

                <DropdownMenuSub>
                  <DropdownMenuSubTrigger>
                    <Globe className="mr-2 h-4 w-4" />
                    <HighlightK text={t('language')} />
                  </DropdownMenuSubTrigger>
                   <DropdownMenuSubContent>
                      <DropdownMenuRadioGroup value={locale} onValueChange={(value) => setLocale(value as 'es' | 'en')}>
                        <DropdownMenuRadioItem value="es"><HighlightK text={t('spanish')} /></DropdownMenuRadioItem>
                        <DropdownMenuRadioItem value="en"><HighlightK text={t('english')} /></DropdownMenuRadioItem>
                      </DropdownMenuRadioGroup>
                   </DropdownMenuSubContent>
                </DropdownMenuSub>
                
                {user?.isAdminMaster && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/master-panel">
                        <Shield className="mr-2 h-4 w-4" /><HighlightK text={t('kalceAdm', true)} />
                      </Link>
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                  <LogOut className="mr-2 h-4 w-4" />
                  <HighlightK text={t('logout')} />
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild variant="outline" size="sm" className="h-8 px-3">
              <Link href="/auth/login"><HighlightK text={t('login')} /></Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
