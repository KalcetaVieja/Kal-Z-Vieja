'use client';

import React, { useEffect, useRef } from 'react';

const ClientSpaceBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    if (!ctx) return;

    let w: number, h: number;
    let center_x: number, center_y: number;
    let max_dist: number;
    let stars: any[] = [];
    const STAR_COUNT = 600;

    let comets: any[] = [];
    let rocketImages: HTMLImageElement[] = [];
    const rocketPaths = [
        '/images/Logos/Viejita/cohete/cohete.png',
        '/images/Logos/Viejita/cohete/cohete1.png',
        '/images/Logos/Viejita/cohete/cohete2.png'
    ];
    let imagesLoaded = 0;
    
    let animationFrameId: number;
    let cometIntervalId: NodeJS.Timeout;

    // Load rocket images
    rocketPaths.forEach(path => {
        const img = new Image();
        img.src = path;
        img.onload = () => {
            imagesLoaded++;
        };
        rocketImages.push(img);
    });

    function resize() {
      if (!canvas) return;
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      center_x = w / 2;
      center_y = h / 2;
      max_dist = Math.sqrt(center_x * center_x + center_y * center_y);
    }

    function createStars() {
      stars = [];
      for (let i = 0; i < STAR_COUNT; i++) {
        stars.push({
            angle: Math.random() * 2 * Math.PI,
            dist: Math.random() * max_dist,
            speed: Math.random() * 0.2 + 0.05, // Slow speed for stars
        });
      }
    }
    
    function spawnComet() {
        if (imagesLoaded < rocketPaths.length || !w || !h) return;
        
        let x, y, angle;
        const side = Math.floor(Math.random() * 4);

        switch (side) {
            case 0: // from top
                x = Math.random() * w;
                y = -100;
                angle = Math.random() * Math.PI * 0.5 + Math.PI * 0.25; // Point downwards
                break;
            case 1: // from right
                x = w + 100;
                y = Math.random() * h;
                angle = Math.random() * Math.PI * 0.5 + Math.PI * 0.75; // Point leftwards
                break;
            case 2: // from bottom
                x = Math.random() * w;
                y = h + 100;
                angle = Math.random() * Math.PI * 0.5 + Math.PI * 1.25; // Point upwards
                break;
            default: // from left
                x = -100;
                y = Math.random() * h;
                angle = Math.random() * Math.PI * 0.5 - Math.PI * 0.25; // Point rightwards
                break;
        }

        comets.push({
            x: x,
            y: y,
            angle: angle,
            speed: Math.random() * 3 + 4,
            image: rocketImages[Math.floor(Math.random() * rocketImages.length)]
        });
    }

    function drawScene() {
      if (!ctx || !w || !h) return;

      ctx.fillStyle = 'black';
      ctx.fillRect(0, 0, w, h);

      // Draw and update stars
      stars.forEach(function (star) {
        star.dist += star.speed;

        if (star.dist > max_dist) {
            star.dist = 0; // Reset to center
            star.angle = Math.random() * 2 * Math.PI;
        }
        
        const x = center_x + Math.cos(star.angle) * star.dist;
        const y = center_y + Math.sin(star.angle) * star.dist;
        const size = (star.dist / max_dist) * 2.5;

        ctx.fillStyle = `rgba(255, 255, 255, ${0.3 + (1 - star.dist/max_dist) * 0.7})`;
        
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw and update comets
      comets.forEach((comet, index) => {
          comet.x += Math.cos(comet.angle) * comet.speed;
          comet.y += Math.sin(comet.angle) * comet.speed;
          
          const size = 60; // Make rockets smaller

          ctx.save();
          ctx.translate(comet.x, comet.y);
          ctx.rotate(comet.angle + Math.PI / 2); 
          ctx.drawImage(comet.image, -size/2, -size/2, size, size);
          ctx.restore();

          // Remove comet if it's far off-screen
          if (comet.x < -200 || comet.x > w + 200 || comet.y < -200 || comet.y > h + 200) {
              comets.splice(index, 1);
          }
      });
    }
    
    function animate() {
      drawScene();
      animationFrameId = requestAnimationFrame(animate);
    }

    // Initial setup
    window.addEventListener('resize', resize);
    resize();
    createStars();
    
    spawnComet();
    cometIntervalId = setInterval(spawnComet, 10000);

    animate();

    // Cleanup function
    return () => {
      window.removeEventListener('resize', resize);
      clearInterval(cometIntervalId);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div
      id="three-js-background"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        zIndex: -1,
        overflow: 'hidden',
        background: 'black',
      }}
    >
      <canvas ref={canvasRef} style={{ display: 'block', position: 'fixed', top: 0, left: 0 }} />
    </div>
  );
};

export default ClientSpaceBackground;
