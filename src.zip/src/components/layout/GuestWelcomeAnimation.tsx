'use client';

import { useLanguage } from '@/context/language-context';
import Image from 'next/image';
import { useEffect, useState } from 'react';

type IconStyle = {
  animationDelay: string;
  left: string;
};

const GuestWelcomeAnimation = () => {
  const { isGuestWelcoming, setIsGuestWelcoming } = useLanguage();
  const [iconStyles, setIconStyles] = useState<IconStyle[]>([]);

  useEffect(() => {
    if (isGuestWelcoming) {
      // Generate styles only on the client side when the animation is active.
      const styles = Array.from({ length: 50 }).map(() => ({
        animationDelay: `${Math.random() * 3}s`,
        left: `${Math.random() * 100}vw`,
      }));
      setIconStyles(styles);

      const timer = setTimeout(() => {
        setIsGuestWelcoming(false);
      }, 4000); // Matches animation duration + fade-out
      return () => clearTimeout(timer);
    }
  }, [isGuestWelcoming, setIsGuestWelcoming]);

  if (!isGuestWelcoming) {
    return null;
  }

  return (
    <div className="guest-welcome-overlay">
      {iconStyles.map((style, i) => (
        <Image
          key={i}
          src="/images/splash.gif"
          alt=""
          width={80}
          height={80}
          unoptimized
          className="guest-welcome-icon"
          style={{
            ...style,
            // @ts-ignore
            '--i': i,
          }}
          data-ai-hint="icono carga"
        />
      ))}
    </div>
  );
};

export default GuestWelcomeAnimation;
