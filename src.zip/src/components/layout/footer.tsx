"use client";

import * as React from "react"
import Link from "next/link"
import Image from "next/image" 
import { Mail, MapPin, Phone, MessageCircle, Instagram, Facebook, ExternalLink, Package } from "lucide-react"
import { useLanguage } from "@/context/language-context"
import { HighlightK } from "./highlight-k"; 
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useTheme } from "next-themes";

const TikTokIcon = ({ className }: { className?: string }) => (
  <svg
    className={cn("lucide", className)}
    viewBox="0 0 24 24" 
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
    suppressHydrationWarning={true}
  >
    <path d="M19 3H5V5H11V21H13V5H19V3Z" />
  </svg>
);


const translations = {
  es: {
    tagline: "Personaliza tu estilo con diseños únicos y prueba virtualmente tu ropa antes de comprar.",
    contactDirect: "KONTAKTO DIRECTO",
    ourStores: "Nuestra Tienda",
    followUs: "Síguenos",
    rightsReserved: "Todos los derechos reservados.",
    storeCentro: "Kal-Z-Vieja (Centro):",
    addressCentro: "Calle Allende #324, Col Centro Pach, Hgo.",
    freeShipping: "Envío gratuito a toda la República Mexicana en compras superiores a $600 MXN.",
    brandName: "KAL-Z-VIEJA",
  },
  en: {
    tagline: "Personalize your style with unique designs and virtually try on your clothes before buying.",
    contactDirect: "DIRECT KONTAKT",
    ourStores: "Our Store",
    followUs: "Follow Us",
    rightsReserved: "All rights reserved.",
    storeCentro: "Kal-Z-Vieja (Center):",
    addressCentro: "Allende St #324, Col Centro Pach, Hgo.",
    freeShipping: "Free shipping throughout Mexico on purchases over $600 MXN.",
    brandName: "KAL-Z-VIEJA",
  }
};

export function Footer() {
  const [isClient, setIsClient] = React.useState(false);
  const languageContext = useLanguage();
  const { theme } = useTheme();
  const currentYear = new Date().getFullYear();
  
  React.useEffect(() => {
    setIsClient(true);
  }, []);

  const getLogoSrc = () => {
    if (!isClient) return "/images/Logos/kalZlogin.png"; // Default for SSR and initial load
    const cacheBust = '?v=6';
    switch(theme) {
      case 'green':
        return `/images/Logos/logokalZ.png${cacheBust}`;
      case 'tornasol':
        return `/images/Logos/logo8bit.png${cacheBust}`;
      case 'vieja':
        return `/images/Logos/logo%20grises.png${cacheBust}`;
      default:
        return `/images/Logos/kalZlogin.png${cacheBust}`;
    }
  }

  if (!isClient || !languageContext) {
    return (
       <footer className="w-full border-t bg-muted/40">
        <div className="container py-12 px-4 md:px-6 h-[370px]">
          {/* Placeholder to prevent layout shift */}
        </div>
      </footer>
    );
  }

  const { locale } = languageContext;
  
  const t = (key: keyof typeof translations.es, isTitleLike: boolean = false) => {
    let text = translations[locale][key] || translations['es'][key] || String(key);
    if (isTitleLike || key === "contactDirect" || key === "brandName") { // Explicitly mark titles/brand names
      text = text.replace(/k/g, "K"); // Uppercase all K's
    }
    // No C->K replacement for footer general text, only existing K's (now uppercase) will be colored by HighlightK.
    return text;
  }


  return (
    <footer className="w-full border-t bg-muted/40">
      <div className="container py-12 px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {/* Column 1: Brand & Tagline */}
          <div className="space-y-3 lg:col-span-1">
            <Link href="/" className="inline-block" aria-label="Ir a la página de inicio de Kal-Z-Vieja">
              <Image
                src={getLogoSrc()} 
                alt="Logo de Kal-Z-Vieja"
                width={180} 
                height={55} 
                className="h-auto" 
                priority={false}
                data-ai-hint="logo marca"
                suppressHydrationWarning={true}
              />
            </Link>
            <p className="text-sm text-muted-foreground">
              <HighlightK text={t('tagline')} />
            </p>
          </div>

          {/* Column 2: Contacto Directo */}
          <div className="lg:col-span-1">
            <h3 className="text-lg font-semibold mb-4"><HighlightK text={t('contactDirect', true)} /></h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <Phone className="h-4 w-4 text-accent mt-1 flex-shrink-0" suppressHydrationWarning={true} />
                <div>
                  <span className="block">Daniel Arriaga (CEO): <a href="tel:+527711256832" className="hover:text-accent transition-colors"><HighlightK text="+52 77 1125 6832" /></a></span>
                  <span className="block">Tania Jiménez (CEO): <a href="tel:+527712581579" className="hover:text-accent transition-colors"><HighlightK text="+52 77 1258 1579" /></a></span>
                </div>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="h-4 w-4 text-accent mt-1 flex-shrink-0" suppressHydrationWarning={true} />
                <div>
                  <a href="mailto:klz.vieja@gmail.com" className="hover:text-accent transition-colors block"><HighlightK text="klz.vieja@gmail.com" /></a>
                  <a href="mailto:kalceta.vieja@gmail.com" className="hover:text-accent transition-colors block"><HighlightK text="kalceta.vieja@gmail.com" /></a>
                </div>
              </li>
            </ul>
          </div>

          {/* Column 3: Nuestras Tiendas */}
          <div className="lg:col-span-1">
            <h3 className="text-lg font-semibold mb-4"><HighlightK text={t('ourStores', true)} /></h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-accent mt-1 flex-shrink-0" suppressHydrationWarning={true} />
                <div>
                  <span className="font-medium block"><HighlightK text={t('storeCentro')} /></span>
                  <a
                    href="https://maps.app.goo.gl/bXZLSTs5xcW7R1Av8"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-accent transition-colors inline-flex items-center"
                  >
                    <HighlightK text={t('addressCentro')} /> <ExternalLink className="h-3 w-3 ml-1" suppressHydrationWarning={true} />
                  </a>
                </div>
              </li>
            </ul>
          </div>
           {/* Column 4: Shipping Info */}
           <div className="lg:col-span-1">
             <h3 className="text-lg font-semibold mb-4"><HighlightK text={"Envíos"} /></h3>
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <Package className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" suppressHydrationWarning={true} />
                <p><HighlightK text={t('freeShipping')} /></p>
              </div>
           </div>
        </div>

        {/* Social Media and Copyright Row */}
        <div className="border-t pt-8 flex flex-col sm:flex-row justify-between items-center text-center sm:text-left">
          <div className="flex space-x-3 mb-4 sm:mb-0 items-center">
             <h4 className="text-md font-semibold mr-2 hidden sm:block"><HighlightK text={t('followUs', true)} />:</h4>
            <Link href="https://wa.me/527711256832" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp de Daniel Arriaga">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-accent">
                <MessageCircle className="h-6 w-6" suppressHydrationWarning={true} />
              </Button>
            </Link>
            <Link href="https://www.facebook.com/share/1EdRR8bBcY/" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-accent">
                <Facebook className="h-6 w-6" suppressHydrationWarning={true} />
              </Button>
            </Link>
            <Link href="https://www.instagram.com/kalzvieja?igsh=MWk4MnJtZXBpMmUxeg==" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-accent">
                <Instagram className="h-6 w-6" suppressHydrationWarning={true} />
              </Button>
            </Link>
            <Link href="https://www.tiktok.com/@kalz.vieja?_t=ZS-8z03tZgzQXK&_r=1" target="_blank" rel="noopener noreferrer" aria-label="TikTok">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-accent">
                <TikTokIcon className="h-6 w-6" />
              </Button>
            </Link>
          </div>
          <div className="text-sm text-muted-foreground">
            &copy; {currentYear} <HighlightK text={t('brandName', true)} />. <HighlightK text={t('rightsReserved')} />
          </div>
        </div>
      </div>
    </footer>
  )
}
