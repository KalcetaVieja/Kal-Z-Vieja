
// src/components/layout/page-header-banner.tsx
import Image from 'next/image';
import { cn } from '@/lib/utils';

interface PageHeaderBannerProps {
  title: string;
  description?: string;
  imageUrl: string;
  imageAlt?: string;
  dataAiHint: string; // Max two words
}

export function PageHeaderBanner({
  title,
  description,
  imageUrl,
  imageAlt, // Default alt text is now generated inside
  dataAiHint,
}: PageHeaderBannerProps) {
  const isLogoImage = imageUrl.includes('/Logos/');
  const isNinetiesImage = imageUrl.includes('the90sportada.png');
  const isContainedImage = isLogoImage || isNinetiesImage;
  const finalImageAlt = imageAlt || `Banner for ${title || 'Page Header'}`;

  return (
    <section className="relative w-full mb-0 shadow-xl">
      <div className={cn(
        "relative w-full",
        isLogoImage ? "h-[25vh]" : "h-[50vh] sm:h-[60vh] md:h-[70vh] lg:h-[80vh]"
      )}>
        <Image
          src={imageUrl}
          alt={finalImageAlt}
          fill
          className={cn(
            "absolute inset-0 z-0",
            isContainedImage ? "object-contain" : "object-cover",
            // Apply dark background only for the logo, not for the 90s cover
            isLogoImage ? "p-4 sm:p-6 md:p-8 bg-black/70" : "",
            isNinetiesImage ? "p-4 sm:p-6 md:p-8" : "",
            !isContainedImage ? "opacity-80" : ""
          )}
          data-ai-hint={dataAiHint}
          priority // Good for LCP
        />
        {/* Gradient overlay for text readability, applied conditionally */}
        {!isContainedImage && <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent z-10" />}
        <div className="relative z-20 flex flex-col items-center justify-center h-full text-center p-4 sm:p-6">
          {!isContainedImage && (
            <>
              <h1 className="font-anton text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-2 sm:mb-3 drop-shadow-lg">
                {title}
              </h1>
              {description && (
                <p className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-100 max-w-3xl mx-auto drop-shadow-md">
                  {description}
                </p>
              )}
            </>
          )}
           {isLogoImage && title && (
             <h1 className="font-anton text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-2 sm:mb-3 drop-shadow-lg">
                {title}
              </h1>
           )}
        </div>
      </div>
    </section>
  );
}
