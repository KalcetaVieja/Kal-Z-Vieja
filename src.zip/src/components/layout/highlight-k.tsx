
// src/components/layout/highlight-k.tsx
import React from 'react';

interface HighlightKProps {
  text: string;
  as?: React.ElementType;
  className?: string;
}

export function HighlightK({ text, as: Component = 'span', className }: HighlightKProps) {
  if (!text) return null;

  const parts = text.split(/([kK])/g); // Divide por 'k' o 'K', manteniendo los delimitadores

  return (
    <Component className={className}>
      {parts.map((part, index) =>
        part.toLowerCase() === 'k' ? (
          <span key={index} className="text-accent">
            {part}
          </span>
        ) : (
          <React.Fragment key={index}>{part}</React.Fragment>
        )
      )}
    </Component>
  );
}
