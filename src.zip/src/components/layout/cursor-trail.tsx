'use client';

import React, { useEffect } from 'react';

const CursorTrail = () => {
  useEffect(() => {
    // Don't run on touch devices for a better experience
    if (typeof window === 'undefined' || 'ontouchstart' in window) {
      return;
    }

    const trailId = 'cursor-trail-container';
    
    // Clean up any existing trail from a previous render (e.g., during hot-reloading)
    let existingContainer = document.getElementById(trailId);
    if (existingContainer) {
      document.body.removeChild(existingContainer);
    }
    
    const trailContainer = document.createElement('div');
    trailContainer.id = trailId;
    trailContainer.style.position = 'fixed';
    trailContainer.style.top = '0';
    trailContainer.style.left = '0';
    trailContainer.style.width = '100%';
    trailContainer.style.height = '100%';
    trailContainer.style.pointerEvents = 'none';
    trailContainer.style.zIndex = '9999';
    // Start with opacity 0 and add a transition for fading in/out
    trailContainer.style.opacity = '0';
    trailContainer.style.transition = 'opacity 0.3s ease-out';
    document.body.appendChild(trailContainer);

    type TrailImage = {
      element: HTMLImageElement;
      x: number;
      y: number;
    };

    const images: TrailImage[] = [];
    const imageCount = 10; 
    const mouse = { x: -100, y: -100 };
    const trailSrc = '/images/cursor kalz p.cur'; 

    for (let i = 0; i < imageCount; i++) {
      const img = document.createElement('img');
      img.src = trailSrc;
      img.style.position = 'absolute';
      img.style.transform = 'translate(-50%, -50%)';
      img.style.pointerEvents = 'none';
      img.style.userSelect = 'none';
      
      const trailImage: TrailImage = {
        element: img,
        x: -100,
        y: -100,
      };

      trailContainer.appendChild(img);
      images.push(trailImage);
    }

    let moveTimeout: NodeJS.Timeout;
    
    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      
      // Make trail visible on move
      if (trailContainer.style.opacity !== '1') {
        trailContainer.style.opacity = '1';
      }

      // Reset inactivity timeout
      clearTimeout(moveTimeout);
      moveTimeout = setTimeout(() => {
        // Hide trail after inactivity
        trailContainer.style.opacity = '0';
      }, 150); // Hide after 150ms of no movement
    };

    const handleMouseClick = (e: MouseEvent) => {
      const pulseElement = document.createElement('img');
      pulseElement.src = trailSrc;
      pulseElement.style.position = 'fixed'; // Use fixed to position relative to viewport
      pulseElement.style.left = `${e.clientX}px`;
      pulseElement.style.top = `${e.clientY}px`;
      pulseElement.style.transform = 'translate(-50%, -50%)';
      pulseElement.style.pointerEvents = 'none';
      pulseElement.style.userSelect = 'none';
      pulseElement.style.width = '24px'; // Base size for the pulse animation
      pulseElement.style.height = 'auto';
      pulseElement.style.zIndex = '10000'; // Ensure it's on top
      pulseElement.classList.add('cursor-pulse');

      document.body.appendChild(pulseElement);

      setTimeout(() => {
        if (document.body.contains(pulseElement)) {
          document.body.removeChild(pulseElement);
        }
      }, 300); // Remove after animation duration (0.3s)
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('click', handleMouseClick);

    let animationFrameId: number;

    const animateImages = () => {
      let x = mouse.x;
      let y = mouse.y;

      images.forEach((trailImage, index) => {
        const d = trailImage;
        
        d.x += (x - d.x) * 0.4;
        d.y += (y - d.y) * 0.4;
        
        d.element.style.left = d.x + 'px';
        d.element.style.top = d.y + 'px';
        
        const scale = Math.max(1 - index * 0.1, 0.1);
        const opacity = Math.max(0.8 - index * 0.1, 0);
        const blur = index * 0.5;

        d.element.style.width = `${24 * scale}px`; 
        d.element.style.height = 'auto';
        d.element.style.opacity = `${opacity}`;
        d.element.style.filter = `blur(${blur}px)`;

        x = d.x;
        y = d.y;
      });

      animationFrameId = requestAnimationFrame(animateImages);
    };
    
    animateImages();

    // Cleanup function
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('click', handleMouseClick);
      cancelAnimationFrame(animationFrameId);
      clearTimeout(moveTimeout);
      const container = document.getElementById(trailId);
      if (container && document.body.contains(container)) {
        document.body.removeChild(container);
      }
    };
  }, []); 

  return null;
};

export default CursorTrail;
