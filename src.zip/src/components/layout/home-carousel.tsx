
"use client"

import Image from "next/image";
import * as React from "react";
import { useRouter } from 'next/navigation';

import { useLanguage } from "@/context/language-context";
import { HighlightK } from "@/components/layout/highlight-k"; 
import { usePathname } from 'next/navigation';
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { ChevronLeft, ChevronRight } from "lucide-react";

const pageTranslations = {
  es: {
    katalogSlideTitle: "Nuestro KATÁLOGO",
    katalogSlideSubtitle: "Explora una amplia variedad de prendas listas para personalizar. ¡Encuentra tu base perfecta!",
    goToKatalog: "Ir al KATÁLOGO",

    kalzaiStudioTitle: "KAL-Z-STUDIO", 
    kalzaiStudioSubtitle: "Diseña con IA, personaliza prendas y Krea estilos únicos sin límites.",
    goToKalZStudio: "Ir a KAL-Z-STUDIO",
    
    ninetiesNav: "Los 90s",
    ninetiesSubtitle: "La colección más retro para un estilo único.",
    viralNav: "Khe Viral",
    viralSubtitle: "Explora diseños de la comunidad y comparte los tuyos.",
    
    tryonTitle: "Probador AI", 
    tryonSubtitle: "Sube tu foto y mira cómo te quedan las prendas antes de comprar.",
    tryNow: "Probar Ahora",
    
    rewardsTitle: "REKOMPENSAS KAL-Z",
    rewardsSubtitleUpdated: "Gana puntos, completa misiones y obtén descuentos. ¡Descubre cómo!",
    discoverRewards: "Descubrir REKOMPENSAS",
    comingSoon: "Próximamente",
  },
  en: {
    katalogSlideTitle: "Our KATALOG",
    katalogSlideSubtitle: "Explore a wide variety of garments ready to customize. Find your perfect base!",
    goToKatalog: "Go to KATALOG",

    kalzaiStudioTitle: "KAL-Z-STUDIO",
    kalzaiStudioSubtitle: "Design with AI, customize garments, and Kreate limitless unique styles.",
    goToKalZStudio: "Go to KAL-Z-STUDIO",
    
    ninetiesNav: "The 90s",
    ninetiesSubtitle: "The most retro collection for a unique style.",
    viralNav: "Khe Viral",
    viralSubtitle: "Explore community designs and share yours.",

    tryonTitle: "AI Try-On", 
    tryonSubtitle: "Upload your photo and see how the garments fit you before buying.",
    tryNow: "Try Now",

    rewardsTitle: "KAL-Z REWARDS",
    rewardsSubtitleUpdated: "Earn points, complete missions, and get discounts. Discover how!",
    discoverRewards: "Discover REWARDS",
    comingSoon: "Coming Soon",
  }
};

interface CarouselSlide {
  id: string;
  titleKey: keyof typeof pageTranslations.es;
  subtitleKey: keyof typeof pageTranslations.es;
  imageUrl?: string; 
  videoUrl?: string;
  dataAiHint?: string; 
  href: string;
  comingSoon?: boolean;
}

const carouselSlidesData: CarouselSlide[] = [
  {
    id: "slide-viral",
    titleKey: "viralNav",
    subtitleKey: "viralSubtitle",
    videoUrl: "/videos/diapositivas/mp4/5kheviral.mp4",
    dataAiHint: "galeria comunidad disenos",
    href: "/viral"
  },
  { 
    id: "slide-kalzaistudio",
    titleKey: "kalzaiStudioTitle",
    subtitleKey: "kalzaiStudioSubtitle",
    videoUrl: "/videos/diapositivas/mp4/4kalzstudio.gif",
    dataAiHint: "estudio diseno ia",
    href: "/kal-z-ai"
  },
  { 
    id: "slide-katalog",
    titleKey: "katalogSlideTitle",
    subtitleKey: "katalogSlideSubtitle",
    videoUrl: "/videos/diapositivas/mp4/2kalzvieja.gif",
    dataAiHint: "catalogo ropa", 
    href: "/catalog"
  },
  { 
    id: "slide-tryon",
    titleKey: "tryonTitle",
    subtitleKey: "tryonSubtitle",
    videoUrl: "/videos/diapositivas/mp4/6probadorai.gif",
    dataAiHint: "probador virtual ia",
    href: "/virtual-try-on"
  },
  {
    id: "slide-los90s",
    titleKey: "ninetiesNav",
    subtitleKey: "ninetiesSubtitle",
    videoUrl: "/videos/diapositivas/mp4/3los90s.gif", 
    dataAiHint: "coleccion 90s retro",
    href: "/los-90s"
  },
];


export function HomeCarouselWrapper() {
  const pathname = usePathname();
  // Only render the carousel on the home page
  if (pathname !== '/home') {
    return null;
  }
  return <HomeCarousel />;
}


function HomeCarousel() {
  const [isClient, setIsClient] = React.useState(false);
  const languageContext = useLanguage();
  const { toast } = useToast();
  const router = useRouter();
  const [selectedSlideId, setSelectedSlideId] = React.useState<string | null>(null);

  // Swipe logic
  const [touchStart, setTouchStart] = React.useState<number | null>(null);
  const [touchEnd, setTouchEnd] = React.useState<number | null>(null);
  const minSwipeDistance = 50;

  React.useEffect(() => {
    setIsClient(true);
  }, []);
  
  if (!isClient || !languageContext) { 
    return null;
  }
  
  const { locale, setIsLoadingPage } = languageContext;

  const t = (key: keyof typeof pageTranslations.es) => {
    let text = pageTranslations[locale]?.[key] || pageTranslations['es']?.[key] || String(key);
    
    const isTitleOrProminentLabel = 
        key.toLowerCase().includes("title") || 
        key === "readyToCreate" || 
        key === "katalogSlideTitle" ||
        key === "kalzaiStudioTitle" ||
        key === "tryonTitle" ||
        key === "rewardsTitle" ||
        key === "homeWelcomeTitle";


    if (isTitleOrProminentLabel) {
      text = text.replace(/Catálogo/gi, "KATÁLOGO")
                 .replace(/Recompensas/gi, "REKOMPENSAS")
                 .replace(/Krear/gi, "KREAR")
                 .replace(/Kal-Z-Vieja/gi, "KAL-Z-VIEJA")
                 .replace(/Kal-Z-Studio/gi, "KAL-Z-STUDIO")
                 .replace(/Khe Viral/gi, "KHE VIRAL")
                 .replace(/Contacto/gi, "KONTAKTO");
      text = text.replace(/K/g, "K").replace(/k/g, "K");
    } else {
      text = text.replace(/Katálogo/gi, "Catálogo")
                 .replace(/Rekompensas/gi, "Recompensas")
                 .replace(/Krear/gi, "Crear");
    }
    return text;
  }
  
  const handleInteraction = (slide: CarouselSlide) => {
    if (slide.comingSoon) {
      toast({
        title: `Próximamente: ${t(slide.titleKey)}`,
        description: "¡Estamos trabajando en esta sección!",
      });
      return;
    }
    
    if (selectedSlideId === slide.id) {
      // Second click/touch, navigate
      setIsLoadingPage(true);
      router.push(slide.href);
    } else {
      // First click/touch, select
      setSelectedSlideId(slide.id);
    }
  };

  const navigate = (direction: number) => {
    const currentIndex = carouselSlidesData.findIndex(s => s.id === selectedSlideId);
    if (currentIndex === -1) {
        setSelectedSlideId(carouselSlidesData[0].id);
        return;
    }
    const nextIndex = (currentIndex + direction + carouselSlidesData.length) % carouselSlidesData.length;
    setSelectedSlideId(carouselSlidesData[nextIndex].id);
  };

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    if (isLeftSwipe) navigate(1);
    if (isRightSwipe) navigate(-1);
  };


  return (
      <div 
        className="w-full max-w-full mx-auto relative -mt-4 sm:-mt-8 mb-12" 
        onMouseLeave={() => setSelectedSlideId(null)}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        <div className="flex justify-center w-full h-[80vh] max-h-[1000px] min-h-[600px] gap-2 p-2 relative">
            {/* Navigation Arrows (Visible only when a slide is selected) */}
            {selectedSlideId && (
                <>
                    <button 
                        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-black/40 hover:bg-black/60 text-white rounded-full p-3 transition-all duration-300 backdrop-blur-sm"
                        onClick={(e) => { e.stopPropagation(); navigate(-1); }}
                        aria-label="Anterior diapositiva"
                    >
                        <ChevronLeft className="h-8 w-8" />
                    </button>
                    <button 
                        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-black/40 hover:bg-black/60 text-white rounded-full p-3 transition-all duration-300 backdrop-blur-sm"
                        onClick={(e) => { e.stopPropagation(); navigate(1); }}
                        aria-label="Siguiente diapositiva"
                    >
                        <ChevronRight className="h-8 w-8" />
                    </button>
                </>
            )}

            {carouselSlidesData.map((slide, index) => {
              const isSelected = selectedSlideId === slide.id;
              const hasSelection = selectedSlideId !== null;
              const isVideoFile = slide.videoUrl && slide.videoUrl.endsWith('.mp4');
              const isGifFile = slide.videoUrl && slide.videoUrl.endsWith('.gif');
              const mediaUrl = slide.videoUrl || slide.imageUrl;
              
              return (
                <button 
                  key={slide.id} 
                  className={cn(
                    "relative h-full focus:outline-none transition-all duration-700 ease-in-out rounded-lg lg:rounded-xl shadow-lg group overflow-hidden",
                    // This is the core animation logic. We control the width.
                    hasSelection 
                      ? (isSelected ? 'w-full' : 'w-[2%]')
                      : 'w-1/5'
                  )}
                  onClick={() => handleInteraction(slide)}
                  onMouseEnter={() => setSelectedSlideId(slide.id)}
                >
                  <div className="absolute inset-0 w-full h-full overflow-hidden rounded-lg lg:rounded-xl">
                    {(isSelected || !hasSelection) && (
                        <>
                            {isVideoFile ? (
                            <video
                                src={mediaUrl}
                                autoPlay
                                loop
                                muted
                                playsInline
                                preload="metadata"
                                className="absolute inset-0 z-0 w-full h-full object-cover"
                            />
                            ) : mediaUrl ? (
                            <Image
                                src={mediaUrl}
                                alt={t(slide.titleKey)}
                                fill
                                className="absolute inset-0 z-0 object-cover"
                                unoptimized={isGifFile}
                                data-ai-hint={slide.dataAiHint}
                                priority={!hasSelection && index < 2}
                            />
                            ) : null}
                        </>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent z-10" />
                    <div className="relative z-20 flex flex-col justify-end h-full p-8 text-left overflow-hidden">
                          <h2 className={cn(
                            "text-white text-3xl lg:text-5xl font-bold drop-shadow-2xl transition-all duration-500 m-0 p-0 leading-[0.8] tracking-tighter",
                            isSelected ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 -translate-y-10 scale-90'
                          )}>
                            <HighlightK text={t(slide.titleKey)} />
                          </h2>
                           <p className={cn(
                            "text-white/90 text-base lg:text-xl mt-2 drop-shadow-md transition-all duration-500 delay-200 whitespace-normal max-w-5xl font-semibold leading-tight",
                             isSelected ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-5'
                           )}>
                            <HighlightK text={t(slide.subtitleKey)} />
                          </p>
                    </div>
                  </div>
                </button>
              );
            })}
        </div>
      </div>
  )
}
