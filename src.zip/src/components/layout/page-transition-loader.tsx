
"use client";

import React, { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { useLanguage } from '@/context/language-context';

export function PageTransitionLoader() {
  const pathname = usePathname();
  const { setIsLoadingPage } = useLanguage();

  // Hide loader on path change
  useEffect(() => {
    setIsLoadingPage(false);
  }, [pathname, setIsLoadingPage]);
  
  return null;
}
